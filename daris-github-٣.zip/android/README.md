# تطبيق أندرويد دارس

الواجهة بتتبني وتتحط جوه الـ APK، والطلبات بتروح لـ Gemini مباشرة من الموبايل (من غير سيرفر).

## 1) حط المفتاح في GitHub
Settings > Secrets and variables > Actions > New repository secret
- Name: `GEMINI_API_KEY`
- Value: مفتاح Gemini بتاعك

الـ workflow بيكتبه في `.env.local` وقت البناء، والملف ده مش بيترفع على جيت.

## 2) ابني الـ APK
- ادفع على `main` أو شغّل الـ workflow يدوياً من Actions.
- حمّل الـ artifact `daris-app-debug` وفيه `app-debug.apk`، ثبّته على الموبايل.

## ملاحظات أمان مهمة
- المفتاح هيكون موجود داخل الـ APK، أي حد يفك الملف يقدر يوصله. لذلك:
  - ادخل Google AI Studio / Cloud Console وقيّد المفتاح على "Generative Language API" بس.
  - حط Quota/Budget alert عشان لو اتسرق تعرف بسرعة.
  - ماتوزعش الـ APK على حد مش موثوق.
- لو عايز تشيل المفتاح من الـ APK مستقبلاً، لازم ترجع للسيرفر.
