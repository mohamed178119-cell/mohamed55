package com.example.data.repository

import android.content.Context
import android.net.Uri
import android.util.Base64
import com.example.BuildConfig
import com.example.data.api.Content
import com.example.data.api.GenerateContentRequest
import com.example.data.api.GenerationConfig
import com.example.data.api.InlineData
import com.example.data.api.Part
import com.example.data.api.RetrofitClient
import com.example.data.db.ChatMessage
import com.example.data.db.LectureRecording
import com.example.data.db.MasaDatabase
import com.example.data.db.StudyDocument
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.InputStream

class MasaRepository(private val context: Context) {
    private val db = MasaDatabase.getDatabase(context)
    private val studyDao = db.studyDao()
    private val chatDao = db.chatDao()
    private val lectureDao = db.lectureDao()

    val allDocuments: Flow<List<StudyDocument>> = studyDao.getAllDocuments()
    val allMessages: Flow<List<ChatMessage>> = chatDao.getAllMessages()
    val allLectures: Flow<List<LectureRecording>> = lectureDao.getAllLectures()

    companion object {
        const val STUDY_GUARDRAIL_SYSTEM_PROMPT =
            "أنت مساعد دراسي ذكي يدعى ماسة. مهمتك هي المساعدة في الدراسة فقط وتقصي المعلومة الأكاديمية."
    }

    suspend fun saveDocument(doc: StudyDocument): Long = withContext(Dispatchers.IO) {
        studyDao.insertDocument(doc)
    }

    suspend fun deleteDocument(id: Long) = withContext(Dispatchers.IO) {
        studyDao.deleteDocument(id)
    }

    suspend fun saveMessage(msg: ChatMessage): Long = withContext(Dispatchers.IO) {
        chatDao.insertMessage(msg)
    }

    suspend fun clearChat() = withContext(Dispatchers.IO) {
        chatDao.clearChatHistory()
    }

    suspend fun saveLecture(lecture: LectureRecording): Long = withContext(Dispatchers.IO) {
        lectureDao.insertLecture(lecture)
    }

    suspend fun deleteLecture(id: Long) = withContext(Dispatchers.IO) {
        lectureDao.deleteLecture(id)
    }

    suspend fun askMasa(
        userPrompt: String,
        documentContext: String? = null,
        base64Image: String? = null,
        base64Audio: String? = null,
        mimeType: String? = null,
        customApiKey: String? = null
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val keyFromCustom = customApiKey?.trim()
            val apiKey = if (!keyFromCustom.isNullOrBlank() && keyFromCustom != "MY_GEMINI_API_KEY") {
                keyFromCustom
            } else {
                BuildConfig.GEMINI_API_KEY
            }

            if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
                return@withContext Result.failure(
                    Exception("يرجى إدخال كلمة السر للاستمرار.")
                )
            }

            val partsList = mutableListOf<Part>()

            if (!documentContext.isNullOrBlank()) {
                partsList.add(Part(text = "سياق المستند:
$documentContext
---"))
            }

            if (!base64Image.isNullOrBlank()) {
                val type = mimeType ?: "image/jpeg"
                partsList.add(Part(inlineData = InlineData(mimeType = type, data = base64Image)))
            }

            if (!base64Audio.isNullOrBlank()) {
                val type = mimeType ?: "audio/mp3"
                partsList.add(Part(inlineData = InlineData(mimeType = type, data = base64Audio)))
            }

            partsList.add(Part(text = userPrompt))

            val systemInstruction = Content(
                parts = listOf(Part(text = STUDY_GUARDRAIL_SYSTEM_PROMPT))
            )

            val request = GenerateContentRequest(
                contents = listOf(Content(parts = partsList)),
                generationConfig = GenerationConfig(temperature = 0.2f),
                systemInstruction = systemInstruction
            )

            val response = RetrofitClient.service.generateContent(apiKey, request)

            if (response.error != null) {
                return@withContext Result.failure(
                    Exception("خطأ من API: ${response.error.message ?: "خطأ غير معروف"}")
                )
            }

            val answerText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (!answerText.isNullOrBlank()) {
                Result.success(answerText)
            } else {
                Result.failure(Exception("لم يتم استلام رد."))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun summarizeDocument(uri: Uri, fileName: String, fileType: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val contentResolver = context.contentResolver
            val inputStream: InputStream? = contentResolver.openInputStream(uri)
            val bytes = inputStream?.readBytes() ?: return@withContext Result.failure(Exception("فشل قراءة الملف."))
            val base64Data = Base64.encodeToString(bytes, Base64.NO_WRAP)
            val mimeType = when (fileType.uppercase()) {
                "PDF" -> "application/pdf"
                "IMAGE" -> contentResolver.getType(uri) ?: "image/jpeg"
                else -> "application/octet-stream"
            }

            val prompt = "يرجى تلخيص هذا المستند ($fileName)."
            val result = askMasa(
                userPrompt = prompt,
                base64Image = base64Data,
                mimeType = mimeType
            )
            result
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun uriToBase64(uri: Uri): String? {
        return try {
            val inputStream = context.contentResolver.openInputStream(uri)
            val bytes = inputStream?.readBytes()
            bytes?.let { Base64.encodeToString(it, Base64.NO_WRAP) }
        } catch (e: Exception) {
            null
        }
    }
}
