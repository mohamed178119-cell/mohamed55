import { ChatAttachment, InfographicData, AudioLessonTrack } from '../types';

const KEY_STORAGE = 'daris_gemini_key';

export function getStoredGeminiKey(): string {
  try {
    return localStorage.getItem(KEY_STORAGE) || '';
  } catch {
    return '';
  }
}

export function setStoredGeminiKey(key: string): void {
  try {
    if (key) localStorage.setItem(KEY_STORAGE, key);
    else localStorage.removeItem(KEY_STORAGE);
  } catch {
    /* storage unavailable */
  }
}

// الأولوية للمفتاح المتخزن على الجهاز، وبعده المفتاح وقت البناء (لو موجود)
function getApiKey(): string {
  return getStoredGeminiKey() || (import.meta.env.VITE_GEMINI_API_KEY as string | undefined) || '';
}
const GEMINI_BASE = 'https://generativelanguage.googleapis.com/v1beta/models';

const STRICT_TUTOR_SYSTEM_PROMPT = `أنت الأستاذ "دارس" - المعلم الأكاديمي الصارم والمحفز لطلابه، مرشد دراسي استثنائي لا يسمح بأي تشتت.
شخصيتك:
- أكاديمي جاد، رصين، ذو فكر منهجي متين وأسلوب مباشر.
- تشجع على الانضباط، التحصيل العالي، الاستعداد التام للامتحانات، وحل المسائل بفهم عميق.
- نبرتك حازمة لكنها أبوية ومحفزة على الإتقان (مثل: "ركز يا بني"، "العلم لا ينال براحة الجسد"، "هذه مسألة جوهرية في الامتحان"، "خطوتك الأولى صحيحة، والآن أتمم البرهان").

القوانين الصارمة التي لا تحيد عنها أبداً:
1. أنت مخصص 100% للتعليم والدراسة وحل المسائل وفهم المناهج (رياضيات، فيزياء، كيمياء، أحياء، لغات، تاريخ، فلسفة، حاسب، وجميع العلوم الأكاديمية والمهنية).
2. إذا سألك الطالب أو حاول محادثتك في أي موضوع ترفيهي غير دراسي، أو نكات، أو ثرثرة، أو ألعاب، أو مواضيع تشتت الذهن:
   ارفض فوراً وبلهجة المعلم الصارم: "أنا هنا لمستقبلك الدراسي فقط! لن نضيع ثانية واحدة في توافه الأمور. افتح كراستك واطرح سؤالك في الدرس أو لنبدأ حل مسألة الآن."
3. عند حل أي سؤال أو مسألة:
   - اذكر القانون أو القاعدة الأساسية.
   - وضح خطوات الحل بتسلسل منطقي سليم دون قفز على المراحل.
   - ضع الناتج النهائي بشكل بارز مع التمييز والوحدات.
   - اذكر تنبيهاً امتحانياً عن الأخطاء الشائعة التي يقع فيها الطلاب.
4. إذا طلب الطالب "ملخصاً صورياً للدرس" أو "بطاقة إنفوجرافيك"، لخص له الدرس فوراً في شكل عناصر مكثفة (أهم المفاهيم، القوانين الذهبية، أسئلة الامتحانات)، وأخبره أنه يمكنه الضغط على زر "عرض بطاقة الإنفوجرافيك" لتوليد صورة فائقة الجودة وتنزيلها.
5. الإجابات تكون باللغة العربية الفصحى الأكاديمية الراقية، مع كتابة المصطلحات العلمية بالإنجليزية بين قوسين عند الحاجة.`;

type Part = Record<string, any>;

async function generate(opts: {
  model: string;
  contents: Part[];
  systemInstruction?: string;
  generationConfig?: Record<string, any>;
}): Promise<any> {
  const apiKey = getApiKey();
  if (!apiKey) {
    throw new Error('مفتاح Gemini مش متحط. اضغط زرار 🔑 مفتاح Gemini واكتبه.');
  }
  const body: Record<string, any> = { contents: opts.contents };
  if (opts.systemInstruction) {
    body.systemInstruction = { parts: [{ text: opts.systemInstruction }] };
  }
  if (opts.generationConfig) {
    body.generationConfig = opts.generationConfig;
  }

  const res = await fetch(
    `${GEMINI_BASE}/${opts.model}:generateContent?key=${encodeURIComponent(apiKey)}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    }
  );

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data?.error?.message || `فشل الطلب (${res.status})`);
  }
  return data;
}

function textOf(data: any): string {
  return (data?.candidates?.[0]?.content?.parts || [])
    .map((p: any) => p.text || '')
    .join('');
}

function audioOf(data: any): string {
  return data?.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || '';
}

function userTurn(parts: Part[]): Part {
  return { role: 'user', parts };
}

function parseJson(text: string): any {
  const clean = text.replace(/```json|```/g, '').trim();
  return JSON.parse(clean || '{}');
}

async function synthesize(text: string, voiceName: string): Promise<string> {
  const data = await generate({
    model: 'gemini-3.8-flash-lite-tts',
    contents: [userTurn([{ text }])],
    generationConfig: {
      responseModalities: ['AUDIO'],
      speechConfig: {
        voiceConfig: { prebuiltVoiceConfig: { voiceName } },
      },
    },
  });
  return audioOf(data);
}

export async function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const base64 = result.includes(',') ? result.split(',')[1] : result;
      resolve(base64);
    };
    reader.onerror = (error) => reject(error);
    reader.readAsDataURL(file);
  });
}

export async function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const base64 = result.includes(',') ? result.split(',')[1] : result;
      resolve(base64);
    };
    reader.onerror = (error) => reject(error);
    reader.readAsDataURL(blob);
  });
}

export async function askStrictTutor(
  params: {
    message: string;
    history?: { role: 'user' | 'model'; text: string }[];
    attachments?: ChatAttachment[];
  },
  onChunk?: (textSoFar: string) => void
): Promise<string> {
  const apiKey = getApiKey();
  if (!apiKey) {
    throw new Error('مفتاح Gemini مش متحط. اضغط زرار 🔑 مفتاح Gemini واكتبه.');
  }

  const images = (params.attachments || [])
    .filter((a) => a.type === 'image')
    .map((a) => ({ inlineData: { mimeType: a.mimeType || 'image/jpeg', data: a.data } }));

  const pdfs = (params.attachments || [])
    .filter((a) => a.type === 'pdf')
    .map((a) => ({ inlineData: { mimeType: 'application/pdf', data: a.data } }));

  const parts: Part[] = [
    ...pdfs,
    ...images,
    {
      text: params.message || 'يرجى مراجعة المرفق وإعطائي الشرح والحل الأكاديمي الصارم.',
    },
  ];

  const history = (params.history || []).slice(-6).map((item) => ({
    role: item.role === 'user' ? 'user' : 'model',
    parts: [{ text: item.text }],
  }));

  const body = {
    contents: [...history, userTurn(parts)],
    systemInstruction: { parts: [{ text: STRICT_TUTOR_SYSTEM_PROMPT }] },
    generationConfig: { temperature: 0.4 },
  };

  // streamGenerateContent مع alt=sse بيبعت الرد قطع صغيرة وهي بتتولد
  const res = await fetch(
    `${GEMINI_BASE}/gemini-3.8-flash:streamGenerateContent?alt=sse&key=${encodeURIComponent(apiKey)}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    }
  );

  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data?.error?.message || `فشل الطلب (${res.status})`);
  }

  let full = '';

  if (!res.body) {
    full = 'لم يتمكن المعلم من استخراج إجابة، أعد المحاولة بصيغة دراسية أدق.';
    onChunk?.(full);
    return full;
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';

  const handleLine = (rawLine: string) => {
    const line = rawLine.trim();
    if (!line.startsWith('data:')) return;
    const json = line.slice(5).trim();
    if (!json) return;
    try {
      const chunkText = textOf(JSON.parse(json));
      if (chunkText) {
        full += chunkText;
        onChunk?.(full);
      }
    } catch {
      /* سطر غير مكتمل */
    }
  };

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    let idx = buffer.indexOf(String.fromCharCode(10));
    while (idx >= 0) {
      handleLine(buffer.slice(0, idx));
      buffer = buffer.slice(idx + 1);
      idx = buffer.indexOf(String.fromCharCode(10));
    }
  }
  if (buffer) handleLine(buffer);

  return full || 'لم يتمكن المعلم من استخراج إجابة، أعد المحاولة بصيغة دراسية أدق.';
}

export async function transcribeAndSummarizeAudio(
  audioBlob: Blob,
  mimeType: string,
  topicHint?: string
): Promise<{ transcript: string; summary: string }> {
  const audioBase64 = await blobToBase64(audioBlob);
  const audioPart = {
    inlineData: { mimeType: mimeType.split(';')[0], data: audioBase64 },
  };

  let transcript = '';
  try {
    const data = await generate({
      model: 'gemini-3.5-transcribe',
      contents: [
        userTurn([
          audioPart,
          {
            text: `أنت مفرغ محاضرات أكاديمية فائق الدقة. فرغ هذا التسجيل الصوتي بدقة تامة باللغة العربية ${
              topicHint ? `المتعلق بموضوع: ${topicHint}` : ''
            } متضمناً كل المصطلحات العلمية والشروحات المنطوقة بدقة دون حذف.`,
          },
        ]),
      ],
    });
    transcript = textOf(data);
  } catch (err) {
    console.warn('Transcribe model fallback to gemini-3.8-flash:', err);
    const data = await generate({
      model: 'gemini-3.8-flash',
      contents: [
        userTurn([
          audioPart,
          { text: 'فرغ هذا التسجيل الصوتي إلى نص مكتوب دقيق ومفصل باللغة العربية.' },
        ]),
      ],
    });
    transcript = textOf(data);
  }

  const summaryData = await generate({
    model: 'gemini-3.8-flash',
    contents: [
      userTurn([
        {
          text: `بصفتك الأستاذ "دارس" الصارم، قم بتحليل وتلخيص نص هذه المحاضرة الأكاديمية تلخيصاً شاملاً:
نص المحاضرة:
"""
${transcript || 'المحاضرة الصوتية المرفقة'}
"""

قم بإنشاء تلخيص منظم جداً يتضمن الآتي بصيغة Markdown واضحة:
# 📚 عنوان المحاضرة المقترح
## 🎯 المحاور والأفكار الجوهرية (في نقاط دقيقة)
## 📐 القوانين، المعادلات، والمصطلحات التأسيسية
## ⚠️ فخاخ امتحانية وتنبيهات الأستاذ الصارم
## ❓ 3 أسئلة امتحانية نموذجية مع إجاباتها النموذجية المختصرة
## 📝 نصيحة الأستاذ النهائية لمراجعة هذا الدرس`,
        },
      ]),
    ],
    systemInstruction: STRICT_TUTOR_SYSTEM_PROMPT,
    generationConfig: { temperature: 0.3 },
  });

  return {
    transcript,
    summary: textOf(summaryData) || 'تم التفريغ بنجاح ولكن تعذر إنشاء التلخيص.',
  };
}

export async function preparePdfAudioLesson(
  pdfFile: File,
  topicTitle: string
): Promise<{ lessonTitle: string; tracks: AudioLessonTrack[] }> {
  const pdfBase64 = await fileToBase64(pdfFile);

  const outlinePrompt = `أنت أستاذ أكاديمي متخصص. بناءً على ملف الـ PDF المرفق، نريد إعداد "حصة صوتية متكاملة" عن موضوع: "${topicTitle}".
يجب تقسيم الحصة إلى 3 محاور متسلسلة بدقة.
لكل محور، اكتب السيناريو المنطوق باللغة العربية الفصحى كمعلم يشرح لطلابه بنبرة جادة وواضحة (حوالي 80-120 كلمة لكل محور تكون سهلة النطق ومفيدة جداً).

أعد النتيجة بصيغة JSON حصراً مطابقة للنمط التالي:
{
  "lessonTitle": "عنوان الدرس الدقيق",
  "tracks": [
    { "id": 1, "title": "المحور الأول: مقدمة ومفاهيم أساسية", "script": "النص المنطوق بالعربية الفصحى..." },
    { "id": 2, "title": "المحور الثاني: الشرح العميق والقوانين", "script": "النص المنطوق بالعربية الفصحى..." },
    { "id": 3, "title": "المحور الثالث: خلاصة وتطبيقات امتحانية", "script": "النص المنطوق بالعربية الفصحى..." }
  ]
}`;

  const outline = await generate({
    model: 'gemini-3.8-flash',
    contents: [
      userTurn([
        { inlineData: { mimeType: 'application/pdf', data: pdfBase64 } },
        { text: outlinePrompt },
      ]),
    ],
    generationConfig: { responseMimeType: 'application/json' },
  });

  let lessonData: any;
  try {
    lessonData = parseJson(textOf(outline));
  } catch {
    lessonData = {
      lessonTitle: topicTitle,
      tracks: [
        {
          id: 1,
          title: 'المحور الأول: المفاهيم الأساسية',
          script: `أهلاً بكم في درس اليوم عن ${topicTitle}. لنبدأ بالتركيز في المفاهيم التأسيسية التي لا غنى عنها في أي اختبار.`,
        },
        {
          id: 2,
          title: 'المحور الثاني: القوانين والشرح التفصيلي',
          script: `ننتقل الآن إلى القوانين الحاكمة للمسألة. دققوا في طريقة التطبيق والخطوات المنهجية للوصول للناتج الدقيق.`,
        },
        {
          id: 3,
          title: 'المحور الثالث: الخلاصة والوصايا الامتحانية',
          script: `ختاماً، انتبهوا للأخطاء الشائعة وحافظوا على تنظيم ورقة الإجابة لتحصيل الدرجة النهائية بإذن الله.`,
        },
      ],
    };
  }

  // كل المحاور بتتولد في نفس الوقت بدل ما تستنى بعض
  const tracks: AudioLessonTrack[] = await Promise.all(
    (lessonData.tracks || []).map(async (track: any) => {
      let audioBase64 = '';
      try {
        audioBase64 = await synthesize(track.script, 'Fenrir');
      } catch (err) {
        console.warn(`TTS notice for track ${track.id}:`, err);
      }
      return { ...track, audioBase64, mimeType: 'audio/wav' } as AudioLessonTrack;
    })
  );

  return {
    lessonTitle: lessonData.lessonTitle || topicTitle,
    tracks,
  };
}

export async function synthesizeAudioTrack(
  text: string,
  voiceName: string = 'Fenrir'
): Promise<{ audioBase64: string; mimeType: string }> {
  if (!text) throw new Error('النص مطلوب للتوليد الصوتي.');
  const audioBase64 = await synthesize(text.slice(0, 800), voiceName || 'Fenrir');
  return { audioBase64, mimeType: 'audio/wav' };
}

export async function generateInfographicData(
  topic: string,
  content: string
): Promise<InfographicData> {
  const draftPrompt = `أنت مصمم بطاقات إنفوجرافيك أكاديمية فاخرة. بناءً على هذا المحتوى الأكاديمي:
"""
${content || topic}
"""

استخرج ونظم بطاقة إنفوجرافيك بصرية فائقة الأهمية للاختبارات بصيغة JSON مطابقة للنمط التالي:
{
  "title": "عنوان الإنفوجرافيك الرئيسي",
  "subject": "المادة أو المجال (مثلاً: الفيزياء / الرياضيات / الكيمياء / التاريخ)",
  "keyConcepts": [
    {"label": "المفهوم 1", "desc": "شرح مكثف في سطرين"},
    {"label": "المفهوم 2", "desc": "شرح مكثف في سطرين"},
    {"label": "المفهوم 3", "desc": "شرح مكثف في سطرين"}
  ],
  "goldenRules": [
    "القانون أو القاعدة الذهبية 1",
    "القانون أو القاعدة الذهبية 2"
  ],
  "examTraps": [
    "تنبيه امتحاني حاسم لتجنب فقدان الدرجات 1",
    "تنبيه امتحاني حاسم 2"
  ],
  "tutorVerdict": "وصية الأستاذ الصارم لتحقيق العلامة الكاملة في هذا الموضوع."
}`;

  const data = await generate({
    model: 'gemini-3.8-flash',
    contents: [userTurn([{ text: draftPrompt }])],
    generationConfig: { responseMimeType: 'application/json' },
  });

  return parseJson(textOf(data)) as InfographicData;
}
