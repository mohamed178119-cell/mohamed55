import { useState } from 'react';
import { getStoredGeminiKey, setStoredGeminiKey } from '../services/api';

export function GeminiKeyButton() {
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState(getStoredGeminiKey());
  const [saved, setSaved] = useState(false);

  const save = () => {
    setStoredGeminiKey(value.trim());
    setSaved(true);
    setTimeout(() => {
      setSaved(false);
      setOpen(false);
    }, 800);
  };

  const clear = () => {
    setStoredGeminiKey('');
    setValue('');
  };

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="fixed bottom-3 left-3 z-40 px-3 py-2 text-xs font-semibold rounded-lg bg-slate-800 text-amber-400 border border-amber-500/30 shadow-lg"
      >
        🔑 مفتاح Gemini
      </button>

      {open && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4"
          onClick={() => setOpen(false)}
        >
          <div
            dir="rtl"
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-sm rounded-xl bg-slate-900 border border-slate-700 p-5 space-y-3"
          >
            <h3 className="font-bold text-white">مفتاح Gemini</h3>
            <p className="text-xs text-slate-400">
              الصق المفتاح هنا مرة واحدة، وهيتحفظ على الجهاز ومتحتاجش تكتبه تاني.
            </p>
            <input
              type="password"
              value={value}
              onChange={(e) => setValue(e.target.value)}
              placeholder="AIza..."
              className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white text-sm outline-none focus:border-amber-500"
            />
            <div className="flex gap-2">
              <button
                onClick={save}
                className="flex-1 py-2 rounded-lg bg-amber-500 text-slate-950 font-semibold text-sm"
              >
                حفظ
              </button>
              <button
                onClick={clear}
                className="px-3 py-2 rounded-lg bg-slate-800 text-slate-300 text-sm border border-slate-700"
              >
                مسح
              </button>
            </div>
            {saved && <p className="text-xs text-emerald-400">تم الحفظ ✅</p>}
          </div>
        </div>
      )}
    </>
  );
}
