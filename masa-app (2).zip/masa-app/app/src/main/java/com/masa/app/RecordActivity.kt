package com.masa.app

import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import java.io.File

class RecordActivity : AppCompatActivity() {

    private var recorder: MediaRecorder? = null
    private var isRecording = false
    private var outputFile: File? = null

    private lateinit var btnToggle: MaterialButton
    private lateinit var tvStatus: TextView

    private val requestPermissionLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startRecording() else
                Toast.makeText(this, "لازم إذن الميكروفون عشان تسجل", Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_record)

        btnToggle = findViewById(R.id.btnRecordToggle)
        tvStatus = findViewById(R.id.tvStatus)

        btnToggle.setOnClickListener {
            if (!isRecording) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                    == PackageManager.PERMISSION_GRANTED
                ) {
                    startRecording()
                } else {
                    requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            } else {
                stopRecordingAndSummarize()
            }
        }
    }

    private fun startRecording() {
        try {
            outputFile = File(cacheDir, "lecture_${System.currentTimeMillis()}.m4a")
            recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(this)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setOutputFile(outputFile!!.absolutePath)
                prepare()
                start()
            }
            isRecording = true
            btnToggle.text = "إيقاف التسجيل والتلخيص"
            tvStatus.text = "بيسجل دلوقتي... اتكلم بارتياح، اضغط \"إيقاف\" لما تخلص."
        } catch (e: Exception) {
            Toast.makeText(this, "تعذر بدء التسجيل: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopRecordingAndSummarize() {
        try {
            recorder?.apply {
                stop()
                release()
            }
        } catch (e: Exception) {
            // ignore stop errors on very short recordings
        }
        recorder = null
        isRecording = false
        btnToggle.text = "بدء التسجيل"
        btnToggle.isEnabled = false
        tvStatus.text = "بيتم تجهيز الملخص..."

        val file = outputFile
        if (file == null || !file.exists()) {
            tvStatus.text = "حصل خطأ، الملف مش موجود."
            btnToggle.isEnabled = true
            return
        }

        val bytes = file.readBytes()
        if (bytes.size > 18 * 1024 * 1024) {
            tvStatus.text = "التسجيل طويل جدًا (أكبر من الحد المسموح). جرب تسجيل أقصر."
            btnToggle.isEnabled = true
            return
        }

        GeminiClient.summarizeAudio(bytes, "audio/mp4", object : GeminiClient.ResultCallback {
            override fun onSuccess(text: String) {
                runOnUiThread {
                    tvStatus.text = text
                    btnToggle.isEnabled = true
                }
            }

            override fun onError(message: String) {
                runOnUiThread {
                    tvStatus.text = "حصل خطأ في التلخيص: $message"
                    btnToggle.isEnabled = true
                }
            }
        })
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isRecording) {
            try {
                recorder?.stop()
                recorder?.release()
            } catch (_: Exception) {
            }
        }
    }
}
