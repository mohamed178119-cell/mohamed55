package com.masa.app

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<com.google.android.material.button.MaterialButton>(R.id.btnUpload)
            .setOnClickListener {
                startActivity(Intent(this, UploadActivity::class.java))
            }

        findViewById<com.google.android.material.button.MaterialButton>(R.id.btnRecord)
            .setOnClickListener {
                startActivity(Intent(this, RecordActivity::class.java))
            }
    }
}
