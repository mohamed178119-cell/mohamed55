package com.masa.app

import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ChatActivity : AppCompatActivity() {

    private lateinit var recycler: RecyclerView
    private lateinit var editMessage: EditText
    private lateinit var adapter: ChatAdapter
    private val messages = mutableListOf<ChatMessage>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        if (!AppState.hasDocument()) {
            Toast.makeText(this, "لازم ترفع ملف الأول", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        recycler = findViewById(R.id.recyclerChat)
        editMessage = findViewById(R.id.editMessage)
        val btnSend = findViewById<android.widget.Button>(R.id.btnSend)

        adapter = ChatAdapter(messages)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        addMessage("اتفضل، ابدأ اسألني في أي حاجة من الملف اللي رفعته: ${AppState.fileName ?: ""}", isUser = false)

        btnSend.setOnClickListener {
            val question = editMessage.text.toString().trim()
            if (question.isEmpty()) return@setOnClickListener
            addMessage(question, isUser = true)
            editMessage.setText("")
            askGemini(question)
        }
    }

    private fun askGemini(question: String) {
        val thinkingMsg = ChatMessage("...بفكر", isUser = false)
        addMessage(thinkingMsg.text, isUser = false)
        val thinkingIndex = messages.size - 1

        GeminiClient.askAboutDocument(question, object : GeminiClient.ResultCallback {
            override fun onSuccess(text: String) {
                runOnUiThread {
                    messages[thinkingIndex] = ChatMessage(text, isUser = false)
                    adapter.notifyItemChanged(thinkingIndex)
                }
            }

            override fun onError(message: String) {
                runOnUiThread {
                    messages[thinkingIndex] = ChatMessage("حصل خطأ: $message", isUser = false)
                    adapter.notifyItemChanged(thinkingIndex)
                }
            }
        })
    }

    private fun addMessage(text: String, isUser: Boolean) {
        adapter.addMessage(ChatMessage(text, isUser))
        recycler.scrollToPosition(messages.size - 1)
    }
}
