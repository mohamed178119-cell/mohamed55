package com.masa.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class UploadActivity : AppCompatActivity() {

    private lateinit var tvFileName: TextView
    private lateinit var btnStartChat: MaterialButton

    private val pickFileLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) handlePickedFile(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_upload)

        tvFileName = findViewById(R.id.tvFileName)
        btnStartChat = findViewById(R.id.btnStartChat)

        findViewById<MaterialButton>(R.id.btnPickFile).setOnClickListener {
            pickFileLauncher.launch(arrayOf("application/pdf", "image/*"))
        }

        btnStartChat.setOnClickListener {
            startActivity(Intent(this, ChatActivity::class.java))
        }
    }

    private fun handlePickedFile(uri: Uri) {
        try {
            val mimeType = contentResolver.getType(uri) ?: "application/octet-stream"
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
            if (bytes == null) {
                Toast.makeText(this, "تعذر قراءة الملف", Toast.LENGTH_SHORT).show()
                return
            }
            // 18MB safety cap (Gemini inline data limit is ~20MB base64-encoded).
            if (bytes.size > 18 * 1024 * 1024) {
                Toast.makeText(this, "الملف كبير جدًا، اختار ملف أصغر من 18 ميجا", Toast.LENGTH_LONG).show()
                return
            }

            AppState.clearDocument()
            AppState.fileBytes = bytes
            AppState.fileMimeType = mimeType
            AppState.fileName = queryFileName(uri)

            tvFileName.text = "تم اختيار: ${AppState.fileName ?: "ملف"}"
            btnStartChat.isEnabled = true
        } catch (e: Exception) {
            Toast.makeText(this, "خطأ في تحميل الملف: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun queryFileName(uri: Uri): String? {
        var name: String? = null
        val cursor = contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                val idx = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) name = it.getString(idx)
            }
        }
        return name
    }
}
