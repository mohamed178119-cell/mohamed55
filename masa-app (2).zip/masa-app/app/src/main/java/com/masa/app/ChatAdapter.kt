package com.masa.app

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ChatAdapter(private val messages: MutableList<ChatMessage>) :
    RecyclerView.Adapter<ChatAdapter.MessageViewHolder>() {

    class MessageViewHolder(val root: LinearLayout, val textView: TextView) :
        RecyclerView.ViewHolder(root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_chat_message, parent, false) as LinearLayout
        val textView = view.findViewById<TextView>(R.id.tvMessage)
        return MessageViewHolder(view, textView)
    }

    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        val message = messages[position]
        holder.textView.text = message.text

        val bg = GradientDrawable()
        bg.cornerRadius = 24f
        val params = holder.root.layoutParams
        if (message.isUser) {
            holder.root.gravity = Gravity.START
            bg.setColor(Color.parseColor("#DCF8C6"))
        } else {
            holder.root.gravity = Gravity.END
            bg.setColor(Color.parseColor("#EDEDED"))
        }
        holder.textView.background = bg
        holder.root.layoutParams = params
    }

    override fun getItemCount(): Int = messages.size

    fun addMessage(message: ChatMessage) {
        messages.add(message)
        notifyItemInserted(messages.size - 1)
    }
}
