package com.masa.app

data class ChatMessage(
    val text: String,
    val isUser: Boolean
)
