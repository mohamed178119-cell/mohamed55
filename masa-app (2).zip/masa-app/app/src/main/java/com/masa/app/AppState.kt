package com.masa.app

import org.json.JSONArray

/**
 * In-memory singleton shared across activities.
 * Holds the uploaded document (PDF/image) and the running chat history
 * sent to Gemini so the conversation stays grounded in that document.
 */
object AppState {

    var fileBytes: ByteArray? = null
    var fileMimeType: String? = null
    var fileName: String? = null

    // Gemini "contents" array (role + parts) built up turn by turn.
    val geminiHistory: JSONArray = JSONArray()

    fun clearDocument() {
        fileBytes = null
        fileMimeType = null
        fileName = null
        while (geminiHistory.length() > 0) {
            geminiHistory.remove(0)
        }
    }

    fun hasDocument(): Boolean = fileBytes != null
}
