package com.wasla.app

import android.content.Context
import kotlin.random.Random

object Prefs {
    private const val FILE = "wasla_prefs"
    private const val KEY_CODE = "my_code"

    fun getMyCode(context: Context): String {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        var code = sp.getString(KEY_CODE, null)
        if (code == null) {
            code = generateCode()
            sp.edit().putString(KEY_CODE, code).apply()
        }
        return code
    }

    private fun generateCode(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        fun part(n: Int) = (1..n).map { chars[Random.nextInt(chars.length)] }.joinToString("")
        return "${part(3)}-${part(2)}${part(1)}"
    }
}
