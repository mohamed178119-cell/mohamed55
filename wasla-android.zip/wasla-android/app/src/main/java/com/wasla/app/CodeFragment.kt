package com.wasla.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment

class CodeFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_code, container, false)

        val myCode = Prefs.getMyCode(requireContext())
        SocketManager.connect(myCode)

        view.findViewById<TextView>(R.id.myCodeText).text = myCode

        view.findViewById<Button>(R.id.copyCodeBtn).setOnClickListener {
            val clipboard = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("code", myCode))
            Toast.makeText(requireContext(), "تم نسخ الكود", Toast.LENGTH_SHORT).show()
        }

        return view
    }
}
