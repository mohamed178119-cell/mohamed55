package com.wasla.app

import android.os.Handler
import android.os.Looper

object ChatRepository {

    val chats: MutableList<Chat> = mutableListOf()
    private val listeners = mutableListOf<() -> Unit>()
    private val mainHandler = Handler(Looper.getMainLooper())

    fun addListener(listener: () -> Unit) {
        listeners.add(listener)
    }

    fun removeListener(listener: () -> Unit) {
        listeners.remove(listener)
    }

    private fun notifyChanged() {
        mainHandler.post {
            listeners.forEach { it() }
        }
    }

    fun findChat(chatId: String): Chat? = chats.find { it.chatId == chatId }

    fun addOutgoing(chatId: String, toCode: String) {
        chats.add(0, Chat(chatId, "كود $toCode", false, "pending_outgoing", peerCode = toCode))
        notifyChanged()
    }

    fun addIncoming(chatId: String, fromCode: String) {
        chats.add(0, Chat(chatId, "كود $fromCode", false, "pending_incoming", peerCode = fromCode))
        notifyChanged()
    }

    fun addGroup(chatId: String, name: String) {
        chats.add(0, Chat(chatId, name, true, "active"))
        notifyChanged()
    }

    fun updateResponse(chatId: String, accepted: Boolean) {
        val chat = findChat(chatId) ?: return
        if (accepted) {
            chat.status = "active"
        } else {
            chats.remove(chat)
        }
        notifyChanged()
    }

    fun acceptIncoming(chatId: String) {
        val chat = findChat(chatId) ?: return
        chat.status = "active"
        notifyChanged()
    }

    fun rejectIncoming(chatId: String) {
        chats.removeAll { it.chatId == chatId }
        notifyChanged()
    }

    fun addOutgoingMessage(chatId: String, text: String) {
        findChat(chatId)?.messages?.add(Message(true, text))
        notifyChanged()
    }

    fun addIncomingMessage(chatId: String, text: String) {
        findChat(chatId)?.messages?.add(Message(false, text))
        notifyChanged()
    }
}
