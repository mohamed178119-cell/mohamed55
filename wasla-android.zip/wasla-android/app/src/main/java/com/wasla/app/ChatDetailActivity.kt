package com.wasla.app

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ChatDetailActivity : AppCompatActivity() {

    private lateinit var chatId: String
    private lateinit var recycler: RecyclerView
    private lateinit var approvalBanner: View
    private lateinit var waitingNote: View
    private lateinit var messageInput: EditText
    private lateinit var sendBtn: Button

    private val listener: () -> Unit = { render() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat_detail)

        chatId = intent.getStringExtra("chatId") ?: return finish()

        recycler = findViewById(R.id.messagesRecycler)
        recycler.layoutManager = LinearLayoutManager(this)
        approvalBanner = findViewById(R.id.approvalBanner)
        waitingNote = findViewById(R.id.waitingNote)
        messageInput = findViewById(R.id.messageInput)
        sendBtn = findViewById(R.id.sendBtn)

        findViewById<Button>(R.id.acceptBtn).setOnClickListener {
            val chat = ChatRepository.findChat(chatId) ?: return@setOnClickListener
            ChatRepository.acceptIncoming(chatId)
            SocketManager.respond(chatId, chat.peerCode, true)
        }
        findViewById<Button>(R.id.rejectBtn).setOnClickListener {
            val chat = ChatRepository.findChat(chatId) ?: return@setOnClickListener
            SocketManager.respond(chatId, chat.peerCode, false)
            ChatRepository.rejectIncoming(chatId)
            finish()
        }
        sendBtn.setOnClickListener { sendMessage() }

        render()
    }

    override fun onResume() {
        super.onResume()
        ChatRepository.addListener(listener)
        render()
    }

    override fun onPause() {
        super.onPause()
        ChatRepository.removeListener(listener)
    }

    private fun sendMessage() {
        val text = messageInput.text.toString().trim()
        if (text.isEmpty()) return
        ChatRepository.addOutgoingMessage(chatId, text)
        SocketManager.sendMessage(chatId, text)
        messageInput.text.clear()
    }

    private fun render() {
        val chat = ChatRepository.findChat(chatId) ?: return finish()
        findViewById<TextView>(R.id.chatTitle).text = chat.name

        approvalBanner.visibility = if (chat.status == "pending_incoming") View.VISIBLE else View.GONE
        waitingNote.visibility = if (chat.status == "pending_outgoing") View.VISIBLE else View.GONE

        val canChat = chat.status == "active"
        messageInput.isEnabled = canChat
        sendBtn.isEnabled = canChat

        recycler.adapter = MessageAdapter(chat.messages)
        if (chat.messages.isNotEmpty()) {
            recycler.scrollToPosition(chat.messages.size - 1)
        }
    }
}
