package com.wasla.app

import io.socket.client.IO
import io.socket.client.Socket
import org.json.JSONArray
import org.json.JSONObject
import java.net.URISyntaxException
import java.util.UUID

object SocketManager {

    // غيّر الرابط ده لرابط السيرفر بتاعك بعد ما تعمله ديبلوي (خطوات الديبلوي في wasla-backend/README.md)
    const val BASE_URL = "https://YOUR-BACKEND-URL.onrender.com"

    private var socket: Socket? = null
    private var myCode: String = ""

    fun connect(code: String) {
        myCode = code
        if (socket != null) return
        try {
            socket = IO.socket(BASE_URL)
        } catch (e: URISyntaxException) {
            return
        }
        socket?.connect()

        socket?.on(Socket.EVENT_CONNECT) {
            val obj = JSONObject()
            obj.put("code", myCode)
            socket?.emit("register", obj)
        }

        socket?.on("incoming_request") { args ->
            val data = args[0] as JSONObject
            ChatRepository.addIncoming(data.getString("chatId"), data.getString("fromCode"))
        }

        socket?.on("request_response") { args ->
            val data = args[0] as JSONObject
            ChatRepository.updateResponse(data.getString("chatId"), data.getBoolean("accepted"))
        }

        socket?.on("new_message") { args ->
            val data = args[0] as JSONObject
            ChatRepository.addIncomingMessage(data.getString("chatId"), data.getString("text"))
        }

        socket?.on("group_invite") { args ->
            val data = args[0] as JSONObject
            ChatRepository.addGroup(data.getString("chatId"), data.getString("name"))
        }
    }

    fun newChatId(): String = UUID.randomUUID().toString()

    fun requestChat(toCode: String, chatId: String) {
        val obj = JSONObject()
        obj.put("fromCode", myCode)
        obj.put("toCode", toCode)
        obj.put("chatId", chatId)
        socket?.emit("request_chat", obj)
    }

    fun respond(chatId: String, fromCode: String, accepted: Boolean) {
        val obj = JSONObject()
        obj.put("chatId", chatId)
        obj.put("toCode", fromCode)
        obj.put("accepted", accepted)
        socket?.emit("respond_chat", obj)
    }

    fun sendMessage(chatId: String, text: String) {
        val obj = JSONObject()
        obj.put("chatId", chatId)
        obj.put("text", text)
        socket?.emit("send_message", obj)
    }

    fun createGroup(chatId: String, name: String, codes: List<String>) {
        val obj = JSONObject()
        obj.put("chatId", chatId)
        obj.put("name", name)
        obj.put("codes", JSONArray(codes + myCode))
        socket?.emit("create_group", obj)
    }
}
