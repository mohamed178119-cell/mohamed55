package com.wasla.app

data class Message(
    val fromMe: Boolean,
    val text: String
)

data class Chat(
    val chatId: String,
    var name: String,
    val isGroup: Boolean,
    var status: String, // pending_incoming | pending_outgoing | active
    val peerCode: String = "",
    val messages: MutableList<Message> = mutableListOf()
)
