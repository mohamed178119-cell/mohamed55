package com.wasla.app

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ChatAdapter(
    private val onClick: (Chat) -> Unit
) : RecyclerView.Adapter<ChatAdapter.VH>() {

    private var items: List<Chat> = emptyList()

    fun submit(list: List<Chat>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(view: android.view.View) : RecyclerView.ViewHolder(view) {
        val name: TextView = view.findViewById(R.id.chatName)
        val status: TextView = view.findViewById(R.id.chatStatus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_chat, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val chat = items[position]
        val prefix = if (chat.isGroup) "👥 " else ""
        holder.name.text = prefix + chat.name
        holder.status.text = when {
            chat.status == "pending_incoming" -> "في انتظار موافقتك على بدء المحادثة"
            chat.status == "pending_outgoing" -> "في انتظار موافقة الطرف الآخر"
            chat.messages.isNotEmpty() -> chat.messages.last().text
            else -> "لا توجد رسائل بعد"
        }
        holder.itemView.setOnClickListener { onClick(chat) }
    }

    override fun getItemCount(): Int = items.size
}
