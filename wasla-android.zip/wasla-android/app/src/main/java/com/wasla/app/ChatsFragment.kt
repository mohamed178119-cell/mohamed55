package com.wasla.app

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ChatsFragment : Fragment() {

    private lateinit var adapter: ChatAdapter
    private lateinit var emptyNote: TextView
    private val groupCodes = mutableListOf<String>()

    private val listener: () -> Unit = { refresh() }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_chats, container, false)

        emptyNote = view.findViewById(R.id.emptyNote)
        val recycler = view.findViewById<RecyclerView>(R.id.chatsRecycler)
        recycler.layoutManager = LinearLayoutManager(requireContext())
        adapter = ChatAdapter { chat -> openChat(chat) }
        recycler.adapter = adapter

        view.findViewById<Button>(R.id.enterCodeBtn).setOnClickListener { showEnterCodeDialog() }
        view.findViewById<Button>(R.id.createGroupBtn).setOnClickListener { showCreateGroupDialog() }

        refresh()
        return view
    }

    override fun onResume() {
        super.onResume()
        ChatRepository.addListener(listener)
        refresh()
    }

    override fun onPause() {
        super.onPause()
        ChatRepository.removeListener(listener)
    }

    private fun refresh() {
        adapter.submit(ChatRepository.chats)
        emptyNote.visibility = if (ChatRepository.chats.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun openChat(chat: Chat) {
        val intent = Intent(requireContext(), ChatDetailActivity::class.java)
        intent.putExtra("chatId", chat.chatId)
        startActivity(intent)
    }

    private fun showEnterCodeDialog() {
        val input = EditText(requireContext())
        input.hint = "اكتب الكود اللي معاك"
        AlertDialog.Builder(requireContext())
            .setTitle("أدخل كود")
            .setView(input)
            .setPositiveButton("إرسال طلب") { _, _ ->
                val code = input.text.toString().trim()
                if (code.isEmpty()) {
                    Toast.makeText(requireContext(), "اكتب كود الأول", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val chatId = SocketManager.newChatId()
                ChatRepository.addOutgoing(chatId, code)
                SocketManager.requestChat(code, chatId)
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun showCreateGroupDialog() {
        groupCodes.clear()
        val layout = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_create_group, null)
        val nameInput = layout.findViewById<EditText>(R.id.groupNameInput)
        val codeInput = layout.findViewById<EditText>(R.id.groupCodeInputDialog)
        val addedText = layout.findViewById<TextView>(R.id.groupCodesAdded)
        layout.findViewById<Button>(R.id.addCodeBtn).setOnClickListener {
            val c = codeInput.text.toString().trim()
            if (c.isNotEmpty()) {
                groupCodes.add(c)
                codeInput.text.clear()
                addedText.text = groupCodes.joinToString("  ,  ")
            }
        }

        AlertDialog.Builder(requireContext())
            .setTitle("أنشئ مجموعة")
            .setView(layout)
            .setPositiveButton("إنشاء") { _, _ ->
                val name = nameInput.text.toString().trim()
                if (name.isEmpty()) {
                    Toast.makeText(requireContext(), "اكتب اسم للمجموعة", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                if (groupCodes.size < 2) {
                    Toast.makeText(requireContext(), "ضيف كودين على الأقل", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val chatId = SocketManager.newChatId()
                ChatRepository.addGroup(chatId, name)
                SocketManager.createGroup(chatId, name, groupCodes.toList())
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }
}
