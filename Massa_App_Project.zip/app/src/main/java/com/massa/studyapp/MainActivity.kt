package com.massa.studyapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.ai.client.generativeai.GenerativeModel

class MainActivity : ComponentActivity() {

    private val generativeModel by lazy {
        GenerativeModel(
            modelName = "gemini-1.5-flash",
            apiKey = BuildConfig.GEMINI_API_KEY,
            systemInstruction = com.google.ai.client.generativeai.type.content {
                text("أنت مساعد تعليمي اسمه 'ماسا'. وظيفتك الإجابة فقط على الأسئلة المتعلقة بملفات الشرح والتسجيلات المرفوعة. يمنع منعاً باتاً الإجابة على أي أسئلة خارج نطاق الدراسية والمذاكرة.")
            }
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                MassaMainScreen(generativeModel)
            }
        }
    }
}

@Composable
fun MassaMainScreen(model: GenerativeModel) {
    var selectedTab by remember { mutableIntStateOf(0) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    label = { Text("الملفات والحل") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    label = { Text("الشات") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    label = { Text("تلخيص الحصص") }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.Center
        ) {
            when (selectedTab) {
                0 -> FileUploadScreen()
                1 -> ChatScreen(model)
                2 -> AudioRecordingScreen()
            }
        }
    }
}

@Composable
fun FileUploadScreen() {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("شاشة رفع الـ PDF والصور")
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = { /* اختر كتاب أو صورة */ }) {
            Text("اختر كتاب أو صورة واجب")
        }
    }
}

@Composable
fun ChatScreen(model: GenerativeModel) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("شاشة الشات والمساعد الدراسي - ماسا")
    }
}

@Composable
fun AudioRecordingScreen() {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("تسجيل وتلخيص الحصص")
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = { /* بدء التسجيل */ }) {
            Text("بدء تسجيل الحصة")
        }
    }
}
