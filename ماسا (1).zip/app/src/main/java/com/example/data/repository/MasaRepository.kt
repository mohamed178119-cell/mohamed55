package com.example.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import com.example.BuildConfig
import com.example.data.api.Content
import com.example.data.api.GenerateContentRequest
import com.example.data.api.GenerationConfig
import com.example.data.api.InlineData
import com.example.data.api.Part
import com.example.data.api.RetrofitClient
import com.example.data.db.ChatMessage
import com.example.data.db.LectureRecording
import com.example.data.db.MasaDatabase
import com.example.data.db.StudyDocument
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.InputStream

class MasaRepository(private val context: Context) {
    private val db = MasaDatabase.getDatabase(context)
    private val studyDao = db.studyDao()
    private val chatDao = db.chatDao()
    private val lectureDao = db.lectureDao()

    val allDocuments: Flow<List<StudyDocument>> = studyDao.getAllDocuments()
    val allMessages: Flow<List<ChatMessage>> = chatDao.getAllMessages()
    val allLectures: Flow<List<LectureRecording>> = lectureDao.getAllLectures()

    companion object {
        const val STUDY_GUARDRAIL_SYSTEM_PROMPT =
            "أنت 'ماسا' (Masa)، المساعد الدراسي والتعليمي الذكي للطلاب والمذاكرة. " +
                    "مهمتك الأساسية هي الإجابة فقط وحصرياً على الأسئلة الدراسية، الشرح التعليمي، حل المسائل، وتلخيص المستندات والكتب والتسجيلات. " +
                    "ضوابط صارمة: يُمنع منعاً باتاً الإجابة على أي أسئلة خارج نطاق الدراسة والمذاكرة والتعليم (مثل الرياضة العامة غير الفيزيائية، السياسة، أو الدردشة العادية). " +
                    "إذا طرح المستخدم سؤالاً غير دراسي، أجب فوراً باللغة العربية: 'عذراً، أنا ماسا المساعد الدراسي المخصص للمذاكرة والتعليم فقط. يسعدني إجابتك على أي سؤال دراسي أو شرح درس!'"
    }

    suspend fun saveDocument(doc: StudyDocument): Long = withContext(Dispatchers.IO) {
        studyDao.insertDocument(doc)
    }

    suspend fun deleteDocument(id: Long) = withContext(Dispatchers.IO) {
        studyDao.deleteDocument(id)
    }

    suspend fun saveMessage(msg: ChatMessage): Long = withContext(Dispatchers.IO) {
        chatDao.insertMessage(msg)
    }

    suspend fun clearChat() = withContext(Dispatchers.IO) {
        chatDao.clearChatHistory()
    }

    suspend fun saveLecture(lecture: LectureRecording): Long = withContext(Dispatchers.IO) {
        lectureDao.insertLecture(lecture)
    }

    suspend fun deleteLecture(id: Long) = withContext(Dispatchers.IO) {
        lectureDao.deleteLecture(id)
    }

    suspend fun askMasa(
        userPrompt: String,
        documentContext: String? = null,
        base64Image: String? = null,
        base64Audio: String? = null,
        mimeType: String? = null,
        customApiKey: String? = null
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val keyFromCustom = customApiKey?.trim()
            val apiKey = if (!keyFromCustom.isNullOrBlank() && keyFromCustom != "MY_GEMINI_API_KEY") {
                keyFromCustom
            } else {
                BuildConfig.GEMINI_API_KEY
            }

            if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
                return@withContext Result.failure(
                    Exception("مفتاح Gemini API غير مكوّن. يرجى توفيره أو ضبطه في الإعدادات.")
                )
            }

            val partsList = mutableListOf<Part>()

            // Include document context if selected
            if (!documentContext.isNullOrBlank()) {
                partsList.add(Part(text = "محتوى المستند الدراسي المرفق:\n$documentContext\n---"))
            }

            // Include base64 image or file if attached
            if (!base64Image.isNullOrBlank()) {
                val type = mimeType ?: "image/jpeg"
                partsList.add(Part(inlineData = InlineData(mimeType = type, data = base64Image)))
            }

            // Include base64 audio if attached
            if (!base64Audio.isNullOrBlank()) {
                val type = mimeType ?: "audio/mp3"
                partsList.add(Part(inlineData = InlineData(mimeType = type, data = base64Audio)))
            }

            partsList.add(Part(text = userPrompt))

            val systemInstruction = Content(
                parts = listOf(Part(text = STUDY_GUARDRAIL_SYSTEM_PROMPT))
            )

            val request = GenerateContentRequest(
                contents = listOf(Content(parts = partsList)),
                generationConfig = GenerationConfig(temperature = 0.2f),
                systemInstruction = systemInstruction
            )

            val response = RetrofitClient.service.generateContent(apiKey, request)

            if (response.error != null) {
                return@withContext Result.failure(
                    Exception("خطأ من Gemini API: ${response.error.message ?: "رمز الخطأ ${response.error.code}"}")
                )
            }

            val answerText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (!answerText.isNullOrBlank()) {
                Result.success(answerText)
            } else {
                Result.failure(Exception("لم يتم استلام رد من النموذج."))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun summarizeDocument(uri: Uri, fileName: String, fileType: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val contentResolver = context.contentResolver
            val inputStream: InputStream? = contentResolver.openInputStream(uri)
            val bytes = inputStream?.readBytes() ?: return@withContext Result.failure(Exception("عذراً، تعذر قراءة الملف."))

            val base64Data = Base64.encodeToString(bytes, Base64.NO_WRAP)
            val mimeType = when (fileType.uppercase()) {
                "PDF" -> "application/pdf"
                "IMAGE" -> contentResolver.getType(uri) ?: "image/jpeg"
                else -> "application/octet-stream"
            }

            val prompt = "قم بتلخيص هذا المستند التعليمي ($fileName) باللغة العربية باحترافية وسهولة للمذاكرة. " +
                    "اكتب: 1. الأفكار الرئيسية 2. المصطلحات والتعاريف المهمة 3. أسئلة مراجعة سريعة."

            val result = askMasa(
                userPrompt = prompt,
                base64Image = base64Data,
                mimeType = mimeType
            )

            result
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun uriToBase64(uri: Uri): String? {
        return try {
            val inputStream = context.contentResolver.openInputStream(uri)
            val bytes = inputStream?.readBytes()
            bytes?.let { Base64.encodeToString(it, Base64.NO_WRAP) }
        } catch (e: Exception) {
            null
        }
    }
}
