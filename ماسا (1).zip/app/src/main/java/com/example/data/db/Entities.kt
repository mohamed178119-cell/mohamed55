package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "study_documents")
data class StudyDocument(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val fileType: String, // "PDF" or "IMAGE"
    val fileUri: String,
    val fileSize: String = "",
    val extractedSummary: String = "",
    val uploadTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "chat_messages")
data class ChatMessage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val documentId: Long? = null,
    val sender: String, // "USER" or "MASA"
    val content: String,
    val imageUri: String? = null,
    val isStudyGuardrailNotice: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "lecture_recordings")
data class LectureRecording(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val audioPath: String = "",
    val durationSeconds: Int = 0,
    val summaryText: String = "",
    val keyPoints: String = "",
    val quizQuestions: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
