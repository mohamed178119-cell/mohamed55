package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface StudyDao {
    @Query("SELECT * FROM study_documents ORDER BY uploadTimestamp DESC")
    fun getAllDocuments(): Flow<List<StudyDocument>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDocument(doc: StudyDocument): Long

    @Query("DELETE FROM study_documents WHERE id = :id")
    suspend fun deleteDocument(id: Long)

    @Query("UPDATE study_documents SET extractedSummary = :summary WHERE id = :id")
    suspend fun updateDocumentSummary(id: Long, summary: String)
}

@Dao
interface ChatDao {
    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    fun getAllMessages(): Flow<List<ChatMessage>>

    @Query("SELECT * FROM chat_messages WHERE documentId = :docId ORDER BY timestamp ASC")
    fun getMessagesForDocument(docId: Long): Flow<List<ChatMessage>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(msg: ChatMessage): Long

    @Query("DELETE FROM chat_messages")
    suspend fun clearChatHistory()
}

@Dao
interface LectureDao {
    @Query("SELECT * FROM lecture_recordings ORDER BY timestamp DESC")
    fun getAllLectures(): Flow<List<LectureRecording>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLecture(lecture: LectureRecording): Long

    @Query("DELETE FROM lecture_recordings WHERE id = :id")
    suspend fun deleteLecture(id: Long)
}
