package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.ui.screens.HomeScreen
import com.example.ui.theme.MasaAppTheme
import com.example.ui.viewmodels.MasaViewModel

class MainActivity : ComponentActivity() {
    private val masaViewModel: MasaViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MasaAppTheme {
                HomeScreen(viewModel = masaViewModel)
            }
        }
    }
}
