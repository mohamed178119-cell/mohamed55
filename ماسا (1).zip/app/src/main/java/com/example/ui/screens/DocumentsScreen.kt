package com.example.ui.screens

import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.StudyDocument
import com.example.ui.theme.MasaAmber
import com.example.ui.theme.MasaPurple
import com.example.ui.theme.MasaPurpleLight
import com.example.ui.theme.MasaTeal
import com.example.ui.viewmodels.MasaViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentsScreen(
    viewModel: MasaViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val documents by viewModel.documents.collectAsState()
    val selectedDoc by viewModel.selectedDocument.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()

    var showDetailDialog by remember { mutableStateOf<StudyDocument?>(null) }

    // File Picker Launcher for PDF & Images
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { fileUri ->
            var fileName = "مستند_دراسي_${System.currentTimeMillis() / 1000}"
            var fileSizeStr = "ملف مخصص"

            context.contentResolver.query(fileUri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (cursor.moveToFirst()) {
                    if (nameIndex != -1) fileName = cursor.getString(nameIndex) ?: fileName
                    if (sizeIndex != -1) {
                        val sizeBytes = cursor.getLong(sizeIndex)
                        fileSizeStr = "${sizeBytes / 1024}  كيلوبايت"
                    }
                }
            }

            val type = if (fileName.lowercase().endsWith(".pdf")) "PDF" else "IMAGE"
            viewModel.addDocument(fileUri, fileName, type, fileSizeStr)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        // Banner Header
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = MasaPurple
            ),
            elevation = CardDefaults.cardElevation(4.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "📚 مكتبة المستندات والكتب",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "ارفع كتابك أو ملخصك بصيغة PDF أو صور ليقوم ماسا بتلخيصه ومساعدتك في المذاكرة.",
                        fontSize = 13.sp,
                        color = Color.White.copy(alpha = 0.9f),
                        lineHeight = 18.sp
                    )
                }
                Icon(
                    imageVector = Icons.Default.MenuBook,
                    contentDescription = "Books",
                    tint = MasaAmber,
                    modifier = Modifier.size(48.dp)
                )
            }
        }

        // Upload Buttons Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = { filePickerLauncher.launch("application/pdf") },
                modifier = Modifier
                    .weight(1f)
                    .height(52.dp)
                    .testTag("upload_pdf_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MasaPurple)
            ) {
                Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = MasaAmber)
                Spacer(modifier = Modifier.width(8.dp))
                Text("رفع كتاب PDF", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }

            OutlinedButton(
                onClick = { filePickerLauncher.launch("image/*") },
                modifier = Modifier
                    .weight(1f)
                    .height(52.dp)
                    .testTag("upload_image_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MasaPurple)
            ) {
                Icon(Icons.Default.Image, contentDescription = null, tint = MasaTeal)
                Spacer(modifier = Modifier.width(8.dp))
                Text("رفع صورة دراسية", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Selected Document Highlight Banner
        selectedDoc?.let { doc ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
                    .border(2.dp, MasaAmber, RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = MasaPurpleLight),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (doc.fileType == "PDF") Icons.Default.PictureAsPdf else Icons.Default.Image,
                                contentDescription = null,
                                tint = MasaPurple
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "المستند النشط حالياً: ${doc.title}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = MasaPurple,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(onClick = { viewModel.selectDocument(null) }) {
                            Icon(Icons.Default.Close, contentDescription = "إلغاء التحديد", tint = Color.Gray)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = { viewModel.selectTab(1) }, // Switch to Chat tab
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MasaTeal)
                    ) {
                        Icon(Icons.Default.Chat, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("اسأل ماسا عن هذا الكتاب الآن 💬", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Text(
            text = "المستندات المحملة (${documents.size})",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(vertical = 8.dp)
        )

        if (documents.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Outlined.FolderZip,
                        contentDescription = null,
                        tint = Color.Gray,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "لا توجد مستندات مرفوعة بعد",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "اضغط على الأزرار بالأعلى لرفع كتبك وأوراق المذاكرة.",
                        fontSize = 13.sp,
                        color = Color.Gray,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(documents, key = { it.id }) { doc ->
                    val isSelected = doc.id == selectedDoc?.id

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.selectDocument(doc) }
                            .testTag("document_card_${doc.id}"),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) MasaPurpleLight else MaterialTheme.colorScheme.surface
                        ),
                        elevation = CardDefaults.cardElevation(2.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(if (doc.fileType == "PDF") Color(0xFFFFEBEE) else Color(0xFFE0F2F1)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (doc.fileType == "PDF") Icons.Default.PictureAsPdf else Icons.Default.Image,
                                    contentDescription = null,
                                    tint = if (doc.fileType == "PDF") Color.Red else MasaTeal,
                                    modifier = Modifier.size(28.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = doc.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = doc.fileSize,
                                        fontSize = 12.sp,
                                        color = Color.Gray
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = SimpleDateFormat("dd MMM, hh:mm a", Locale("ar")).format(Date(doc.uploadTimestamp)),
                                        fontSize = 12.sp,
                                        color = Color.Gray
                                    )
                                }
                            }

                            Row {
                                IconButton(onClick = { showDetailDialog = doc }) {
                                    Icon(Icons.Default.Visibility, contentDescription = "عرض الملخص", tint = MasaPurple)
                                }
                                IconButton(onClick = { viewModel.deleteDocument(doc.id) }) {
                                    Icon(Icons.Default.DeleteOutline, contentDescription = "حذف", tint = Color.Red)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Summary Details Dialog
    showDetailDialog?.let { doc ->
        AlertDialog(
            onDismissRequest = { showDetailDialog = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MasaAmber)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "ملخص الكتاب: ${doc.title}", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 350.dp)
                ) {
                    Text(
                        text = doc.extractedSummary.ifBlank { "جاري إعداد الملخص من ماسا..." },
                        fontSize = 14.sp,
                        lineHeight = 22.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.selectDocument(doc)
                        showDetailDialog = null
                        viewModel.selectTab(1) // Go to chat
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MasaPurple)
                ) {
                    Text("ابدأ المحادثة حول هذا المستند 💬")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDetailDialog = null }) {
                    Text("إغلاق")
                }
            }
        )
    }
}
