package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.LectureRecording
import com.example.ui.theme.MasaAmber
import com.example.ui.theme.MasaPurple
import com.example.ui.theme.MasaPurpleDark
import com.example.ui.theme.MasaPurpleLight
import com.example.ui.theme.MasaTeal
import com.example.ui.viewmodels.MasaViewModel
import com.example.ui.viewmodels.RecordingStatus
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun LectureRecorderScreen(
    viewModel: MasaViewModel,
    modifier: Modifier = Modifier
) {
    val lectures by viewModel.lectures.collectAsState()
    val recordingStatus by viewModel.recordingStatus.collectAsState()
    val seconds by viewModel.recordingSeconds.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()

    var lectureTitle by remember { mutableStateOf("") }
    var expandedLectureId by remember { mutableStateOf<Long?>(null) }
    var selectedAudioUri by remember { mutableStateOf<Uri?>(null) }

    // Audio File Picker Launcher
    val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        selectedAudioUri = uri
    }

    val formatSeconds = { sec: Int ->
        val m = sec / 60
        val s = sec % 60
        String.format(Locale.US, "%02d:%02d", m, s)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        // Header
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MasaPurpleDark),
            elevation = CardDefaults.cardElevation(4.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "🎙️ تسجيل وتلخيص الحصص",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "سجل شرح المدرس أو المعلم في الفصل، وسيقوم ماسا بتلخيص الحصة واستخراج الأسئلة المتوقعة تلقائياً.",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.85f),
                        lineHeight = 18.sp
                    )
                }
                Icon(
                    Icons.Default.Mic,
                    contentDescription = null,
                    tint = MasaAmber,
                    modifier = Modifier.size(44.dp)
                )
            }
        }

        // Active Recorder Controls Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MasaPurpleLight)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                OutlinedTextField(
                    value = lectureTitle,
                    onValueChange = { lectureTitle = it },
                    label = { Text("عنوان الحصة أو المادة (مثال: رياضيات - الأحياء)") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("lecture_title_input"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(16.dp))

                if (recordingStatus == RecordingStatus.RECORDING) {
                    Text(
                        text = "⏱️ جاري تسجيل الحصة: ${formatSeconds(seconds)}",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Red
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Audio Wave Animation Simulation
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        repeat(7) { index ->
                            val height = remember(seconds) { (15..45).random().dp }
                            Box(
                                modifier = Modifier
                                    .width(6.dp)
                                    .height(height)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(MasaPurple)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { viewModel.stopAndSummarizeLecture(lectureTitle, selectedAudioUri) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("stop_recording_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Stop, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("إنهاء التسجيل وتلخيص الحصة مع ماسا ✨", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                } else if (recordingStatus == RecordingStatus.PROCESSING || isGenerating) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = MasaPurple)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "جاري تحليل التسجيل الصوتي وتوليد ملخص الحصة بواسطة ماسا...",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = MasaPurple
                        )
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = { viewModel.startRecording() },
                            colors = ButtonDefaults.buttonColors(containerColor = MasaPurple),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("start_recording_button"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.FiberManualRecord, contentDescription = null, tint = Color.Red)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("بدء تسجيل الحصة", fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = { audioPickerLauncher.launch("audio/*") },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.AudioFile, contentDescription = null, tint = MasaTeal)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("اختيار ملف صوتي", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    selectedAudioUri?.let { uri ->
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MasaTeal)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تم تحديد ملف صوتي جاهز للتلخيص!", fontSize = 12.sp, color = MasaTeal, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.weight(1f))
                            Button(
                                onClick = { viewModel.stopAndSummarizeLecture(lectureTitle, uri) },
                                colors = ButtonDefaults.buttonColors(containerColor = MasaTeal),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("لخّص الصوت")
                            }
                        }
                    }
                }
            }
        }

        Text(
            text = "ملخصات الحصص السابقة (${lectures.size})",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(vertical = 8.dp)
        )

        if (lectures.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Outlined.GraphicEq, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(56.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("لا توجد حصص مسجلة بعد", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("اضغط 'بدء تسجيل الحصة' أثناء شرح المدرس لتلخيصها فوراً.", fontSize = 12.sp, color = Color.Gray)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(lectures, key = { it.id }) { lecture ->
                    val isExpanded = expandedLectureId == lecture.id

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        elevation = CardDefaults.cardElevation(2.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(CircleShape)
                                            .background(MasaPurpleLight),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Mic, contentDescription = null, tint = MasaPurple)
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = lecture.title,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "مدة التسجيل: ${lecture.durationSeconds} ثانية • ${
                                                SimpleDateFormat("dd/MM/yyyy - hh:mm a", Locale("ar")).format(Date(lecture.timestamp))
                                            }",
                                            fontSize = 11.sp,
                                            color = Color.Gray
                                        )
                                    }
                                }

                                Row {
                                    IconButton(onClick = { expandedLectureId = if (isExpanded) null else lecture.id }) {
                                        Icon(
                                            imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                            contentDescription = "توسيع",
                                            tint = MasaPurple
                                        )
                                    }
                                    IconButton(onClick = { viewModel.deleteLecture(lecture.id) }) {
                                        Icon(Icons.Default.DeleteOutline, contentDescription = "حذف", tint = Color.Red)
                                    }
                                }
                            }

                            AnimatedVisibility(visible = isExpanded) {
                                Column(modifier = Modifier.padding(top = 12.dp)) {
                                    Divider(color = Color.LightGray.copy(alpha = 0.5f))
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        text = "📑 ملخص وتفريغ ماسا للحصة:",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = MasaPurple
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = lecture.summaryText,
                                        fontSize = 13.sp,
                                        lineHeight = 20.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
