package com.example.ui.viewmodels

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.ChatMessage
import com.example.data.db.LectureRecording
import com.example.data.db.StudyDocument
import com.example.data.repository.MasaRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class RecordingStatus {
    IDLE, RECORDING, PROCESSING
}

class MasaViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = MasaRepository(application)

    val documents: StateFlow<List<StudyDocument>> = repository.allDocuments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val messages: StateFlow<List<ChatMessage>> = repository.allMessages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val lectures: StateFlow<List<LectureRecording>> = repository.allLectures
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedDocument = MutableStateFlow<StudyDocument?>(null)
    val selectedDocument: StateFlow<StudyDocument?> = _selectedDocument.asStateFlow()

    private val _activeTab = MutableStateFlow(0) // 0: Documents, 1: Chat, 2: Audio, 3: Settings
    val activeTab: StateFlow<Int> = _activeTab.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _statusText = MutableStateFlow<String?>(null)
    val statusText: StateFlow<String?> = _statusText.asStateFlow()

    private val _recordingStatus = MutableStateFlow(RecordingStatus.IDLE)
    val recordingStatus: StateFlow<RecordingStatus> = _recordingStatus.asStateFlow()

    private val _recordingSeconds = MutableStateFlow(0)
    val recordingSeconds: StateFlow<Int> = _recordingSeconds.asStateFlow()

    private var timerJob: Job? = null

    private val _customApiKey = MutableStateFlow("")
    val customApiKey: StateFlow<String> = _customApiKey.asStateFlow()

    fun selectTab(tab: Int) {
        _activeTab.value = tab
    }

    fun selectDocument(doc: StudyDocument?) {
        _selectedDocument.value = doc
    }

    fun setCustomApiKey(key: String) {
        _customApiKey.value = key
    }

    fun setStatusText(text: String?) {
        _statusText.value = text
    }

    fun addDocument(uri: Uri, name: String, type: String, sizeText: String) {
        viewModelScope.launch {
            val newDoc = StudyDocument(
                title = name,
                fileType = type,
                fileUri = uri.toString(),
                fileSize = sizeText,
                extractedSummary = "جاري إعداد الملخص الدراسي..."
            )
            val id = repository.saveDocument(newDoc)
            val savedDoc = newDoc.copy(id = id)
            _selectedDocument.value = savedDoc

            // Auto summarize
            _isGenerating.value = true
            val result = repository.summarizeDocument(uri, name, type)
            _isGenerating.value = false

            result.onSuccess { summary ->
                repository.saveDocument(savedDoc.copy(extractedSummary = summary))
                _selectedDocument.value = savedDoc.copy(extractedSummary = summary)
                _statusText.value = "تم تلخيص المستند بنجاح!"
            }.onFailure { err ->
                repository.saveDocument(savedDoc.copy(extractedSummary = "تعذر التلخيص التلقائي: ${err.message}"))
                _statusText.value = "ملاحظة: ${err.message}"
            }
        }
    }

    fun deleteDocument(id: Long) {
        viewModelScope.launch {
            repository.deleteDocument(id)
            if (_selectedDocument.value?.id == id) {
                _selectedDocument.value = null
            }
        }
    }

    fun sendMessage(userText: String, attachedUri: Uri? = null) {
        if (userText.isBlank() && attachedUri == null) return

        viewModelScope.launch {
            val docContext = _selectedDocument.value?.let {
                "مستند [${it.title}]:\n${it.extractedSummary}"
            }

            var base64Img: String? = null
            attachedUri?.let {
                base64Img = repository.uriToBase64(it)
            }

            // Save user message
            val userMsg = ChatMessage(
                sender = "USER",
                content = userText,
                documentId = _selectedDocument.value?.id,
                imageUri = attachedUri?.toString()
            )
            repository.saveMessage(userMsg)

            _isGenerating.value = true

            val result = repository.askMasa(
                userPrompt = userText,
                documentContext = docContext,
                base64Image = base64Img,
                customApiKey = _customApiKey.value
            )

            _isGenerating.value = false

            result.onSuccess { answer ->
                val isGuardrail = answer.contains("عذراً، أنا ماسا المساعد الدراسي")
                val masaMsg = ChatMessage(
                    sender = "MASA",
                    content = answer,
                    documentId = _selectedDocument.value?.id,
                    isStudyGuardrailNotice = isGuardrail
                )
                repository.saveMessage(masaMsg)
            }.onFailure { err ->
                val masaErrMsg = ChatMessage(
                    sender = "MASA",
                    content = "تنبيه: ${err.message ?: "حدث خطأ أثناء التواصل مع النموذج."}",
                    documentId = _selectedDocument.value?.id
                )
                repository.saveMessage(masaErrMsg)
            }
        }
    }

    fun clearChat() {
        viewModelScope.launch {
            repository.clearChat()
        }
    }

    fun startRecording() {
        _recordingStatus.value = RecordingStatus.RECORDING
        _recordingSeconds.value = 0
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (_recordingStatus.value == RecordingStatus.RECORDING) {
                delay(1000)
                _recordingSeconds.value += 1
            }
        }
    }

    fun stopAndSummarizeLecture(lectureTitle: String, audioUri: Uri? = null) {
        timerJob?.cancel()
        val duration = _recordingSeconds.value
        _recordingStatus.value = RecordingStatus.PROCESSING
        _isGenerating.value = true

        viewModelScope.launch {
            val title = if (lectureTitle.isNotBlank()) lectureTitle else "حصة دراسية - ${System.currentTimeMillis() / 1000}"

            var audioBase64: String? = null
            audioUri?.let {
                audioBase64 = repository.uriToBase64(it)
            }

            val prompt = "قم بتلخيص هذه الحصة الدراسية بالتفصيل الشديد لإنشاء ملخص مذاكرة شامل.\n" +
                    "اسم الحصة: $title\n" +
                    "مدة التسجيل: $duration ثانية.\n" +
                    "المطلوب بشكل منسق وبنقاط واضحة:\n" +
                    "1. 📌 الملخص الشامل للحصة\n" +
                    "2. 💡 أهم المفاهيم والتعاريف الدراسية\n" +
                    "3. 📝 أسئلة مراجعة وتوقعات للاختبار مع الحلول الإرشادية."

            val result = repository.askMasa(
                userPrompt = prompt,
                base64Audio = audioBase64,
                customApiKey = _customApiKey.value
            )

            _isGenerating.value = false
            _recordingStatus.value = RecordingStatus.IDLE

            result.onSuccess { summary ->
                val lecture = LectureRecording(
                    title = title,
                    durationSeconds = duration,
                    summaryText = summary,
                    keyPoints = "مفاهيم دراسية هامة استُخرجت بواسطة ماسا"
                )
                repository.saveLecture(lecture)
                _statusText.value = "تم تلخيص الحصة الدراسية بنجاح!"
            }.onFailure { err ->
                val fallbackLecture = LectureRecording(
                    title = title,
                    durationSeconds = duration,
                    summaryText = "ملخص الحصة الدراسية:\n" +
                            "تضمنت الحصة شرح المفاهيم الدراسية الأساسية والتطبيقات العلمية.\n\n" +
                            "ملاحظة النظام: ${err.message}"
                )
                repository.saveLecture(fallbackLecture)
                _statusText.value = "تم إنشاء مسودة التلخيص بنجاح."
            }
        }
    }

    fun deleteLecture(id: Long) {
        viewModelScope.launch {
            repository.deleteLecture(id)
        }
    }
}
