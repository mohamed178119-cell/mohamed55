package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.BuildConfig
import com.example.ui.theme.MasaAmber
import com.example.ui.theme.MasaPurple
import com.example.ui.theme.MasaPurpleDark
import com.example.ui.theme.MasaPurpleLight
import com.example.ui.theme.MasaTeal
import com.example.ui.viewmodels.MasaViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: MasaViewModel,
    modifier: Modifier = Modifier
) {
    val customKey by viewModel.customApiKey.collectAsState()
    var inputKey by remember { mutableStateOf(customKey) }
    var keySavedMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // App Profile Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MasaPurple),
            elevation = CardDefaults.cardElevation(4.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(MasaAmber),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = MasaPurpleDark,
                        modifier = Modifier.size(36.dp)
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "تطبيق ماسا - Masa Study",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "المساعد الدراسي الذكي والإلكتروني الكامل v1.0",
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.85f)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // API Key Management Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Key, contentDescription = null, tint = MasaPurple)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "مفتاح Gemini API والاتصال",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                val isEnvConfigured = BuildConfig.GEMINI_API_KEY.isNotBlank() && BuildConfig.GEMINI_API_KEY != "MY_GEMINI_API_KEY"

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = if (isEnvConfigured || customKey.isNotBlank()) Icons.Default.CheckCircle else Icons.Default.Info,
                        contentDescription = null,
                        tint = if (isEnvConfigured || customKey.isNotBlank()) MasaTeal else MasaAmber
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isEnvConfigured || customKey.isNotBlank())
                            "مفتاح Gemini API نشط ومربوط بـ AI Studio"
                        else
                            "مفتاح Gemini API افتراضي جاهز. يمكنك تغيير المفتاح بالأسفل إذا أردت.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = inputKey,
                    onValueChange = { inputKey = it },
                    label = { Text("مفتاح Gemini API مخصص (اختياري)") },
                    placeholder = { Text("AIzaSy...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("api_key_input"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = {
                        viewModel.setCustomApiKey(inputKey.trim())
                        keySavedMessage = "تم حفظ مفتاح Gemini API بنجاح!"
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("save_api_key_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = MasaPurple),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("حفظ المفتاح MASA API", fontWeight = FontWeight.Bold)
                }

                keySavedMessage?.let { msg ->
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = msg, color = MasaTeal, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Strict Study Guardrail Rules Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MasaPurpleLight)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Shield, contentDescription = null, tint = MasaPurple)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "ضوابط ونطاق تطبيق ماسا الدراسي",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MasaPurpleDark
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                val rules = listOf(
                    "📌 ماسا يرفض الإجابة عن أي أسئلة خارج نطاق الدراسات المدرسية والجامعية والمذاكرة.",
                    "📑 يقبل ملفات الكتب والدروس بصيغ PDF والصور بدقة عالية.",
                    "🎙️ يسجل ويلخص شرح الحصص والمحاضرات الدراسية فورياً.",
                    "🎯 يستخرج أهم التعاريف والمصطلحات والأسئلة المتوقعة في الامتحانات."
                )

                rules.forEach { rule ->
                    Text(
                        text = rule,
                        fontSize = 13.sp,
                        lineHeight = 20.sp,
                        color = MasaPurpleDark,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // GitHub Workflow Actions Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Build, contentDescription = null, tint = MasaTeal)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "ملف بناء APK على GitHub Actions",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "تم إنشاء ملف الورك فلو جاهز بمسار `.github/workflows/android-build.yml` في المشروع.\n" +
                            "عند رفع هذا الكود إلى مستودع GitHub الخاص بك، سيعمل بناء الـ APK تلقائياً وسيمنحك رابط تحميل ملف الـ APK المباشر!",
                    fontSize = 12.sp,
                    lineHeight = 18.sp,
                    color = Color.Gray
                )
            }
        }
    }
}
