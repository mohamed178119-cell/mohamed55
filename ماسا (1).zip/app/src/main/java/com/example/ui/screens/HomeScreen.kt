package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MasaAmber
import com.example.ui.theme.MasaPurple
import com.example.ui.viewmodels.MasaViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: MasaViewModel
) {
    val activeTab by viewModel.activeTab.collectAsState()
    val statusText by viewModel.statusText.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    // Show status snackbar when statusText changes
    LaunchedEffect(statusText) {
        statusText?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.setStatusText(null)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MasaPurple,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = activeTab == 0,
                    onClick = { viewModel.selectTab(0) },
                    icon = {
                        Icon(
                            imageVector = if (activeTab == 0) Icons.Filled.MenuBook else Icons.Outlined.MenuBook,
                            contentDescription = "المستندات"
                        )
                    },
                    label = { Text("المكتبة", fontSize = 12.sp) },
                    modifier = Modifier.testTag("tab_documents")
                )

                NavigationBarItem(
                    selected = activeTab == 1,
                    onClick = { viewModel.selectTab(1) },
                    icon = {
                        Icon(
                            imageVector = if (activeTab == 1) Icons.Filled.Chat else Icons.Outlined.Chat,
                            contentDescription = "الشات"
                        )
                    },
                    label = { Text("الشات", fontSize = 12.sp) },
                    modifier = Modifier.testTag("tab_chat")
                )

                NavigationBarItem(
                    selected = activeTab == 2,
                    onClick = { viewModel.selectTab(2) },
                    icon = {
                        Icon(
                            imageVector = if (activeTab == 2) Icons.Filled.Mic else Icons.Outlined.Mic,
                            contentDescription = "تسجيل الحصص"
                        )
                    },
                    label = { Text("تسجيل الحصص", fontSize = 12.sp) },
                    modifier = Modifier.testTag("tab_audio")
                )

                NavigationBarItem(
                    selected = activeTab == 3,
                    onClick = { viewModel.selectTab(3) },
                    icon = {
                        Icon(
                            imageVector = if (activeTab == 3) Icons.Filled.Settings else Icons.Outlined.Settings,
                            contentDescription = "الإعدادات"
                        )
                    },
                    label = { Text("الإعدادات", fontSize = 12.sp) },
                    modifier = Modifier.testTag("tab_settings")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (activeTab) {
                0 -> DocumentsScreen(viewModel = viewModel)
                1 -> ChatScreen(viewModel = viewModel)
                2 -> LectureRecorderScreen(viewModel = viewModel)
                3 -> SettingsScreen(viewModel = viewModel)
            }
        }
    }
}
