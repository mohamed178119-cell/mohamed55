package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "translation_projects")
data class TranslationProject(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val videoSourceType: String, // "URL", "FILE", "SAMPLE"
    val videoUriOrUrl: String,
    val originalLanguageCode: String = "en",
    val targetLanguageCode: String,
    val targetLanguageNameAr: String,
    val selectedVoiceId: String,
    val selectedVoiceNameAr: String,
    val createdAtTimestamp: Long = System.currentTimeMillis(),
    val durationSeconds: Int = 0,
    val subtitlesJson: String, // Serialized JSON list of SubtitleItem
    val summaryText: String = "",
    val isFavorite: Boolean = false
)
