package com.example.data.model

enum class VoiceGender { MALE, FEMALE }

data class VoiceOption(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val descriptionAr: String,
    val pitch: Float,
    val speechRate: Float,
    val gender: VoiceGender,
    val geminiVoiceName: String, // Gemini TTS voice parameter (e.g. Onyx, Kore, Fenrir, Aoede, Puck)
    val iconName: String
) {
    companion object {
        val FIVE_VOICES = listOf(
            VoiceOption(
                id = "voice_1",
                nameAr = "صوت حماسي ورزين (أونيكس)",
                nameEn = "Dynamic Male (Onyx)",
                descriptionAr = "صوت رجالي عالي النقاء وعميق، مثالي للمحتوى التقني والتعليمي",
                pitch = 0.85f,
                speechRate = 1.0f,
                gender = VoiceGender.MALE,
                geminiVoiceName = "Puck",
                iconName = "mic_male_1"
            ),
            VoiceOption(
                id = "voice_2",
                nameAr = "صوت ناعم ودافئ (كوري)",
                nameEn = "Warm Female (Kore)",
                descriptionAr = "صوت نسائي دافئ ومريح للأذن، رائع للأفلام الوثائقية واللايف ستايل",
                pitch = 1.15f,
                speechRate = 0.95f,
                gender = VoiceGender.FEMALE,
                geminiVoiceName = "Kore",
                iconName = "mic_female_1"
            ),
            VoiceOption(
                id = "voice_3",
                nameAr = "صوت احترافي إخباري (فنرير)",
                nameEn = "News Anchor Male (Fenrir)",
                descriptionAr = "صوت رسمي وقوي بنبرة إخبارية احترافية للمحتوى الإخباري والجاد",
                pitch = 0.95f,
                speechRate = 1.05f,
                gender = VoiceGender.MALE,
                geminiVoiceName = "Fenrir",
                iconName = "mic_male_2"
            ),
            VoiceOption(
                id = "voice_4",
                nameAr = "صوت راوي قصص (أويدي)",
                nameEn = "Storyteller Female (Aoede)",
                descriptionAr = "صوت تعبيري وتفاعلي يمنح الحكايات والروايات حيوية وسحراً",
                pitch = 1.05f,
                speechRate = 0.90f,
                gender = VoiceGender.FEMALE,
                geminiVoiceName = "Aoede",
                iconName = "mic_female_2"
            ),
            VoiceOption(
                id = "voice_5",
                nameAr = "صوت شبابي عصري (باك)",
                nameEn = "Energetic Youth (Puck)",
                descriptionAr = "صوت حركي وحماسي مناسب لفيديوهات اليوتيوب القصيرة وReels",
                pitch = 1.10f,
                speechRate = 1.10f,
                gender = VoiceGender.MALE,
                geminiVoiceName = "Onyx",
                iconName = "mic_male_3"
            )
        )

        fun getById(id: String): VoiceOption {
            return FIVE_VOICES.find { it.id == id } ?: FIVE_VOICES[0]
        }
    }
}
