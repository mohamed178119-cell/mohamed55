package com.example.ui.components

import android.net.Uri
import android.widget.MediaController
import android.widget.VideoView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.model.SubtitleItem
import com.example.ui.theme.AccentGold
import com.example.ui.theme.PrimaryIndigo
import com.example.ui.theme.SecondaryCyan
import com.example.ui.theme.SubtitleBg
import com.example.ui.theme.SubtitleTextYellow
import kotlinx.coroutines.delay

@Composable
fun VideoPlayerView(
    videoUriOrUrl: String,
    subtitles: List<SubtitleItem>,
    isDubbingAudioActive: Boolean,
    onToggleAudioMode: () -> Unit,
    onSubtitleSpoken: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var isPlaying by remember { mutableStateOf(false) }
    var currentPositionMs by remember { mutableStateOf(0L) }
    var durationMs by remember { mutableStateOf(20000L) }
    var currentSubtitle by remember { mutableStateOf<SubtitleItem?>(null) }
    var lastSpokenSubtitleId by remember { mutableStateOf(-1) }
    var showDualSubtitles by remember { mutableStateOf(true) }

    // Simulated / Native playback loop
    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            delay(200)
            currentPositionMs += 200
            if (currentPositionMs >= durationMs) {
                currentPositionMs = 0
                lastSpokenSubtitleId = -1
            }

            // Find current subtitle cue
            val activeCue = subtitles.find { cue ->
                currentPositionMs >= cue.startTimeMs && currentPositionMs <= cue.endTimeMs
            }
            currentSubtitle = activeCue

            // If dubbing audio is active, trigger TTS speech for new subtitle cue
            if (activeCue != null && isDubbingAudioActive && activeCue.id != lastSpokenSubtitleId) {
                lastSpokenSubtitleId = activeCue.id
                onSubtitleSpoken(activeCue.translatedText)
            }
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("video_player_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Black),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            
            // Video Frame Screen
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .background(Color(0xFF0F0F1A)),
                contentAlignment = Alignment.Center
            ) {
                // If it's a direct mp4 URL or URI, we display VideoView
                if (videoUriOrUrl.startsWith("http") && videoUriOrUrl.endsWith(".mp4")) {
                    AndroidView(
                        factory = { ctx ->
                            VideoView(ctx).apply {
                                setVideoURI(Uri.parse(videoUriOrUrl))
                                setOnPreparedListener { mp ->
                                    durationMs = mp.duration.toLong()
                                    mp.isLooping = true
                                    start()
                                    isPlaying = true
                                }
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    // Stylized AI Media Canvas display
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color(0xFF1E1B4B),
                                        Color(0xFF0F101D)
                                    )
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.ClosedCaption else Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = SecondaryCyan,
                                modifier = Modifier.size(56.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (isPlaying) "جاري تشغيل الفيديو المترجم..." else "اضغط تشغيل لمشاهدة الترجمة والدبلجة",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White.copy(alpha = 0.9f)
                            )
                        }
                    }
                }

                // Subtitle Overlay at lower part of video canvas
                if (currentSubtitle != null) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 12.dp, start = 16.dp, end = 16.dp)
                    ) {
                        currentSubtitle?.let { cue ->
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(SubtitleBg)
                                    .border(1.dp, PrimaryIndigo.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                    .padding(horizontal = 14.dp, vertical = 8.dp)
                            ) {
                                // Target Language Translated Subtitle Text (Highlighted)
                                Text(
                                    text = cue.translatedText,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp
                                    ),
                                    color = SubtitleTextYellow,
                                    textAlign = TextAlign.Center
                                )

                                // Optional Original Language Dual Subtitle
                                if (showDualSubtitles) {
                                    Text(
                                        text = cue.originalText,
                                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                                        color = Color.White.copy(alpha = 0.8f),
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(top = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Controls Bar Below Video Frame
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF141526))
                    .padding(12.dp)
            ) {
                // Time Slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = formatTime(currentPositionMs),
                        style = MaterialTheme.typography.labelSmall,
                        color = SecondaryCyan
                    )

                    Slider(
                        value = if (durationMs > 0) currentPositionMs.toFloat() / durationMs.toFloat() else 0f,
                        onValueChange = { progress ->
                            currentPositionMs = (progress * durationMs).toLong()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 8.dp),
                        colors = SliderDefaults.colors(
                            thumbColor = AccentGold,
                            activeTrackColor = PrimaryIndigo,
                            inactiveTrackColor = Color.Gray.copy(alpha = 0.3f)
                        )
                    )

                    Text(
                        text = formatTime(durationMs),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                }

                // Playback Action Buttons Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Audio Mode Switcher (Dubbing Voice vs Original)
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (isDubbingAudioActive) PrimaryIndigo.copy(alpha = 0.3f)
                                else Color.White.copy(alpha = 0.1f)
                            )
                            .border(
                                width = 1.dp,
                                color = if (isDubbingAudioActive) PrimaryIndigo else Color.Transparent,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable { onToggleAudioMode() }
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isDubbingAudioActive) Icons.Default.VolumeUp else Icons.Default.VolumeMute,
                            contentDescription = null,
                            tint = if (isDubbingAudioActive) SecondaryCyan else Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isDubbingAudioActive) "صوت الدبلجة AI" else "الصوت الأصلي",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDubbingAudioActive) SecondaryCyan else Color.White
                        )
                    }

                    // Play/Pause & Skip Buttons
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = {
                                currentPositionMs = maxOf(0L, currentPositionMs - 10000L)
                            }
                        ) {
                            Icon(Icons.Default.Replay10, contentDescription = "تراجع 10 ثواني", tint = Color.White)
                        }

                        IconButton(
                            onClick = { isPlaying = !isPlaying },
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(PrimaryIndigo)
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isPlaying) "إيقاف مؤقت" else "تشغيل",
                                tint = Color.White,
                                modifier = Modifier.size(28.dp)
                            )
                        }

                        IconButton(
                            onClick = {
                                currentPositionMs = minOf(durationMs, currentPositionMs + 10000L)
                            }
                        ) {
                            Icon(Icons.Default.Forward10, contentDescription = "تقديم 10 ثواني", tint = Color.White)
                        }
                    }

                    // Toggle Dual Subtitles
                    IconButton(
                        onClick = { showDualSubtitles = !showDualSubtitles },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(if (showDualSubtitles) AccentGold.copy(alpha = 0.2f) else Color.Transparent)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ClosedCaption,
                            contentDescription = "الترجمة المزدوجة",
                            tint = if (showDualSubtitles) AccentGold else Color.Gray
                        )
                    }
                }
            }
        }
    }
}

private fun formatTime(ms: Long): String {
    val totalSecs = ms / 1000
    val mins = totalSecs / 60
    val secs = totalSecs % 60
    return String.format("%02d:%02d", mins, secs)
}
