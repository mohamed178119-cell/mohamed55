package com.example.data.model

data class TranslationLanguage(
    val code: String,
    val nameAr: String,
    val nameEn: String,
    val flagEmoji: String,
    val nativeName: String
) {
    companion object {
        val ALL_LANGUAGES = listOf(
            TranslationLanguage("ar", "العربية", "Arabic", "🇸🇦", "العربية"),
            TranslationLanguage("en", "الإنجليزية", "English", "🇺🇸", "English"),
            TranslationLanguage("fr", "الفرنسية", "French", "🇫🇷", "Français"),
            TranslationLanguage("es", "الإسبانية", "Spanish", "🇪🇸", "Español"),
            TranslationLanguage("de", "الألمانية", "German", "🇩🇪", "Deutsch"),
            TranslationLanguage("it", "الإيطالية", "Italian", "🇮🇹", "Italiano"),
            TranslationLanguage("ja", "اليابانية", "Japanese", "🇯🇵", "日本語"),
            TranslationLanguage("zh", "الصينية", "Chinese", "🇨🇳", "中文"),
            TranslationLanguage("tr", "التركية", "Turkish", "🇹🇷", "Türkçe"),
            TranslationLanguage("ru", "الروسية", "Russian", "🇷🇺", "Русский"),
            TranslationLanguage("pt", "البرتغالية", "Portuguese", "🇵🇹", "Português"),
            TranslationLanguage("hi", "الهندية", "Hindi", "🇮🇳", "हिन्दी"),
            TranslationLanguage("ko", "الكورية", "Korean", "🇰🇷", "한국어"),
            TranslationLanguage("nl", "الهولندية", "Dutch", "🇳🇱", "Nederlands"),
            TranslationLanguage("pl", "البولندية", "Polish", "🇵🇱", "Polski"),
            TranslationLanguage("id", "الإندونيسية", "Indonesian", "🇮🇩", "Bahasa Indonesia"),
            TranslationLanguage("ur", "الأوردو", "Urdu", "🇵🇰", "اردو"),
            TranslationLanguage("bn", "البنغالية", "Bengali", "🇧🇩", "বাংলা"),
            TranslationLanguage("sv", "السويدية", "Swedish", "🇸🇪", "Svenska"),
            TranslationLanguage("vi", "الفييتنامية", "Vietnamese", "🇻🇳", "Tiếng Việt"),
            TranslationLanguage("el", "اليونانية", "Greek", "🇬🇷", "Ελληνικά"),
            TranslationLanguage("he", "العبرية", "Hebrew", "🇮🇱", "עברית")
        )

        fun getByCode(code: String): TranslationLanguage {
            return ALL_LANGUAGES.find { it.code == code } ?: ALL_LANGUAGES[0]
        }
    }
}
