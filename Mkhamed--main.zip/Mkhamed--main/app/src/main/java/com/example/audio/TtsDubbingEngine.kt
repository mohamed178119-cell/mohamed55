package com.example.audio

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.example.data.model.VoiceOption
import java.util.Locale

class TtsDubbingEngine(
    private val context: Context,
    private val onInitComplete: (Boolean) -> Unit = {}
) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isInitialized = false
    private var currentLanguageCode = "ar"
    private var currentVoice: VoiceOption = VoiceOption.FIVE_VOICES[0]

    init {
        try {
            tts = TextToSpeech(context.applicationContext, this)
        } catch (e: Exception) {
            Log.e("TtsDubbingEngine", "Failed to init TTS: ${e.message}")
            onInitComplete(false)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            applyLanguageAndVoice(currentLanguageCode, currentVoice)
            
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {}
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {}
            })
            onInitComplete(true)
        } else {
            isInitialized = false
            onInitComplete(false)
        }
    }

    fun applyLanguageAndVoice(langCode: String, voiceOption: VoiceOption) {
        currentLanguageCode = langCode
        currentVoice = voiceOption

        if (!isInitialized || tts == null) return

        val locale = mapCodeToLocale(langCode)
        val result = tts?.setLanguage(locale)
        
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            // Fallback to English or default if specific language TTS engine data is absent
            tts?.language = Locale.getDefault()
        }

        // Configure pitch and speed according to selected voice option
        tts?.setPitch(voiceOption.pitch)
        tts?.setSpeechRate(voiceOption.speechRate)
    }

    fun speakText(text: String, utteranceId: String = "sub_utterance") {
        if (!isInitialized || tts == null || text.isBlank()) return
        
        tts?.stop()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun speakPreview(voiceOption: VoiceOption, langCode: String, customSampleText: String? = null) {
        applyLanguageAndVoice(langCode, voiceOption)
        
        val previewText = customSampleText ?: when (langCode) {
            "ar" -> "أهلاً بك! هذا نموذج لصوت ${voiceOption.nameAr} في تطبيق ترجمة ودبلجة الفيديوهات."
            "en" -> "Hello! This is a preview of ${voiceOption.nameEn} voice in Video Translator AI."
            "fr" -> "Bonjour! Ceci est un aperçu de la voix ${voiceOption.nameEn}."
            "es" -> "¡Hola! Esta es una vista previa de la voz ${voiceOption.nameEn}."
            "de" -> "Hallo! Dies ist eine Hörprobe der Stimme ${voiceOption.nameEn}."
            else -> "Hello! This is a voice sample preview for translation and dubbing."
        }

        speakText(previewText, "preview_voice_${voiceOption.id}")
    }

    fun stop() {
        if (isInitialized && tts != null) {
            tts?.stop()
        }
    }

    fun shutdown() {
        if (tts != null) {
            try {
                tts?.stop()
                tts?.shutdown()
            } catch (e: Exception) {
                Log.e("TtsDubbingEngine", "Shutdown error: ${e.message}")
            } finally {
                tts = null
                isInitialized = false
            }
        }
    }

    private fun mapCodeToLocale(code: String): Locale {
        return when (code.lowercase()) {
            "ar" -> Locale("ar")
            "en" -> Locale.ENGLISH
            "fr" -> Locale.FRENCH
            "es" -> Locale("es")
            "de" -> Locale.GERMAN
            "it" -> Locale.ITALIAN
            "ja" -> Locale.JAPANESE
            "zh" -> Locale.CHINESE
            "tr" -> Locale("tr")
            "ru" -> Locale("ru")
            "pt" -> Locale("pt")
            "hi" -> Locale("hi")
            "ko" -> Locale.KOREAN
            "nl" -> Locale("nl")
            "pl" -> Locale("pl")
            "id" -> Locale("id")
            "ur" -> Locale("ur")
            "bn" -> Locale("bn")
            "sv" -> Locale("sv")
            "vi" -> Locale("vi")
            "el" -> Locale("el")
            "he" -> Locale("iw")
            else -> Locale.getDefault()
        }
    }
}
