package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.FooterSignature
import com.example.ui.components.LanguageSelectorCard
import com.example.ui.components.TranscriptListCard
import com.example.ui.components.VideoInputCard
import com.example.ui.components.VideoPlayerView
import com.example.ui.components.VoiceSelectorCard
import com.example.ui.theme.AccentGold
import com.example.ui.theme.PrimaryIndigo
import com.example.ui.theme.SecondaryCyan
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onNavigateToHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    val videoUrlInput by viewModel.videoUrlInput.collectAsState()
    val selectedFileName by viewModel.selectedFileName.collectAsState()
    val selectedLanguage by viewModel.selectedLanguage.collectAsState()
    val selectedVoice by viewModel.selectedVoice.collectAsState()
    val isProcessing by viewModel.isProcessing.collectAsState()
    val processingPhase by viewModel.processingPhase.collectAsState()
    val currentProject by viewModel.currentProject.collectAsState()
    val currentSubtitles by viewModel.currentSubtitles.collectAsState()
    val isDubbingAudioActive by viewModel.isDubbingAudioActive.collectAsState()

    // File picker launcher
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            val fileName = uri.lastPathSegment ?: "فيديو محلي"
            viewModel.onLocalFileSelected(fileName, uri.toString())
        }
    }

    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(PrimaryIndigo)
                                .padding(6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Translate,
                                contentDescription = null,
                                tint = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "مترجم الفيديوهات AI",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp
                                ),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "دبلجة وترجمة لأكثر من 20 لغة بـ 5 أصوات",
                                style = MaterialTheme.typography.labelSmall,
                                color = SecondaryCyan
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = onNavigateToHistory,
                        modifier = Modifier.testTag("history_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "السجل والتسجيلات المحفوظة",
                            tint = AccentGold
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            // MANDATORY FOOTER AT VERY BOTTOM OF HOME SCREEN
            FooterSignature()
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
        ) {
            // Video Source Input Card
            VideoInputCard(
                videoUrlInput = videoUrlInput,
                onUrlChange = { viewModel.onUrlChange(it) },
                onSelectLocalFile = { filePickerLauncher.launch("video/*") },
                selectedFileName = selectedFileName
            )

            // Language Selector Card (20+ languages)
            LanguageSelectorCard(
                selectedLanguage = selectedLanguage,
                onLanguageSelected = { viewModel.onLanguageSelected(it) }
            )

            // Voice Selector Card (5 distinct AI voices with previews)
            VoiceSelectorCard(
                selectedVoice = selectedVoice,
                onVoiceSelected = { viewModel.onVoiceSelected(it) },
                onPreviewVoice = { viewModel.previewVoice(it) },
                targetLanguage = selectedLanguage
            )

            // Action Translate Button
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Button(
                    onClick = { viewModel.startTranslationProcess() },
                    enabled = !isProcessing && videoUrlInput.isNotBlank(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("start_translation_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PrimaryIndigo,
                        contentColor = Color.White
                    ),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp)
                ) {
                    if (isProcessing) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(24.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "جاري المعالجة بالذكاء الاصطناعي...",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = AccentGold,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ترجمة ودبلجة الفيديو الآن",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Processing Indicator Banner
            AnimatedVisibility(visible = isProcessing) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = PrimaryIndigo.copy(alpha = 0.2f)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            color = SecondaryCyan,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = processingPhase,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                            color = Color.White
                        )
                    }
                }
            }

            // Video Player View (shows when video translation is completed or video active)
            if (currentSubtitles.isNotEmpty() || currentProject != null) {
                Text(
                    text = "مشغل الفيديو المترجم والدبلجة الصوتيّة",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 4.dp)
                )

                VideoPlayerView(
                    videoUriOrUrl = currentProject?.videoUriOrUrl ?: videoUrlInput,
                    subtitles = currentSubtitles,
                    isDubbingAudioActive = isDubbingAudioActive,
                    onToggleAudioMode = { viewModel.toggleDubbingAudioMode() },
                    onSubtitleSpoken = { text -> viewModel.speakSubtitleText(text) }
                )

                TranscriptListCard(
                    subtitles = currentSubtitles,
                    onSelectCue = { cue ->
                        viewModel.speakSubtitleText(cue.translatedText)
                    }
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
