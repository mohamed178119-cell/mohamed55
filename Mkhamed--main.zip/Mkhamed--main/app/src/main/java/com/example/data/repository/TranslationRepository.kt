package com.example.data.repository

import com.example.data.local.TranslationDao
import com.example.data.model.SubtitleItem
import com.example.data.model.TranslationLanguage
import com.example.data.model.TranslationProject
import com.example.data.model.VoiceOption
import com.example.data.remote.GeminiTranslationService
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.Flow
import java.lang.reflect.Type

class TranslationRepository(
    private val translationDao: TranslationDao,
    private val geminiService: GeminiTranslationService = GeminiTranslationService()
) {

    private val moshi: Moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
    private val subtitleListType: Type = Types.newParameterizedType(List::class.java, SubtitleItem::class.java)
    private val subtitleAdapter = moshi.adapter<List<SubtitleItem>>(subtitleListType)

    val allSavedProjects: Flow<List<TranslationProject>> = translationDao.getAllProjects()

    suspend fun translateAndSave(
        title: String,
        videoSourceType: String,
        videoUriOrUrl: String,
        targetLanguage: TranslationLanguage,
        selectedVoice: VoiceOption
    ): TranslationProject {
        val (summary, subtitles) = geminiService.translateVideoContent(
            videoTitleOrUrl = if (title.isNotBlank()) title else videoUriOrUrl,
            targetLanguage = targetLanguage
        )

        val jsonSubtitles = subtitleAdapter.toJson(subtitles)
        val durationSecs = if (subtitles.isNotEmpty()) (subtitles.last().endTimeMs / 1000).toInt() else 30

        val project = TranslationProject(
            title = if (title.isNotBlank()) title else "ترجمة فيديو - ${targetLanguage.nameAr}",
            videoSourceType = videoSourceType,
            videoUriOrUrl = videoUriOrUrl,
            originalLanguageCode = "en",
            targetLanguageCode = targetLanguage.code,
            targetLanguageNameAr = targetLanguage.nameAr,
            selectedVoiceId = selectedVoice.id,
            selectedVoiceNameAr = selectedVoice.nameAr,
            createdAtTimestamp = System.currentTimeMillis(),
            durationSeconds = durationSecs,
            subtitlesJson = jsonSubtitles,
            summaryText = summary
        )

        val id = translationDao.insertProject(project)
        return project.copy(id = id)
    }

    fun parseSubtitles(subtitlesJson: String): List<SubtitleItem> {
        return try {
            if (subtitlesJson.isBlank()) emptyList()
            else subtitleAdapter.fromJson(subtitlesJson) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun deleteProject(id: Long) {
        translationDao.deleteProjectById(id)
    }

    suspend fun updateProject(project: TranslationProject) {
        translationDao.updateProject(project)
    }
}
