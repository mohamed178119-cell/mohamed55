package com.example.data.model

data class SubtitleItem(
    val id: Int,
    val startTimeMs: Long,
    val endTimeMs: Long,
    val originalText: String,
    val translatedText: String,
    val speaker: String = "المتحدث"
) {
    fun formatTime(timeMs: Long): String {
        val totalSecs = timeMs / 1000
        val mins = totalSecs / 60
        val secs = totalSecs % 60
        return String.format("%02d:%02d", mins, secs)
    }

    val startFormatted: String get() = formatTime(startTimeMs)
    val endFormatted: String get() = formatTime(endTimeMs)
}
