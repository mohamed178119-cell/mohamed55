package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Indigo Accent
val PrimaryIndigo = Color(0xFF6366F1)
val PrimaryIndigoDark = Color(0xFF4338CA)
val PrimaryIndigoLight = Color(0xFF818CF8)

// Secondary Cyan / Electric Blue
val SecondaryCyan = Color(0xFF06B6D4)
val SecondaryCyanLight = Color(0xFF67E8F9)

// Accent Gold / Amber
val AccentGold = Color(0xFFF59E0B)
val AccentGoldLight = Color(0xFFFCD34D)

// Background Dark Canvas
val BackgroundDark = Color(0xFF0F101D)
val SurfaceDark = Color(0xFF1B1D33)
val SurfaceDarkElevated = Color(0xFF262947)
val CardBorderDark = Color(0xFF333761)

// Light Theme Fallback
val PrimaryLight = Color(0xFF4F46E5)
val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceLightElevated = Color(0xFFF1F5F9)

// Subtitle Highlight
val SubtitleBg = Color(0xCC000000)
val SubtitleTextYellow = Color(0xFFFFEB3B)

