package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.TtsDubbingEngine
import com.example.data.local.AppDatabase
import com.example.data.model.SubtitleItem
import com.example.data.model.TranslationLanguage
import com.example.data.model.TranslationProject
import com.example.data.model.VoiceOption
import com.example.data.repository.TranslationRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = TranslationRepository(db.translationDao())
    private val ttsEngine = TtsDubbingEngine(application)

    // Form inputs
    private val _videoUrlInput = MutableStateFlow("https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4")
    val videoUrlInput: StateFlow<String> = _videoUrlInput.asStateFlow()

    private val _selectedFileName = MutableStateFlow<String?>(null)
    val selectedFileName: StateFlow<String?> = _selectedFileName.asStateFlow()

    private val _selectedLanguage = MutableStateFlow(TranslationLanguage.ALL_LANGUAGES[0]) // Arabic default
    val selectedLanguage: StateFlow<TranslationLanguage> = _selectedLanguage.asStateFlow()

    private val _selectedVoice = MutableStateFlow(VoiceOption.FIVE_VOICES[0]) // Dynamic Male default
    val selectedVoice: StateFlow<VoiceOption> = _selectedVoice.asStateFlow()

    // Processing status
    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    private val _processingPhase = MutableStateFlow("")
    val processingPhase: StateFlow<String> = _processingPhase.asStateFlow()

    // Active translated project
    private val _currentProject = MutableStateFlow<TranslationProject?>(null)
    val currentProject: StateFlow<TranslationProject?> = _currentProject.asStateFlow()

    private val _currentSubtitles = MutableStateFlow<List<SubtitleItem>>(emptyList())
    val currentSubtitles: StateFlow<List<SubtitleItem>> = _currentSubtitles.asStateFlow()

    private val _isDubbingAudioActive = MutableStateFlow(true)
    val isDubbingAudioActive: StateFlow<Boolean> = _isDubbingAudioActive.asStateFlow()

    // Saved projects history from Room
    val savedHistory: StateFlow<List<TranslationProject>> = repository.allSavedProjects
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun onUrlChange(newUrl: String) {
        _videoUrlInput.value = newUrl
        _selectedFileName.value = null
    }

    fun onLocalFileSelected(fileName: String, uriString: String) {
        _selectedFileName.value = fileName
        _videoUrlInput.value = uriString
    }

    fun onLanguageSelected(language: TranslationLanguage) {
        _selectedLanguage.value = language
        ttsEngine.applyLanguageAndVoice(language.code, _selectedVoice.value)
    }

    fun onVoiceSelected(voice: VoiceOption) {
        _selectedVoice.value = voice
        ttsEngine.applyLanguageAndVoice(_selectedLanguage.value.code, voice)
    }

    fun previewVoice(voice: VoiceOption) {
        ttsEngine.speakPreview(voice, _selectedLanguage.value.code)
    }

    fun toggleDubbingAudioMode() {
        _isDubbingAudioActive.value = !_isDubbingAudioActive.value
        if (!_isDubbingAudioActive.value) {
            ttsEngine.stop()
        }
    }

    fun speakSubtitleText(text: String) {
        if (_isDubbingAudioActive.value) {
            ttsEngine.speakText(text)
        }
    }

    fun startTranslationProcess() {
        val input = _videoUrlInput.value
        if (input.isBlank()) return

        viewModelScope.launch {
            _isProcessing.value = true
            
            _processingPhase.value = "جاري استخراج الصوت والحوار من الفيديو..."
            kotlinx.coroutines.delay(1000)

            _processingPhase.value = "جاري الاتصال بنموذج الذكاء الاصطناعي وترجمة الحوار إلى ${selectedLanguage.value.nameAr}..."
            kotlinx.coroutines.delay(1200)

            _processingPhase.value = "جاري تركيب الهندسة الصوتية مع صوت ${_selectedVoice.value.nameAr}..."
            kotlinx.coroutines.delay(1000)

            try {
                val project = repository.translateAndSave(
                    title = _selectedFileName.value ?: "ترجمة فيديو - ${selectedLanguage.value.nameAr}",
                    videoSourceType = if (_selectedFileName.value != null) "FILE" else "URL",
                    videoUriOrUrl = input,
                    targetLanguage = _selectedLanguage.value,
                    selectedVoice = _selectedVoice.value
                )

                val subs = repository.parseSubtitles(project.subtitlesJson)
                _currentProject.value = project
                _currentSubtitles.value = subs

                _processingPhase.value = "تمت الترجمة والدبلجة بنجاح!"
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isProcessing.value = false
            }
        }
    }

    fun loadHistoryProject(project: TranslationProject) {
        viewModelScope.launch {
            _currentProject.value = project
            _videoUrlInput.value = project.videoUriOrUrl
            val subs = repository.parseSubtitles(project.subtitlesJson)
            _currentSubtitles.value = subs
            
            val lang = TranslationLanguage.getByCode(project.targetLanguageCode)
            _selectedLanguage.value = lang
            val voice = VoiceOption.getById(project.selectedVoiceId)
            _selectedVoice.value = voice

            ttsEngine.applyLanguageAndVoice(lang.code, voice)
        }
    }

    fun deleteHistoryProject(project: TranslationProject) {
        viewModelScope.launch {
            repository.deleteProject(project.id)
            if (_currentProject.value?.id == project.id) {
                _currentProject.value = null
                _currentSubtitles.value = emptyList()
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        ttsEngine.shutdown()
    }
}
