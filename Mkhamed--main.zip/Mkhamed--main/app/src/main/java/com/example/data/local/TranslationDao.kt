package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.TranslationProject
import kotlinx.coroutines.flow.Flow

@Dao
interface TranslationDao {

    @Query("SELECT * FROM translation_projects ORDER BY createdAtTimestamp DESC")
    fun getAllProjects(): Flow<List<TranslationProject>>

    @Query("SELECT * FROM translation_projects WHERE id = :id")
    suspend fun getProjectById(id: Long): TranslationProject?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: TranslationProject): Long

    @Update
    suspend fun updateProject(project: TranslationProject)

    @Query("DELETE FROM translation_projects WHERE id = :id")
    suspend fun deleteProjectById(id: Long)

    @Query("DELETE FROM translation_projects")
    suspend fun deleteAllProjects()
}
