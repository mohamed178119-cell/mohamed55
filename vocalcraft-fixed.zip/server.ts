import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const isProduction = process.env.NODE_ENV === 'production';

app.use(express.json({ limit: '10mb' }));

// Allow the mobile app (Capacitor WebView) to call this API from another origin
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  if (req.method === 'OPTIONS') {
    res.sendStatus(204);
    return;
  }
  next();
});

// Gemini TTS returns raw PCM (audio/L16, usually 24kHz mono), which browsers cannot decode
// as WAV. Wrap it in a WAV header so decodeAudioData and .wav downloads work.
function pcmToWavBase64(pcmBase64: string, mimeType?: string): string {
  if (mimeType && !/pcm|l16/i.test(mimeType)) return pcmBase64; // already a playable container
  const pcm = Buffer.from(pcmBase64, 'base64');
  const rateMatch = mimeType?.match(/rate=(\d+)/);
  const sampleRate = rateMatch ? parseInt(rateMatch[1], 10) : 24000;
  const channels = 1;
  const bitsPerSample = 16;
  const header = Buffer.alloc(44);
  header.write('RIFF', 0);
  header.writeUInt32LE(36 + pcm.length, 4);
  header.write('WAVE', 8);
  header.write('fmt ', 12);
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20);
  header.writeUInt16LE(channels, 22);
  header.writeUInt32LE(sampleRate, 24);
  header.writeUInt32LE((sampleRate * channels * bitsPerSample) / 8, 28);
  header.writeUInt16LE((channels * bitsPerSample) / 8, 32);
  header.writeUInt16LE(bitsPerSample, 34);
  header.write('data', 36);
  header.writeUInt32LE(pcm.length, 40);
  return Buffer.concat([header, pcm]).toString('base64');
}

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Realistic Voice Presets
const REALISTIC_VOICE_CONFIGS: Record<string, { voiceName: string; defaultStyle: string }> = {
  sara_melodic: {
    voiceName: 'Kore',
    defaultStyle: 'Speak in a soft, gentle, natural, and soothing Arabic female voice with crystal-clear pronunciation and warm emotional resonance like a professional audiobook narrator.',
  },
  omar_deep: {
    voiceName: 'Fenrir',
    defaultStyle: 'Deep, warm, prestigious Arabic male speaker with steady cadence, rich vocal timbre, and natural articulation.',
  },
  yasmine_doc: {
    voiceName: 'Kore',
    defaultStyle: 'Professional documentary narrator, captivating and engaging Arabic female speaker with expressive pacing and natural pauses.',
  },
  karim_youth: {
    voiceName: 'Puck',
    defaultStyle: 'Natural, cheerful, enthusiastic, conversational young Arabic male speaker, completely fluent and friendly.',
  },
  laila_tarab: {
    voiceName: 'Zephyr',
    defaultStyle: 'Deeply expressive, emotional, poetic recitation in pristine Classical Arabic with musical cadence and soulful feeling.',
  },
  tariq_news: {
    voiceName: 'Charon',
    defaultStyle: 'Crisp, authoritative, articulate broadcast journalist speaking standard formal Arabic with impeccable diction.',
  },
  mariam_egyptian: {
    voiceName: 'Kore',
    defaultStyle: 'Warm, natural, lively Egyptian dialect Arabic speaker, speaking comfortably like a loving friend, charming and realistic.',
  },
  sultan_gulf: {
    voiceName: 'Charon',
    defaultStyle: 'Prestigious, polite, deep Gulf Arabic speaker with noble and hospitable cadence, warm and authentic.',
  },
  nour_levant: {
    voiceName: 'Zephyr',
    defaultStyle: 'Gentle, soft, charming Levantine (Syrian/Lebanese) Arabic speaker with melodic, friendly, relaxing cadence.',
  },
  zain_singer: {
    voiceName: 'Fenrir',
    defaultStyle: 'Soulful Arabic vocalist with melodic intonation, resonant vocal chords, and natural acoustic warmth.',
  },
};

// Text-to-Speech endpoint with Gemini 3.8 TTS for Realistic Voices
app.post('/api/tts', async (req, res) => {
  try {
    const { text, voiceId = 'sara_melodic', voice, style } = req.body;

    if (!text || typeof text !== 'string') {
      res.status(400).json({ error: 'نص المحادثة مطلوب (Text is required)' });
      return;
    }

    const voiceConfig = REALISTIC_VOICE_CONFIGS[voiceId] || {
      voiceName: voice || 'Kore',
      defaultStyle: 'Natural, warm, crystal-clear and expressive Arabic speaker with human breathing and authentic pronunciation.',
    };

    const finalVoiceName = voice || voiceConfig.voiceName;
    const finalStyle = style || voiceConfig.defaultStyle;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: text.slice(0, 500),
              speechMetadata: {
                style: finalStyle,
              },
            },
          ],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: {
              voiceName: finalVoiceName,
            },
          },
        },
      },
    });

    const inline = response.candidates?.[0]?.content?.parts?.[0]?.inlineData;
    const base64Audio = inline?.data ? pcmToWavBase64(inline.data, inline.mimeType) : undefined;

    if (!base64Audio) {
      throw new Error('No audio returned by Gemini TTS');
    }

    res.json({
      success: true,
      audioBase64: base64Audio,
      mimeType: 'audio/wav',
    });
  } catch (error: any) {
    console.error('Error generating realistic TTS:', error?.message);
    res.status(500).json({
      error: error?.message || 'فشل في توليد الصوت بواسطة الذكاء الاصطناعي',
      fallbackRecommended: true,
    });
  }
});

// AI Song & Music Lyrics Composer
app.post('/api/compose-song', async (req, res) => {
  try {
    const { prompt, genre = 'tarab', singerCharacter = 'zain_singer' } = req.body;

    const systemInstruction = `أنت ملحن موسيقي وكاتب أغانٍ عربي خبير في الموسيقى والمقامات (بياتي، حجاز، نهاوند، كورد، عجم).
مهمتك تحويل فكرة المستخدم أو كلماته إلى أغنية جميلة، راقية، ذات معانٍ عميقة ووزن شعري متزن ولحن شجي يطرب الأذن بدون أي صخب أو نشاز.
النوع الموسيقي: ${genre}
الصوت المغني: ${singerCharacter}

يجب أن ترجع استجابة JSON دقيقة بالبنية التالية:
{
  "title": "عنوان الأغنية بالعربية الفصحى أو اللهجة المطلوبة",
  "genre": "${genre}",
  "bpm": 96, // إيقاع هادئ ومنتظم بين 75 و 120
  "scale": "Hijaz" | "Bayati" | "Major" | "Minor" | "Pentatonic",
  "singerCharacter": "${singerCharacter}",
  "chorusCatchphrase": "مذهب أو جملة طربية مميزة ومؤثرة",
  "fullLyrics": "كلمات الأغنية موزونة ومرتبة",
  "sections": [
    {
      "sectionName": "المذهب / الكوبليه الأول / الكورال",
      "lyrics": "السطور المغناة برقة وعذوبة",
      "melodyNotes": ["C4", "D4", "E4", "F4", "G4", "F4", "E4", "D4", "C4"],
      "chords": ["Dm", "C", "Bb", "A7"],
      "energy": 0.85
    }
  ],
  "socialHook": "اقتباس جميل من الأغنية مناسب للمشاركة"
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `اكتب ولحن أغنية موسيقية راقية وعذبة حول: "${prompt || 'أغنية طربية عن جمال المساء وهدوء الروح والمشاعر الصادقة'}".
الطابع: ${genre}`,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
      },
    });

    const songData = JSON.parse(response.text || '{}');
    res.json({ success: true, song: songData });
  } catch (error: any) {
    console.error('Error composing song:', error?.message);
    // Provide a beautiful classical song fallback
    res.json({
      success: true,
      fallback: true,
      song: {
        title: 'نسيم الشوق والهدوء',
        genre: req.body.genre || 'tarab',
        bpm: 92,
        scale: 'Hijaz',
        singerCharacter: req.body.singerCharacter || 'laila_tarab',
        chorusCatchphrase: 'يا ليل يا عيني على سحر النغم.. يداوي كل ألم',
        fullLyrics: `تنساب نغمات العود في سكون الليل\nتداعب أرواحنا بنسيم الشوق والميل\nفي كل لحن حكاية صفاء وسلام\nتزهر في القلوب كأجمل الأحلام`,
        sections: [
          {
            sectionName: 'المذهب الطربي',
            lyrics: 'تنساب نغمات العود في سكون الليل، تداعب أرواحنا بنسيم الشوق والميل!',
            melodyNotes: ['D4', 'E4', 'F4', 'G4', 'F4', 'E4', 'D4'],
            chords: ['Dm', 'Gm', 'A7', 'Dm'],
            energy: 0.8,
          },
          {
            sectionName: 'الكوبليه الهادئ',
            lyrics: 'في كل لحن حكاية صفاء وسلام، تزهر في القلوب كأجمل الأحلام!',
            melodyNotes: ['F4', 'G4', 'A4', 'Bb4', 'A4', 'G4', 'F4', 'E4', 'D4'],
            chords: ['F', 'Bb', 'C', 'Dm'],
            energy: 0.9,
          },
        ],
        socialHook: 'لحن يأخذك إلى عالم من الهدوء والسلطنة 🎶✨',
      },
    });
  }
});

// Realistic Singing Audio Synthesis endpoint
app.post('/api/sing-track', async (req, res) => {
  try {
    const { lyrics, voiceId = 'zain_singer', voice = 'Fenrir', style } = req.body;

    const singingPrompt = style || `Sing melodiously and authentically in Arabic with pure vocal tone, natural acoustic vibrato, soulful emotional expression, and pitch accuracy like an esteemed Tarab artist singing: "${lyrics}"`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: lyrics.slice(0, 450),
              speechMetadata: {
                style: singingPrompt,
              },
            },
          ],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: {
              voiceName: voice || 'Fenrir',
            },
          },
        },
      },
    });

    const inline = response.candidates?.[0]?.content?.parts?.[0]?.inlineData;
    const base64Audio = inline?.data ? pcmToWavBase64(inline.data, inline.mimeType) : undefined;

    if (!base64Audio) {
      throw new Error('No audio returned by singing TTS');
    }

    res.json({
      success: true,
      audioBase64: base64Audio,
      mimeType: 'audio/wav',
    });
  } catch (error: any) {
    console.error('Error generating realistic singing track:', error?.message);
    res.status(500).json({
      error: error?.message || 'تعذر توليد صوت الغناء',
      fallbackRecommended: true,
    });
  }
});

// AI Realistic Dialogue Generator
app.post('/api/generate-dialogue', async (req, res) => {
  try {
    const { topic = 'نقاش ثقافي ودي', speakerAName = 'سارة', speakerBName = 'عمر' } = req.body;

    const systemInstruction = `أنت كاتب سيناريو وحوارات إذاعية محترف.
قم بكتابة حوار عربي طبيعي وواقعي، ذكي وممتع بين شخصيتين حول الموضوع المطلوب.
الشخصية الأولى: ${speakerAName}
الشخصية الثانية: ${speakerBName}

يجب أن ترجع استجابة JSON دقيقة بالبنية التالية:
{
  "title": "عنوان الحوار بالعربية",
  "lines": [
    { "speaker": "${speakerAName}", "speakerIndex": 0, "text": "نص الجملة الأولى" },
    { "speaker": "${speakerBName}", "speakerIndex": 1, "text": "نص الرد الطبيعي" },
    { "speaker": "${speakerAName}", "speakerIndex": 0, "text": "نص التعقيب" },
    { "speaker": "${speakerBName}", "speakerIndex": 1, "text": "نص الخاتمة" }
  ]
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `اكتب حواراً واقعياً متبادلاً بين ${speakerAName} و ${speakerBName} حول: "${topic}".`,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
      },
    });

    const data = JSON.parse(response.text || '{}');
    res.json({ success: true, dialogue: data });
  } catch (error: any) {
    console.error('Error generating dialogue:', error?.message);
    const { speakerAName = 'سارة', speakerBName = 'عمر', topic = 'لقاء ممتع' } = req.body;
    res.json({
      success: true,
      fallback: true,
      dialogue: {
        title: `حوار حول ${topic}`,
        lines: [
          { speaker: speakerAName, speakerIndex: 0, text: `مرحباً بك يا ${speakerBName}، سعيد جداً بلقائك اليوم لنناقش هذا الموضوع الشيق.` },
          { speaker: speakerBName, speakerIndex: 1, text: `أهلاً بك يا ${speakerAName}، وأنا كذلك متشوق لسماع وجهة نظرك في هذا الأمر.` },
          { speaker: speakerAName, speakerIndex: 0, text: 'أعتقد أن التجربة المشتركة وتبادل الأفكار بصدق يمنحاننا رؤية أعمق وأوضح دائماً.' },
          { speaker: speakerBName, speakerIndex: 1, text: 'أتفق معك تماماً، فالإنصات الواعي هو مفتاح كل حوار ناجح ونافع.' },
        ],
      },
    });
  }
});

async function startServer() {
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`Server running at http://0.0.0.0:${port}`);
  });
}

startServer();
