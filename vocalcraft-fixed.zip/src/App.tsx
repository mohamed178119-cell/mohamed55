import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { TtsStudio } from './components/TtsStudio';
import { SongStudio } from './components/SongStudio';
import { CartoonCorner } from './components/CartoonCorner';
import { LibraryModal } from './components/LibraryModal';
import { PWAInstallModal } from './components/PWAInstallModal';
import { SavedTrack } from './types';
import { useOnlineStatus } from './hooks/usePWAInstall';
import { Sparkles, CheckCircle, WifiOff } from 'lucide-react';

const STORAGE_KEY = 'soutak_realistic_tracks_v2';

// Realistic starter tracks
const INITIAL_DEMO_TRACKS: SavedTrack[] = [
  {
    id: 'demo_track_1',
    title: 'نسيم الشوق والهدوء (طرب أصيل)',
    content: 'تنساب نغمات العود في سكون الليل، تداعب أرواحنا بنسيم الشوق والميل! في كل لحن حكاية صفاء وسلام تزهر في القلوب كأجمل الأحلام.',
    type: 'song',
    characterId: 'zain_singer',
    genre: 'طرب وسلطنة',
    bpm: 92,
    duration: 22,
    createdAt: Date.now() - 3600000 * 2,
    formattedDate: 'اليوم، 10:30 ص',
  },
  {
    id: 'demo_track_2',
    title: 'خواطر مسائية عن راحة البال',
    content: 'بين ثنايا التاريخ الإنساني، بقيت هناك أسرارٌ كبرى تتحدى الزمن، والهدوء ليس غياباً للصوت بل حضورٌ أعمق لكل ما له معنى.',
    type: 'speech',
    characterId: 'omar_deep',
    genre: 'سرد وثائقي دافئ',
    bpm: 90,
    duration: 15,
    createdAt: Date.now() - 3600000 * 5,
    formattedDate: 'أمس، 08:15 م',
  },
  {
    id: 'demo_track_3',
    title: 'همس الأمل والبدايات النقية',
    content: 'في هدوء هذا المساء الجميل، ننصت لأجمل الحكايات التي تلامس القلوب وتبث الأمل في النفوس، فالحياة تبدو أجمل حين ننصت لتفاصيلها بكل امتنان.',
    type: 'speech',
    characterId: 'sara_melodic',
    genre: 'قراءة عذبة وناعمة',
    bpm: 95,
    duration: 18,
    createdAt: Date.now() - 3600000 * 12,
    formattedDate: 'أمس، 02:40 م',
  }
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'tts' | 'song' | 'cartoon' | 'library'>('tts');
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);
  const isOnline = useOnlineStatus();

  const [savedTracks, setSavedTracks] = useState<SavedTrack[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (_) {}
    return INITIAL_DEMO_TRACKS;
  });

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(savedTracks));
    } catch (_) {}
  }, [savedTracks]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleSaveTrack = (track: SavedTrack) => {
    setSavedTracks(prev => [track, ...prev]);
    showToast(`تم حفظ "${track.title}" في مكتبتك بنجاح! 💾`);
  };

  const handleDeleteTrack = (id: string) => {
    setSavedTracks(prev => prev.filter(t => t.id !== id));
    showToast('تم حذف المقطع من المكتبة');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-['Cairo',sans-serif] selection:bg-amber-500 selection:text-black">
      
      {/* Top Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        savedCount={savedTracks.length}
        onOpenInstallModal={() => setIsInstallModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10">
        
        {/* Tab 1: Real Text to Speech Studio */}
        {activeTab === 'tts' && (
          <TtsStudio onSaveTrack={handleSaveTrack} />
        )}

        {/* Tab 2: Realistic Song & Music Studio */}
        {activeTab === 'song' && (
          <SongStudio onSaveTrack={handleSaveTrack} />
        )}

        {/* Tab 3: Realistic Duets & Dialects */}
        {activeTab === 'cartoon' && (
          <CartoonCorner onSaveTrack={handleSaveTrack} />
        )}

        {/* Tab 4: Saved Library */}
        {activeTab === 'library' && (
          <LibraryModal
            tracks={savedTracks}
            onDeleteTrack={handleDeleteTrack}
            onNavigateToStudio={() => setActiveTab('tts')}
          />
        )}

      </main>

      {/* PWA & APK Installation Modal */}
      <PWAInstallModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
      />

      {/* Offline Toast Indicator */}
      {!isOnline && (
        <div className="fixed bottom-20 left-6 z-50 flex items-center gap-2.5 px-4 py-2.5 rounded-2xl bg-amber-600/90 text-white font-bold text-xs shadow-xl backdrop-blur-md border border-amber-400/40">
          <WifiOff className="w-4 h-4 animate-pulse" />
          <span>وضع عدم الاتصال — يتم استخدام البيانات المحفوظة محلياً</span>
        </div>
      )}

      {/* Quick Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-3 px-5 py-3 rounded-2xl bg-amber-500 text-slate-950 font-bold text-sm shadow-2xl animate-bounce">
          <Sparkles className="w-4 h-4 fill-current" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Studio Footer with APK Callout */}
      <footer className="border-t border-slate-900 bg-slate-950/90 py-8 px-4 sm:px-6 lg:px-8 mt-12 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <img
              src="/favicon.png"
              alt="أيقونة صوتك ونغم"
              className="w-6 h-6 rounded-lg"
            />
            <span className="font-bold text-slate-300 font-['Tajawal'] text-sm">
              صوتك ونغم - استوديو تحويل النصوص إلى أصوات واقعية طبيعية وأغاني طربية راقية
            </span>
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <button
              onClick={() => setIsInstallModalOpen(true)}
              className="text-emerald-400 hover:text-emerald-300 font-bold underline transition-colors"
            >
              📱 تثبيت التطبيق على الهاتف (APK)
            </button>
            <span>•</span>
            <span className="flex items-center gap-1.5 text-slate-400">
              <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
              أصوات بشرية واقعية نقية
            </span>
            <span>•</span>
            <span>📱 تصدير فوري لـ TikTok و Instagram و WhatsApp</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
