import { MusicGenre } from '../types';

export const MUSIC_GENRES: MusicGenre[] = [
  {
    id: 'tarab',
    name: 'طرب وسلطنة شرقية',
    nameEn: 'Oriental Tarab & Oud',
    icon: '🪕',
    bpm: 92,
    scale: 'Bayati',
    description: 'ألحان عود أصيل مع تقاسيم عذبة وإيقاع مقسوم هادئ يأسر القلوب.',
    color: 'from-amber-600 to-amber-800',
    drumPattern: 'oriental_maqsum',
    sampleKeywords: ['ليالي الطرب', 'يا ليل يا عين', 'شوق وسلام', 'سحر النغم']
  },
  {
    id: 'acoustic_pop',
    name: 'بوب عربي ناعم وهادئ',
    nameEn: 'Soft Acoustic Pop',
    icon: '🎸',
    bpm: 104,
    scale: 'Major',
    description: 'نغمات جيتار وبيانو رقيقة مع إيقاع راقص خفيف يبعث على البهجة والتفاؤل.',
    color: 'from-pink-500 to-rose-600',
    drumPattern: 'soft_pop',
    sampleKeywords: ['صباح الأمل', 'ابتسم للحياة', 'حلم جميل', 'راحة البال']
  },
  {
    id: 'andalusian',
    name: 'موشحات وموسيقى أندلسية',
    nameEn: 'Andalusian & Qanun',
    icon: '🏛️',
    bpm: 88,
    scale: 'Hijaz',
    description: 'نغمات قانون ورق أصيل مستوحاة من بساتين قرطبة وجمال الموشحات الكلاسيكية.',
    color: 'from-emerald-600 to-teal-800',
    drumPattern: 'andalusian_samai',
    sampleKeywords: ['شمس الأصيل', 'عطر الياسمين', 'نسيم الأندلس', 'وجد وحنين']
  },
  {
    id: 'ballad_poetry',
    name: 'وجدانيات وشعر بالبيانو',
    nameEn: 'Soulful Ballad & Piano',
    icon: '🎹',
    bpm: 78,
    scale: 'Minor',
    description: 'بيانو دافئ مع وتريات شجية تلامس الوجدان، مخصصة للقصائد العاطفية الراقية.',
    color: 'from-purple-600 to-indigo-800',
    drumPattern: 'slow_ballad',
    sampleKeywords: ['حديث الروح', 'سكون الليل', 'همس القلوب', 'ذكرى غالية']
  },
  {
    id: 'khaleeji',
    name: 'إيقاع خليجي راقٍ',
    nameEn: 'Prestigious Khaleeji',
    icon: '🦅',
    bpm: 98,
    scale: 'Bayati',
    description: 'إيقاع السامري والصوت الفخم مع العود الأصيل والمقامات الخليجية الأصيلة.',
    color: 'from-yellow-600 to-amber-700',
    drumPattern: 'khaleeji_samri',
    sampleKeywords: ['هلا بالطيب', 'عز وفخر', 'كرم وأصالة', 'نور الفجر']
  },
  {
    id: 'ambient_doc',
    name: 'موسيقى وثائقية وتأملية',
    nameEn: 'Ambient & Meditative',
    icon: '🌌',
    bpm: 72,
    scale: 'Pentatonic',
    description: 'أجواء صوتية أثيرية هادئة تناسب التأمل، الاسترخاء، والسرد الوثائقي الهادف.',
    color: 'from-cyan-600 to-blue-800',
    drumPattern: 'ambient_drift',
    sampleKeywords: ['تأمل وسلام', 'أعماق الكون', 'أسرار الطبيعة', 'هدوء تام']
  },
  {
    id: 'egyptian_warm',
    name: 'طابع مصري أصيل ومبهج',
    nameEn: 'Warm Egyptian Melody',
    icon: '☀️',
    bpm: 110,
    scale: 'Major',
    description: 'إيقاع بلدي لطيف ومقسوم ناعم يحمل روح الحارة المصرية والبهجة الدافئة.',
    color: 'from-orange-500 to-amber-600',
    drumPattern: 'egyptian_baladi',
    sampleKeywords: ['يا حلاوة اللمة', 'فرحة الأحباب', 'ضحكة من القلب', 'مساء الجمال']
  },
  {
    id: 'lofi_chill',
    name: 'لو-فاي شرقي هادئ',
    nameEn: 'Oriental Lo-Fi Chill',
    icon: '☕',
    bpm: 76,
    scale: 'Minor',
    description: 'مزيج هادئ من نغمات الفينيل والعود العصري المريح للمذاكرة والتركيز.',
    color: 'from-sky-600 to-slate-700',
    drumPattern: 'lofi_chill',
    sampleKeywords: ['قهوة الصباح', 'سحاب ومطر', 'لحظة هدوء', 'أفكار ملهمة']
  }
];
