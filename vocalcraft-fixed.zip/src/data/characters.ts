import { RealisticVoice } from '../types';

export const REALISTIC_VOICES: RealisticVoice[] = [
  {
    id: 'sara_melodic',
    name: 'سارة - صوت نسائي عذب وناعم',
    nameEn: 'Sara (Gentle & Melodic Female)',
    gender: 'female',
    dialect: 'فصحى متقنة',
    tone: 'عذب وهادئ',
    category: 'narration',
    description: 'صوت أنثوي فائق النقاء، دافئ ومريح للأذن، مثالي لقراءة الروايات والقصص الهادئة والكتب الصوتية.',
    avatarIcon: '🌸',
    badge: 'فصحى عذبة',
    colorClass: 'from-rose-500 to-pink-600 border-rose-400 text-white',
    accentHex: '#f43f5e',
    glowColor: 'rgba(244, 63, 94, 0.4)',
    samplePhrases: [
      'في هدوء هذا المساء، تبدأ أجمل الحكايات التي تلامس القلوب.',
      'أهلاً بكم في رحلتنا اليوم، حيث تلتقي الكلمات بأعذب الألحان.',
      'الحياة تبدو أجمل حين ننصت لتفاصيلها الصغيرة بكل امتنان وسلام.',
      'صفحة جديدة نفتحها معاً، مليئة بالأمل والجمال الذي لا ينتهي.'
    ],
    geminiVoice: 'Kore',
    stylePrompt: 'Speak naturally in pristine, elegant, soothing Arabic with gentle breathing, warm emotional resonance, and crystal-clear pronunciation like a professional audio-book narrator.',
    singingPrompt: 'Sing in a soft, delicate, melodious Arab female voice with gentle vibrato and acoustic warmth.'
  },
  {
    id: 'omar_deep',
    name: 'عمر - صوت رجالي دافئ ورخيم',
    nameEn: 'Omar (Warm Deep Male)',
    gender: 'male',
    dialect: 'فصحى متقنة',
    tone: 'دافئ ورخيم',
    category: 'narration',
    description: 'صوت رجالي عميق ووقور، نبرة دافئة ذات صدى فخم، ممتاز للسرد الوثائقي والخواطر الفلسفية.',
    avatarIcon: '🎙️',
    badge: 'صوت رخيم',
    colorClass: 'from-amber-600 to-amber-800 border-amber-400 text-white',
    accentHex: '#d97706',
    glowColor: 'rgba(217, 119, 6, 0.4)',
    samplePhrases: [
      'بين ثنايا التاريخ، بقيت هناك أسرارٌ تنتظر من يكتشف حقيقتها.',
      'الهدوء ليس غياباً للصوت، بل هو حضورٌ أعمق لكل ما له معنى.',
      'استمع إلى صوت عقلك، فالحكمة تأتي دائماً لمن يحسن الإنصات.',
      'مرحباً بكم مستمعينا الأعزاء في هذا المقطع الخاص من أعماق المعرفة.'
    ],
    geminiVoice: 'Fenrir',
    stylePrompt: 'Deep, resonant, rich, velvet-smooth Arabic male speaker with steady cadence, warm vocal timbre, and natural articulation.',
    singingPrompt: 'Sing as a deep, resonant Arab baritone with classical Tarab warmth and soulful pitch control.'
  },
  {
    id: 'yasmine_doc',
    name: 'ياسمين - معلقة وثائقية محترفة',
    nameEn: 'Yasmine (Documentary Narrator)',
    gender: 'female',
    dialect: 'فصحى متقنة',
    tone: 'وثائقي محترف',
    category: 'narration',
    description: 'نبرة استكشافية مشوقة كالتي تسمعها في ناشيونال جيوغرافيك، تسحر السامع بدقة الأداء والتشويق.',
    avatarIcon: '🌍',
    badge: 'وثائقي احترافي',
    colorClass: 'from-emerald-500 to-teal-700 border-emerald-400 text-white',
    accentHex: '#10b981',
    glowColor: 'rgba(16, 185, 129, 0.4)',
    samplePhrases: [
      'هنا في أعالي الجبال الشاهقة، تبدأ رحلة البقاء لأغرب الكائنات الحية.',
      'عبر آلاف السنين، شيدت الحضارات أعظم المعالم التي تحدت الزمن.',
      'لكل سر في الطبيعة حكاية، وها نحن نغوص اليوم في أعمق أسرارها.'
    ],
    geminiVoice: 'Kore',
    stylePrompt: 'Professional documentary narrator, authoritative yet captivating, expressive pacing with dramatic natural pauses.',
    singingPrompt: 'Harmonious, rich cinematic vocal performance with elegant modern acoustic Arabic styling.'
  },
  {
    id: 'karim_youth',
    name: 'كريم - صوت شاب عصري وودي',
    nameEn: 'Karim (Friendly Modern Youth)',
    gender: 'male',
    dialect: 'فصحى متقنة',
    tone: 'عفوي شبابي',
    category: 'conversation',
    description: 'صوت شاب متفائل وعفوي، نبرة طبيعية جداً تشبه حديث صديق في بودكاست شبابي خفيف.',
    avatarIcon: '✨',
    badge: 'بودكاست شبابي',
    colorClass: 'from-blue-500 to-cyan-600 border-blue-400 text-white',
    accentHex: '#3b82f6',
    glowColor: 'rgba(59, 130, 246, 0.4)',
    samplePhrases: [
      'يا هلا بالجميع! جاهزين لتجربة ممتعة ومختلفة تماماً النهاردة؟',
      'دائماً خليك فاكر إن البدايات الصغيرة هي اللي بتصنع الإنجازات الكبيرة!',
      'فكرة بسيطة ممكن تغير يومك كله، جرب وشوف الفرق بنفسك!'
    ],
    geminiVoice: 'Puck',
    stylePrompt: 'Natural, cheerful, enthusiastic, conversational young Arabic speaker, completely fluent and authentic.',
    singingPrompt: 'Catchy, energetic, upbeat pop vocal performance with lively modern rhythm.'
  },
  {
    id: 'laila_tarab',
    name: 'ليلى - قراءة شعرية وطربية راقية',
    nameEn: 'Laila (Poetic & Tarab)',
    gender: 'female',
    dialect: 'فصحى متقنة',
    tone: 'طربي شجي',
    category: 'poetry',
    description: 'صوت شجي مليء بالإحساس، مخارج حروف عربية فصيحة مشحونة بالعاطفة لقصائد الحب والشوق.',
    avatarIcon: '🪕',
    badge: 'شعر وسلطنة',
    colorClass: 'from-purple-500 to-indigo-700 border-purple-400 text-white',
    accentHex: '#a855f7',
    glowColor: 'rgba(168, 85, 247, 0.4)',
    samplePhrases: [
      'أراك عصي الدمع شيمتك الصبر، أما للهوى نهيٌ عليك ولا أمرُ؟',
      'يا ليل الصب متى غده، أقيام الساعة موعده؟',
      'في كل حرف أكتبه، هناك نبضٌ يبحث عنك في زحام الأيام.'
    ],
    geminiVoice: 'Zephyr',
    stylePrompt: 'Deeply expressive, emotional, poetic recitation in pristine Classical Arabic with musical cadence.',
    singingPrompt: 'Authentic classical Tarab singing in Maqam Bayati with graceful microtonal inflections and pure acoustic emotion.'
  },
  {
    id: 'tariq_news',
    name: 'طارق - مذيع إذاعة ونشرة أخبار',
    nameEn: 'Tariq (Formal Broadcaster)',
    gender: 'male',
    dialect: 'فصحى متقنة',
    tone: 'إذاعي فصيح',
    category: 'broadcast',
    description: 'صوت مذيع نشرة أخبار محترف، مخارج حروف رصينة، نبرة واثقة وفصيحة تنقل المعلومة بأعلى مصداقية.',
    avatarIcon: '📻',
    badge: 'إذاعة وأخبار',
    colorClass: 'from-slate-700 to-slate-900 border-slate-500 text-white',
    accentHex: '#94a3b8',
    glowColor: 'rgba(148, 163, 184, 0.4)',
    samplePhrases: [
      'سيداتي وسادتي، طابت أوقاتكم بكل خير، إليكم النشرة المفصلة لأهم الأحداث.',
      'نوافيكم الآن بتطورات المشهد لحظة بلحظة من غرفة الأخبار الرئيسية.',
      'هذا تقرير خاص يسلط الضوء على أبرز المنجزات الاقتصادية والتقنية.'
    ],
    geminiVoice: 'Charon',
    stylePrompt: 'Crisp, authoritative, articulate broadcast journalist speaking standard formal Arabic with impeccable diction.',
    singingPrompt: 'Solemn, powerful theatrical Arab baritone performance with clear diction.'
  },
  {
    id: 'mariam_egyptian',
    name: 'مريم - لهجة مصرية عذبة وودودة',
    nameEn: 'Mariam (Natural Egyptian Dialect)',
    gender: 'female',
    dialect: 'لهجة مصرية',
    tone: 'عذب وهادئ',
    category: 'conversation',
    description: 'نبرة مصرية دافئة، خفيفة الظل وقريبة من القلب، تعبر عن الألفة والبهجة بأسلوب طبيعي واقعي.',
    avatarIcon: '☀️',
    badge: 'لهجة مصرية',
    colorClass: 'from-amber-400 to-orange-500 border-amber-300 text-amber-950',
    accentHex: '#f59e0b',
    glowColor: 'rgba(245, 158, 11, 0.4)',
    samplePhrases: [
      'يا صباح الفل والياسمين على أحلى ناس في الدنيا، يومكم جميل وسعيد!',
      'الدنيا ما تستاهلش زعل، اضحك وخلي الفرحة تدخل قلبك النهاردة.',
      'لما تفكر فيها صح، هتلاقي إن راحة البال هي أحلى مكسب ممكن تكسبه!'
    ],
    geminiVoice: 'Kore',
    stylePrompt: 'Warm, natural, lively Egyptian dialect Arabic speaker, speaking comfortably like a loving friend, charming and realistic.',
    singingPrompt: 'Lively, joyful Egyptian melody with cheerful rhythmic cadence and genuine vocal warmth.'
  },
  {
    id: 'sultan_gulf',
    name: 'سلطان - لهجة خليجية فخمة وهادئة',
    nameEn: 'Sultan (Prestige Gulf Dialect)',
    gender: 'male',
    dialect: 'لهجة خليجية',
    tone: 'دافئ ورخيم',
    category: 'conversation',
    description: 'صوت خليجي رزين وراقي، إلقاء هادئ يجمع بين الكرم والأصالة، ممتاز للتقديم الراقي والإعلانات الفخمة.',
    avatarIcon: '🦅',
    badge: 'لهجة خليجية',
    colorClass: 'from-amber-600 via-yellow-600 to-amber-700 border-yellow-400 text-white',
    accentHex: '#eab308',
    glowColor: 'rgba(234, 179, 8, 0.4)',
    samplePhrases: [
      'يا هلا ومرحبا، مساكم الله بالخير والنور والسرور جميعاً.',
      'الطيب والأصل ما يتغيرون مع الوقت، والرجال مواقف وأفعال قبل الكلام.',
      'يسرنا أن نقدم لكم هذه التجربة المميزة التي تليق بذائقتكم الرفيعة.'
    ],
    geminiVoice: 'Charon',
    stylePrompt: 'Prestigious, polite, deep Gulf Arabic speaker with noble and hospitable cadence, warm and authentic.',
    singingPrompt: 'Noble Gulf vocal performance (Sawt / Samri / Khaleeji) with graceful oud accompaniment style.'
  },
  {
    id: 'nour_levant',
    name: 'نور - لهجة شامية ناعمة ولطيفة',
    nameEn: 'Nour (Smooth Levantine Dialect)',
    gender: 'female',
    dialect: 'لهجة شامية',
    tone: 'عذب وهادئ',
    category: 'conversation',
    description: 'صوت شامي ناعم ومريح للأعصاب، ينبض بالرقة والعذوبة كنسيم الصباح العليل في دمشق وبيروت.',
    avatarIcon: '🌿',
    badge: 'لهجة شامية',
    colorClass: 'from-teal-400 to-emerald-600 border-teal-300 text-teal-950',
    accentHex: '#14b8a6',
    glowColor: 'rgba(20, 184, 166, 0.4)',
    samplePhrases: [
      'يسعدلي صباحكم ومساكم، شو حلو إنو نبلش نهارنا بكلمة طيبة وابتسامة!',
      'الحياة بتبسط لما بنعيشها برواق ونحب الخير لكل العالم حوالينا.',
      'فنجان قهوة الصبح وكلمة دافية، بتكفي لترجع الأمل لقلوبنا كل يوم.'
    ],
    geminiVoice: 'Zephyr',
    stylePrompt: 'Gentle, soft, charming Levantine (Syrian/Lebanese) Arabic speaker with melodic, friendly, relaxing cadence.',
    singingPrompt: 'Soft acoustic Levantine folk singing with delicate acoustic guitar and flute accompaniment.'
  },
  {
    id: 'zain_singer',
    name: 'زين - مطرب ومغنٍ طربي شجي',
    nameEn: 'Zain (Authentic Arabic Vocalist)',
    gender: 'male',
    dialect: 'فصحى متقنة',
    tone: 'طربي شجي',
    category: 'singing',
    description: 'صوت غنائي عربي أصيل، مشبع بالنغمات الطربية الشرقية والمقامات الكلاسيكية العذبة.',
    avatarIcon: '🎵',
    badge: 'مطرب طربي',
    colorClass: 'from-rose-600 via-purple-600 to-indigo-700 border-rose-400 text-white',
    accentHex: '#e11d48',
    glowColor: 'rgba(225, 29, 72, 0.4)',
    samplePhrases: [
      'يا ليل يا عين.. تمايل النغم مع نسيم الصباح العليل.',
      'بين أوتار العود ولحن الحجاز، تتجدد أجمل الذكريات في كل مساء.',
      'سلامٌ على من يسمع النغم فيطرب، ومن يقرأ الحرف فيعشق.'
    ],
    geminiVoice: 'Fenrir',
    stylePrompt: 'Soulful Arabic vocalist with melodic intonation, resonant vocal chords and natural acoustic vibrato.',
    singingPrompt: 'Masterful Arabic singer performing with authentic Tarab ornamentation, soulful emotional depth and rhythmic mastery.'
  }
];

// Alias for backwards compatibility
export const CHARACTERS = REALISTIC_VOICES;
