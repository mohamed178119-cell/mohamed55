export interface RealisticVoice {
  id: string;
  name: string;
  nameEn: string;
  gender: 'female' | 'male';
  dialect: 'فصحى متقنة' | 'لهجة مصرية' | 'لهجة خليجية' | 'لهجة شامية';
  tone: string;
  category: 'narration' | 'broadcast' | 'poetry' | 'conversation' | 'singing';
  description: string;
  avatarIcon: string;
  badge: string;
  colorClass: string;
  accentHex: string;
  glowColor: string;
  samplePhrases: string[];
  geminiVoice: 'Kore' | 'Puck' | 'Charon' | 'Fenrir' | 'Zephyr';
  stylePrompt: string;
  singingPrompt: string;
}

// Backward compatibility alias for UI references
export type Character = RealisticVoice;

export interface MusicGenre {
  id: string;
  name: string;
  nameEn: string;
  icon: string;
  bpm: number;
  scale: 'Hijaz' | 'Bayati' | 'Major' | 'Minor' | 'Pentatonic';
  description: string;
  color: string;
  drumPattern: string;
  sampleKeywords: string[];
}

export interface SongSection {
  sectionName: string;
  lyrics: string;
  melodyNotes: string[];
  chords: string[];
  energy: number;
}

export interface SongData {
  id: string;
  title: string;
  genre: string;
  bpm: number;
  scale: string;
  singerCharacter: string;
  chorusCatchphrase: string;
  fullLyrics: string;
  sections: SongSection[];
  soundFx?: string[];
  socialHook?: string;
  vocalAudioBase64?: string;
  createdAt: number;
}

export interface AudioSettings {
  speed: number;
  pitch: number;
  reverb: number;
  bassBoost: number;
  presence: number;
}

export interface SavedTrack {
  id: string;
  title: string;
  content: string;
  type: 'speech' | 'song';
  characterId: string;
  genre?: string;
  bpm?: number;
  audioBase64?: string;
  duration: number;
  createdAt: number;
  formattedDate: string;
}

export interface SocialExportOptions {
  platform: 'tiktok' | 'reels' | 'whatsapp' | 'youtube' | 'facebook' | 'telegram' | 'x';
  aspectRatio: '9:16' | '1:1' | '16:9';
  includeSubtitles: boolean;
  includeAvatar: boolean;
  includeVisualizer: boolean;
  backgroundColor: string;
}
