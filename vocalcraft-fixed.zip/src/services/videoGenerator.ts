import { Character, SongData } from '../types';
import { audioEngine } from './audioEngine';

export interface RenderVideoParams {
  title: string;
  character: Character;
  lyrics: string;
  songData?: SongData | null;
  aspectRatio: '9:16' | '1:1' | '16:9';
  durationSeconds: number;
  onProgress?: (percent: number) => void;
}

export class SocialVideoGenerator {
  public static async generateSocialVideo({
    title,
    character,
    lyrics,
    songData,
    aspectRatio,
    durationSeconds,
    onProgress
  }: RenderVideoParams): Promise<Blob> {
    return new Promise((resolve, reject) => {
      let width = 720;
      let height = 1280; // 9:16 vertical by default

      if (aspectRatio === '1:1') {
        width = 1080;
        height = 1080;
      } else if (aspectRatio === '16:9') {
        width = 1280;
        height = 720;
      }

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');

      if (!ctx) {
        reject(new Error('Cannot create 2D canvas context'));
        return;
      }

      // Prepare audio stream from audioEngine
      audioEngine.init();
      const audioStream = audioEngine.getMediaStream();

      // Canvas stream
      const canvasStream = canvas.captureStream(30); // 30 fps
      const combinedTracks: MediaStreamTrack[] = [...canvasStream.getVideoTracks()];

      if (audioStream && audioStream.getAudioTracks().length > 0) {
        combinedTracks.push(audioStream.getAudioTracks()[0]);
      }

      const combinedStream = new MediaStream(combinedTracks);

      const mimeTypes = [
        'video/webm;codecs=vp9,opus',
        'video/webm;codecs=vp8,opus',
        'video/webm',
        'video/mp4'
      ];
      let selectedMime = mimeTypes.find(m => MediaRecorder.isTypeSupported(m)) || 'video/webm';

      const recorder = new MediaRecorder(combinedStream, {
        mimeType: selectedMime,
        videoBitsPerSecond: 2500000,
      });

      const chunks: Blob[] = [];
      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          chunks.push(e.data);
        }
      };

      recorder.onstop = () => {
        const finalBlob = new Blob(chunks, { type: selectedMime });
        resolve(finalBlob);
      };

      recorder.start();

      const startTime = performance.now();
      const totalDurationMs = Math.max(5000, durationSeconds * 1000);

      // Split lyrics into lines for karaoke subtitles
      const lines = lyrics
        .split('\n')
        .map(l => l.trim())
        .filter(l => l.length > 0);
      
      const linesCount = Math.max(1, lines.length);
      const lineDurationMs = totalDurationMs / linesCount;

      let animationFrameId: number;

      function renderFrame(now: number) {
        const elapsed = now - startTime;
        const progress = Math.min(1.0, elapsed / totalDurationMs);

        if (onProgress) {
          onProgress(Math.floor(progress * 100));
        }

        // Draw Background Gradient (Elegant Studio Aesthetic)
        const grad = ctx!.createLinearGradient(0, 0, width, height);
        grad.addColorStop(0, '#030712');
        grad.addColorStop(0.5, '#0f172a');
        grad.addColorStop(1, '#1e1b4b');
        ctx!.fillStyle = grad;
        ctx!.fillRect(0, 0, width, height);

        // Animated particles / sparkles
        ctx!.fillStyle = 'rgba(255, 255, 255, 0.15)';
        for (let i = 0; i < 25; i++) {
          const px = (Math.sin(elapsed * 0.001 + i) * 0.5 + 0.5) * width;
          const py = ((elapsed * 0.05 + i * 40) % height);
          ctx!.beginPath();
          ctx!.arc(px, py, (i % 3) + 2, 0, Math.PI * 2);
          ctx!.fill();
        }

        // Header: Brand & Track Title
        ctx!.textAlign = 'center';
        ctx!.fillStyle = '#f8fafc';
        ctx!.font = 'bold 36px Cairo, Tajawal, sans-serif';
        ctx!.fillText(title || 'نغمة بالذكاء الاصطناعي', width / 2, height * 0.1);

        // Character Badge
        ctx!.fillStyle = character.accentHex || '#f59e0b';
        ctx!.font = '600 24px Cairo, sans-serif';
        ctx!.fillText(`${character.avatarIcon} ${character.name}`, width / 2, height * 0.15);

        // Center: Animated Character Avatar with pulsing aura
        const avatarSize = 140;
        const bounce = Math.sin(elapsed * 0.008) * 15;
        const centerX = width / 2;
        const centerY = height * 0.38 + bounce;

        // Glowing outer circle aura
        const auraGrad = ctx!.createRadialGradient(centerX, centerY, 50, centerX, centerY, avatarSize + 30);
        auraGrad.addColorStop(0, character.glowColor || 'rgba(245, 158, 11, 0.8)');
        auraGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx!.fillStyle = auraGrad;
        ctx!.beginPath();
        ctx!.arc(centerX, centerY, avatarSize + 30, 0, Math.PI * 2);
        ctx!.fill();

        // Inner circle
        ctx!.fillStyle = '#0f172a';
        ctx!.strokeStyle = character.accentHex || '#facc15';
        ctx!.lineWidth = 6;
        ctx!.beginPath();
        ctx!.arc(centerX, centerY, avatarSize / 2, 0, Math.PI * 2);
        ctx!.fill();
        ctx!.stroke();

        // Big emoji inside
        ctx!.font = '64px sans-serif';
        ctx!.textBaseline = 'middle';
        ctx!.fillText(character.avatarIcon, centerX, centerY);
        ctx!.textBaseline = 'alphabetic';

        // Animated Audio Waveform Bars
        const freqData = audioEngine.getVisualizerData();
        const barsCount = 36;
        const barWidth = (width * 0.8) / barsCount;
        const startX = width * 0.1;
        const visualizerBaseY = height * 0.62;

        for (let b = 0; b < barsCount; b++) {
          const val = freqData[b % freqData.length] || 40;
          const barHeight = Math.max(8, (val / 255) * (height * 0.15));
          const bx = startX + b * barWidth;
          const by = visualizerBaseY - barHeight / 2;

          ctx!.fillStyle = b % 2 === 0 ? character.accentHex : '#38bdf8';
          ctx!.fillRect(bx, by, barWidth - 4, barHeight);
        }

        // Subtitles / Karaoke Section
        const currentLineIndex = Math.min(linesCount - 1, Math.floor(elapsed / lineDurationMs));
        const currentText = lines[currentLineIndex] || '...';

        // Subtitle card background
        const subBoxY = height * 0.72;
        const subBoxH = height * 0.14;
        ctx!.fillStyle = 'rgba(0, 0, 0, 0.65)';
        ctx!.roundRect(width * 0.08, subBoxY, width * 0.84, subBoxH, 20);
        ctx!.fill();

        ctx!.strokeStyle = 'rgba(255, 255, 255, 0.2)';
        ctx!.lineWidth = 2;
        ctx!.stroke();

        // Subtitle text (glow effect)
        ctx!.shadowColor = character.accentHex;
        ctx!.shadowBlur = 12;
        ctx!.fillStyle = '#ffffff';
        ctx!.font = 'bold 32px Cairo, Tajawal, sans-serif';
        ctx!.fillText(currentText, width / 2, subBoxY + subBoxH * 0.58);
        ctx!.shadowBlur = 0;

        // Footer Social Tags & Branding
        ctx!.font = '500 20px Cairo, sans-serif';
        ctx!.fillStyle = 'rgba(255, 255, 255, 0.7)';
        ctx!.fillText('صوتك ونغم • تيك توك وريلز @SoutakApp', width / 2, height * 0.94);

        if (elapsed < totalDurationMs) {
          animationFrameId = requestAnimationFrame(renderFrame);
        } else {
          recorder.stop();
        }
      }

      animationFrameId = requestAnimationFrame(renderFrame);
    });
  }
}
