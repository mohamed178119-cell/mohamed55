import { AudioSettings, SongData, RealisticVoice } from '../types';

// Musical Note to Frequency mapping
const NOTE_FREQS: Record<string, number> = {
  'C3': 130.81, 'C#3': 138.59, 'D3': 146.83, 'D#3': 155.56, 'E3': 164.81, 'F3': 174.61, 'F#3': 185.00, 'G3': 196.00, 'G#3': 207.65, 'A3': 220.00, 'A#3': 233.08, 'B3': 246.94,
  'C4': 261.63, 'C#4': 277.18, 'D4': 293.66, 'D#4': 311.13, 'E4': 329.63, 'F4': 349.23, 'F#4': 369.99, 'G4': 392.00, 'G#4': 415.30, 'A4': 440.00, 'A#4': 466.16, 'B4': 493.88,
  'C5': 523.25, 'C#5': 554.37, 'D5': 587.33, 'D#5': 622.25, 'E5': 659.25, 'F5': 698.46, 'F#5': 739.99, 'G5': 783.99, 'G#5': 830.61, 'A5': 880.00, 'A#5': 932.33, 'B5': 987.77,
};

class AudioEngineService {
  private ctx: AudioContext | null = null;
  public analyser: AnalyserNode | null = null;
  private masterGain: GainNode | null = null;
  private mediaDest: MediaStreamAudioDestinationNode | null = null;
  private currentSource: AudioBufferSourceNode | null = null;
  private isPlayingMusic = false;
  private activeOscillators: OscillatorNode[] = [];
  private activeTimeouts: number[] = [];
  
  // Track mixer gain nodes
  public vocalGain: GainNode | null = null;
  public melodyGain: GainNode | null = null;
  public drumsGain: GainNode | null = null;
  public bassGain: GainNode | null = null;

  public init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioCtx();
      
      this.analyser = this.ctx.createAnalyser();
      this.analyser.fftSize = 256;
      this.analyser.smoothingTimeConstant = 0.85;

      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = 0.95;

      this.vocalGain = this.ctx.createGain();
      this.melodyGain = this.ctx.createGain();
      this.drumsGain = this.ctx.createGain();
      this.bassGain = this.ctx.createGain();

      this.mediaDest = this.ctx.createMediaStreamDestination();

      this.vocalGain.connect(this.masterGain);
      this.melodyGain.connect(this.masterGain);
      this.drumsGain.connect(this.masterGain);
      this.bassGain.connect(this.masterGain);

      this.masterGain.connect(this.analyser);
      this.analyser.connect(this.ctx.destination);
      this.analyser.connect(this.mediaDest);
    }

    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public getContext(): AudioContext {
    this.init();
    return this.ctx!;
  }

  public getMediaStream(): MediaStream | null {
    this.init();
    return this.mediaDest ? this.mediaDest.stream : null;
  }

  // Pure, natural playback of realistic studio audio without distortion
  public async playAudioBuffer(
    buffer: AudioBuffer,
    settings: AudioSettings,
    onEnded?: () => void
  ) {
    this.init();
    this.stopPlayback();

    const ctx = this.ctx!;
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    this.currentSource = source;

    // Natural playback rate
    source.playbackRate.value = Math.max(0.7, Math.min(1.5, settings.speed || 1.0));

    source.onended = () => {
      if (onEnded) onEnded();
    };

    let lastNode: AudioNode = source;

    // Optional Warm Bass / Body Enhancement (Acoustic warmth, not distortion)
    if (settings.bassBoost && settings.bassBoost > 0) {
      const bassEq = ctx.createBiquadFilter();
      bassEq.type = 'lowshelf';
      bassEq.frequency.value = 220;
      bassEq.gain.value = settings.bassBoost * 4; // subtle warmth
      lastNode.connect(bassEq);
      lastNode = bassEq;
    }

    // Optional Soft Room Reverb for natural space
    if (settings.reverb && settings.reverb > 0.05) {
      const convolver = ctx.createConvolver();
      convolver.buffer = this.createImpulseResponse(1.5, 2.5);
      
      const wetGain = ctx.createGain();
      wetGain.gain.value = settings.reverb * 0.4;
      const dryGain = ctx.createGain();
      dryGain.gain.value = 1.0;

      lastNode.connect(dryGain);
      lastNode.connect(convolver);
      convolver.connect(wetGain);

      const mixer = ctx.createGain();
      dryGain.connect(mixer);
      wetGain.connect(mixer);
      lastNode = mixer;
    }

    lastNode.connect(this.vocalGain!);
    source.start();
  }

  // Play base64 WAV audio (from Gemini TTS or user recordings)
  public async playBase64Audio(
    base64Data: string,
    settings: AudioSettings,
    onEnded?: () => void
  ) {
    this.init();
    try {
      const binaryString = atob(base64Data);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const audioBuffer = await this.ctx!.decodeAudioData(bytes.buffer.slice(0));
      await this.playAudioBuffer(audioBuffer, settings, onEnded);
      return audioBuffer;
    } catch (e) {
      console.error('Error decoding/playing base64 audio:', e);
      throw e;
    }
  }

  public stopPlayback() {
    if (this.currentSource) {
      try {
        this.currentSource.stop();
        this.currentSource.disconnect();
      } catch (_) {}
      this.currentSource = null;
    }

    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }

    this.isPlayingMusic = false;
    this.activeTimeouts.forEach(t => clearTimeout(t));
    this.activeTimeouts = [];

    this.activeOscillators.forEach(osc => {
      try {
        osc.stop();
        osc.disconnect();
      } catch (_) {}
    });
    this.activeOscillators = [];
  }

  // Get real available system voices for Arabic or high-definition speech
  public getAvailableSystemVoices(): SpeechSynthesisVoice[] {
    if (!('speechSynthesis' in window)) return [];
    const all = window.speechSynthesis.getVoices();
    // Deduplicate voices by unique identifier
    const seen = new Set<string>();
    const uniqueVoices = all.filter((v) => {
      const id = `${v.voiceURI || v.name}__${v.lang}`;
      if (seen.has(id)) return false;
      seen.add(id);
      return true;
    });

    // Sort so Arabic voices and natural voices come first
    return uniqueVoices.sort((a, b) => {
      const aAr = a.lang.startsWith('ar');
      const bAr = b.lang.startsWith('ar');
      if (aAr && !bAr) return -1;
      if (!aAr && bAr) return 1;
      return a.name.localeCompare(b.name);
    });
  }

  // Speak using high quality natural Arabic speech synthesis
  public speakNative(
    text: string,
    settings: AudioSettings,
    targetVoice?: RealisticVoice,
    preferredVoiceUri?: string,
    onEnded?: () => void
  ) {
    if (!('speechSynthesis' in window)) {
      alert('المتصفح لا يدعم ميزة تحويل النص لصوت');
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);

    const voices = window.speechSynthesis.getVoices();
    const arabicVoices = voices.filter(v => v.lang.startsWith('ar'));

    let selectedVoice: SpeechSynthesisVoice | undefined;

    // 1. If user chose a specific voice by URI
    if (preferredVoiceUri) {
      selectedVoice = voices.find(v => v.voiceURI === preferredVoiceUri || v.name === preferredVoiceUri);
    }

    // 2. If target voice has gender, find matching Arabic voice if possible
    if (!selectedVoice && arabicVoices.length > 0) {
      if (targetVoice?.gender === 'female') {
        selectedVoice = arabicVoices.find(v => 
          /female|salma|laila|hoda|zeina|سارة|ليلى|سلمى|مريم/i.test(v.name)
        ) || arabicVoices[0];
      } else if (targetVoice?.gender === 'male') {
        selectedVoice = arabicVoices.find(v => 
          /male|maged|tarik|shakir|طارق|ماجد|عمر|شاكر/i.test(v.name)
        ) || arabicVoices[0];
      } else {
        selectedVoice = arabicVoices[0];
      }
    }

    // 3. Fallback to any natural voice
    if (!selectedVoice) {
      selectedVoice = voices.find(v => v.lang.startsWith('ar')) ||
        voices.find(v => /natural|neural|online|google/i.test(v.name)) ||
        voices[0];
    }

    if (selectedVoice) {
      utterance.voice = selectedVoice;
      utterance.lang = selectedVoice.lang || 'ar-SA';
    } else {
      utterance.lang = 'ar-SA';
    }

    // Natural human pitch (between 0.95 and 1.05 - always natural!)
    const naturalPitch = targetVoice?.gender === 'female' ? 1.05 : 0.98;
    utterance.pitch = naturalPitch;
    utterance.rate = Math.max(0.8, Math.min(1.3, settings.speed || 1.0));

    utterance.onend = () => {
      if (onEnded) onEnded();
    };

    utterance.onerror = (e) => {
      console.warn('SpeechSynthesis error:', e);
      if (onEnded) onEnded();
    };

    window.speechSynthesis.speak(utterance);
  }

  // Harmonic acoustic backing instruments for songs (Oud, Piano, Soft Strings)
  public playAcousticNote(noteName: string, duration = 0.6, timeOffset = 0, instrument = 'oud') {
    this.init();
    const ctx = this.ctx!;
    const freq = NOTE_FREQS[noteName] || 440;
    const time = ctx.currentTime + timeOffset;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    if (instrument === 'oud') {
      // Natural Arabic Oud: Plucked triangle wave with gentle warmth
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, time);

      gain.gain.setValueAtTime(0.7, time);
      gain.gain.exponentialRampToValueAtTime(0.001, time + duration * 1.4);
    } else if (instrument === 'piano') {
      // Acoustic piano: Sine wave with fast attack, smooth decay
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, time);

      gain.gain.setValueAtTime(0.6, time);
      gain.gain.exponentialRampToValueAtTime(0.001, time + duration);
    } else {
      // Soft strings / Nay
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, time);

      gain.gain.setValueAtTime(0.05, time);
      gain.gain.linearRampToValueAtTime(0.5, time + 0.1);
      gain.gain.exponentialRampToValueAtTime(0.001, time + duration * 1.2);
    }

    osc.connect(gain);
    gain.connect(this.melodyGain!);

    osc.start(time);
    osc.stop(time + duration * 1.5);
    this.activeOscillators.push(osc);
  }

  // Play Acoustic Percussion (Darbuka Dum, Riq Tak, Soft Shaker)
  public playRhythmHit(type: 'dum' | 'tak' | 'shaker', timeOffset = 0) {
    this.init();
    const ctx = this.ctx!;
    const time = ctx.currentTime + timeOffset;

    if (type === 'dum') {
      // Authentic Darbuka Dum: deep resonant low tone
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(105, time);
      osc.frequency.exponentialRampToValueAtTime(45, time + 0.22);

      gain.gain.setValueAtTime(0.9, time);
      gain.gain.exponentialRampToValueAtTime(0.001, time + 0.35);

      osc.connect(gain);
      gain.connect(this.drumsGain!);
      osc.start(time);
      osc.stop(time + 0.35);
    } else if (type === 'tak') {
      // Authentic Riq Tak: crisp high acoustic sound
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(650, time);
      osc.frequency.exponentialRampToValueAtTime(250, time + 0.07);

      gain.gain.setValueAtTime(0.6, time);
      gain.gain.exponentialRampToValueAtTime(0.001, time + 0.08);

      osc.connect(gain);
      gain.connect(this.drumsGain!);
      osc.start(time);
      osc.stop(time + 0.08);
    } else {
      // Soft shaker
      const buffer = this.getNoiseBuffer();
      const source = ctx.createBufferSource();
      source.buffer = buffer;

      const filter = ctx.createBiquadFilter();
      filter.type = 'highpass';
      filter.frequency.value = 6000;

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.2, time);
      gain.gain.exponentialRampToValueAtTime(0.001, time + 0.05);

      source.connect(filter);
      filter.connect(gain);
      gain.connect(this.drumsGain!);
      source.start(time);
      source.stop(time + 0.05);
    }
  }

  // Play Bass note for acoustic harmony
  public playAcousticBass(freq: number, duration = 0.6, timeOffset = 0) {
    this.init();
    const ctx = this.ctx!;
    const time = ctx.currentTime + timeOffset;

    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, time);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.6, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + duration);

    osc.connect(gain);
    gain.connect(this.bassGain!);

    osc.start(time);
    osc.stop(time + duration);
    this.activeOscillators.push(osc);
  }

  // Play full song accompaniment arrangement
  public playFullSongArrangement(
    song: SongData,
    onProgress?: (sectionIndex: number, beat: number) => void,
    onComplete?: () => void
  ) {
    this.init();
    this.stopPlayback();
    this.isPlayingMusic = true;

    const bpm = Math.max(70, Math.min(130, song.bpm || 95));
    const beatDuration = 60 / bpm;
    let currentOffset = 0.1;

    const sections = song.sections && song.sections.length > 0 ? song.sections : [
      {
        sectionName: 'المذهب الطربي',
        lyrics: song.fullLyrics || 'تنساب نغمات العود في سكون الليل',
        melodyNotes: ['D4', 'E4', 'F4', 'G4', 'F4', 'E4', 'D4'],
        chords: ['Dm', 'Gm', 'A7', 'Dm'],
        energy: 0.8
      }
    ];

    sections.forEach((section, sIdx) => {
      const melodyNotes = section.melodyNotes && section.melodyNotes.length > 0
        ? section.melodyNotes
        : ['D4', 'E4', 'F4', 'G4', 'F4', 'E4', 'D4'];
      
      const bars = Math.max(4, Math.ceil(melodyNotes.length / 2));
      const sectionDuration = bars * 4 * beatDuration;

      const tId = window.setTimeout(() => {
        if (this.isPlayingMusic && onProgress) {
          onProgress(sIdx, 0);
        }
      }, currentOffset * 1000);
      this.activeTimeouts.push(tId);

      // Play elegant oriental rhythm: Dum - Tak - - Tak - Dum - Tak
      for (let bar = 0; bar < bars; bar++) {
        const barStart = currentOffset + bar * 4 * beatDuration;

        this.playRhythmHit('dum', barStart);
        this.playRhythmHit('shaker', barStart + beatDuration * 0.5);
        this.playRhythmHit('tak', barStart + beatDuration * 1.0);
        this.playRhythmHit('shaker', barStart + beatDuration * 1.5);
        this.playRhythmHit('dum', barStart + beatDuration * 2.0);
        this.playRhythmHit('tak', barStart + beatDuration * 3.0);
        this.playRhythmHit('shaker', barStart + beatDuration * 3.5);

        // Acoustic root bass
        this.playAcousticBass(146.83, beatDuration * 1.5, barStart); // D
        this.playAcousticBass(110.00, beatDuration * 1.0, barStart + beatDuration * 2); // A
      }

      // Play Melodic Oud Notes
      melodyNotes.forEach((note, nIdx) => {
        const noteStart = currentOffset + nIdx * (beatDuration * 1.2);
        this.playAcousticNote(note, beatDuration * 1.3, noteStart, 'oud');
      });

      currentOffset += sectionDuration;
    });

    const finishTimeout = window.setTimeout(() => {
      this.isPlayingMusic = false;
      if (onComplete) onComplete();
    }, currentOffset * 1000);
    this.activeTimeouts.push(finishTimeout);
  }

  // Get real-time audio visualizer frequency data
  public getVisualizerData(): Uint8Array {
    if (!this.analyser) return new Uint8Array(64);
    const data = new Uint8Array(this.analyser.frequencyBinCount);
    this.analyser.getByteFrequencyData(data);
    return data;
  }

  // Set track volumes
  public setTrackVolume(track: 'vocal' | 'melody' | 'drums' | 'bass' | 'master', vol: number) {
    this.init();
    const clamped = Math.max(0, Math.min(1.5, vol));
    if (track === 'vocal' && this.vocalGain) this.vocalGain.gain.value = clamped;
    if (track === 'melody' && this.melodyGain) this.melodyGain.gain.value = clamped;
    if (track === 'drums' && this.drumsGain) this.drumsGain.gain.value = clamped;
    if (track === 'bass' && this.bassGain) this.bassGain.gain.value = clamped;
    if (track === 'master' && this.masterGain) this.masterGain.gain.value = clamped;
  }

  private getNoiseBuffer(): AudioBuffer {
    const ctx = this.ctx!;
    const bufferSize = ctx.sampleRate * 0.2;
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    return buffer;
  }

  private createImpulseResponse(duration = 1.5, decay = 2.0): AudioBuffer {
    const ctx = this.ctx!;
    const sampleRate = ctx.sampleRate;
    const length = sampleRate * duration;
    const impulse = ctx.createBuffer(2, length, sampleRate);
    const left = impulse.getChannelData(0);
    const right = impulse.getChannelData(1);

    for (let i = 0; i < length; i++) {
      const n = length - i;
      left[i] = (Math.random() * 2 - 1) * Math.pow(n / length, decay);
      right[i] = (Math.random() * 2 - 1) * Math.pow(n / length, decay);
    }

    return impulse;
  }
}

export const audioEngine = new AudioEngineService();
