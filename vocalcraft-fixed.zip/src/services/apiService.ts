import { RealisticVoice, SongData } from '../types';

// In the APK there is no local server, so requests go to the deployed backend.
// On the web it stays empty and requests use the same origin.
const API_BASE = (import.meta.env.VITE_API_BASE as string | undefined) ?? '';

export class ApiService {
  public static async generateTTS(
    text: string,
    voice?: RealisticVoice,
    style?: string
  ): Promise<{ audioBase64: string; mimeType: string }> {
    const response = await fetch(API_BASE + '/api/tts', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        text,
        voiceId: voice?.id || 'sara_melodic',
        voice: voice?.geminiVoice || 'Kore',
        style: style || voice?.stylePrompt,
      }),
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.error || `خطأ في الخادم (${response.status})`);
    }

    return response.json();
  }

  public static async composeSong(
    prompt: string,
    genre: string,
    voice: RealisticVoice
  ): Promise<SongData> {
    const response = await fetch(API_BASE + '/api/compose-song', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt,
        genre,
        singerCharacter: voice.id,
      }),
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.error || 'تعذر تأليف الأغنية');
    }

    const data = await response.json();
    return {
      ...data.song,
      id: 'song_' + Date.now(),
      createdAt: Date.now(),
    };
  }

  public static async generateSingingTrack(
    lyrics: string,
    voice: RealisticVoice,
    style?: string
  ): Promise<string> {
    const response = await fetch(API_BASE + '/api/sing-track', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        lyrics,
        voiceId: voice.id,
        voice: voice.geminiVoice,
        style: style || voice.singingPrompt,
      }),
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.error || 'فشل في توليد صوت الغناء');
    }

    const data = await response.json();
    return data.audioBase64;
  }

  public static async generateDialogue(
    topic: string,
    speakerAName: string,
    speakerBName: string
  ): Promise<{ title: string; lines: Array<{ speaker: string; speakerIndex: number; text: string }> }> {
    const response = await fetch(API_BASE + '/api/generate-dialogue', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ topic, speakerAName, speakerBName }),
    });

    if (!response.ok) {
      throw new Error('تعذر توليد الحوار');
    }

    const data = await response.json();
    return data.dialogue;
  }
}
