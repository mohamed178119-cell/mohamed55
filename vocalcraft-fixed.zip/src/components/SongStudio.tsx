import React, { useState, useEffect } from 'react';
import { 
  Music, Sparkles, Play, Square, Sliders, 
  FolderPlus, Share2, Wand2, RefreshCw, Mic, Disc3, Zap, Heart
} from 'lucide-react';
import { RealisticVoice, SongData, SavedTrack } from '../types';
import { REALISTIC_VOICES } from '../data/characters';
import { MUSIC_GENRES } from '../data/musicStyles';
import { audioEngine } from '../services/audioEngine';
import { ApiService } from '../services/apiService';
import { Visualizer } from './Visualizer';
import { ShareExportModal } from './ShareExportModal';

interface SongStudioProps {
  onSaveTrack: (track: SavedTrack) => void;
}

export const SongStudio: React.FC<SongStudioProps> = ({ onSaveTrack }) => {
  const [prompt, setPrompt] = useState('أغنية طربية عذبة عن سكون المساء وجمال النغم وراحة الروح والمشاعر الصادقة.');
  const [selectedGenreId, setSelectedGenreId] = useState('tarab');
  const [selectedVoiceId, setSelectedVoiceId] = useState('zain_singer');
  
  const [isComposing, setIsComposing] = useState(false);
  const [isSynthesizingVoice, setIsSynthesizingVoice] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);

  // Mixer track volumes
  const [vocalVol, setVocalVol] = useState(1.0);
  const [melodyVol, setMelodyVol] = useState(0.85);
  const [drumsVol, setDrumsVol] = useState(0.75);
  const [bassVol, setBassVol] = useState(0.7);

  const [currentSong, setCurrentSong] = useState<SongData | null>(null);
  const [activeSectionIdx, setActiveSectionIdx] = useState(0);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const selectedVoice = REALISTIC_VOICES.find(v => v.id === selectedVoiceId) || REALISTIC_VOICES[0];
  const selectedGenre = MUSIC_GENRES.find(g => g.id === selectedGenreId) || MUSIC_GENRES[0];

  // Starter song for instant pleasant listening
  useEffect(() => {
    const starterSong: SongData = {
      id: 'default_tarab_song',
      title: 'نسيم الشوق والهدوء',
      genre: 'tarab',
      bpm: 92,
      scale: 'Hijaz',
      singerCharacter: 'zain_singer',
      chorusCatchphrase: 'يا ليل يا عيني على سحر النغم.. يداوي كل ألم',
      fullLyrics: `تنساب نغمات العود في سكون الليل\nتداعب أرواحنا بنسيم الشوق والميل\nفي كل لحن حكاية صفاء وسلام\nتزهر في القلوب كأجمل الأحلام`,
      sections: [
        {
          sectionName: 'المذهب الطربي',
          lyrics: 'تنساب نغمات العود في سكون الليل، تداعب أرواحنا بنسيم الشوق والميل!',
          melodyNotes: ['D4', 'E4', 'F4', 'G4', 'F4', 'E4', 'D4'],
          chords: ['Dm', 'Gm', 'A7', 'Dm'],
          energy: 0.8,
        },
        {
          sectionName: 'الكوبليه الهادئ',
          lyrics: 'في كل لحن حكاية صفاء وسلام، تزهر في القلوب كأجمل الأحلام!',
          melodyNotes: ['F4', 'G4', 'A4', 'Bb4', 'A4', 'G4', 'F4', 'E4', 'D4'],
          chords: ['F', 'Bb', 'C', 'Dm'],
          energy: 0.9,
        },
      ],
      socialHook: 'لحن شجي يأخذك إلى عالم من الهدوء والسلطنة 🎶✨',
      createdAt: Date.now(),
    };
    setCurrentSong(starterSong);
  }, []);

  // Update track mixer gains
  useEffect(() => {
    audioEngine.setTrackVolume('vocal', vocalVol);
  }, [vocalVol]);
  useEffect(() => {
    audioEngine.setTrackVolume('melody', melodyVol);
  }, [melodyVol]);
  useEffect(() => {
    audioEngine.setTrackVolume('drums', drumsVol);
  }, [drumsVol]);
  useEffect(() => {
    audioEngine.setTrackVolume('bass', bassVol);
  }, [bassVol]);

  // Compose new song with Gemini AI
  const handleComposeSong = async () => {
    if (!prompt.trim()) return;
    try {
      setIsComposing(true);
      audioEngine.stopPlayback();
      setIsPlaying(false);

      const songData = await ApiService.composeSong(prompt, selectedGenreId, selectedVoice);
      setCurrentSong(songData);
      setIsComposing(false);

      // Synthesize singing vocal track for the song
      handleSynthesizeSinging(songData);
    } catch (err) {
      console.error(err);
      setIsComposing(false);
    }
  };

  // Synthesize singing vocal track
  const handleSynthesizeSinging = async (songToSing?: SongData) => {
    const song = songToSing || currentSong;
    if (!song) return;

    try {
      setIsSynthesizingVoice(true);
      const lyricsToSing = song.sections.map(s => s.lyrics).join('. ');
      const base64Audio = await ApiService.generateSingingTrack(
        lyricsToSing,
        selectedVoice,
        selectedVoice.singingPrompt
      );

      setCurrentSong(prev => prev ? { ...prev, vocalAudioBase64: base64Audio } : null);
      setIsSynthesizingVoice(false);
    } catch (err) {
      console.warn('Fallback to natural voice recitation for singing');
      setIsSynthesizingVoice(false);
    }
  };

  // Play full song (Acoustic arrangement + Vocal track)
  const handlePlaySong = async () => {
    if (!currentSong) return;

    if (isPlaying) {
      audioEngine.stopPlayback();
      setIsPlaying(false);
      return;
    }

    setIsPlaying(true);
    audioEngine.init();

    // 1. Play acoustic accompaniment (Oud, Piano, Riq & Darbuka rhythm)
    audioEngine.playFullSongArrangement(
      currentSong,
      (sectionIdx) => {
        setActiveSectionIdx(sectionIdx);
      },
      () => {
        setIsPlaying(false);
      }
    );

    // 2. Play vocal track cleanly without distortion
    if (currentSong.vocalAudioBase64) {
      try {
        await audioEngine.playBase64Audio(
          currentSong.vocalAudioBase64,
          {
            speed: 1.0,
            pitch: 0,
            reverb: 0.15,
            bassBoost: 0.2,
            presence: 0.5,
          }
        );
      } catch (e) {
        console.error('Error playing vocal audio track:', e);
      }
    } else {
      // Natural speech singing recitation
      const fullText = currentSong.sections.map(s => s.lyrics).join(' ');
      audioEngine.speakNative(
        fullText,
        {
          speed: 0.95,
          pitch: 0,
          reverb: 0.1,
          bassBoost: 0.2,
          presence: 0.5,
        },
        selectedVoice
      );
    }
  };

  const handleStopSong = () => {
    audioEngine.stopPlayback();
    setIsPlaying(false);
  };

  const handleSaveToLibrary = () => {
    if (!currentSong) return;
    const item: SavedTrack = {
      id: 'song_' + Date.now(),
      title: currentSong.title,
      content: currentSong.fullLyrics,
      type: 'song',
      characterId: selectedVoice.id,
      genre: selectedGenre.name,
      bpm: currentSong.bpm,
      audioBase64: currentSong.vocalAudioBase64,
      duration: 22,
      createdAt: Date.now(),
      formattedDate: new Date().toLocaleDateString('ar-EG', {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }),
    };
    onSaveTrack(item);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  return (
    <div className="space-y-8">
      
      {/* Studio Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-amber-500/10 via-purple-500/10 to-rose-500/10 border border-slate-800 p-6 sm:p-8">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
              <Sparkles className="w-3.5 h-3.5" />
              <span>تلحين موسيقي بأصوات واقعية ومقامات عربية أصيلة</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white font-['Tajawal'] tracking-wide">
              استوديو تلحين الأغاني والموسيقى الواقعية 🎶
            </h2>
            <p className="text-slate-300 text-sm leading-relaxed">
              حول أي خاطرة أو شعر أو موضوع إلى عمل غنائي متكامل بأصوات واقعية شجية، مع توزيع موسيقي متناسق بالعود والبيانو والإيقاعات الشرقية الأصيلة بدون أي نشاز.
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => {
                setPrompt('قصيدة طربية عن الشوق وسكون الليل ونغمات العود الحنونة');
                setSelectedGenreId('tarab');
                setSelectedVoiceId('zain_singer');
              }}
              className="text-xs bg-slate-900/80 hover:bg-slate-800 text-amber-300 border border-amber-500/30 px-3.5 py-2 rounded-xl font-bold transition-all shadow-sm"
            >
              🪕 طرب وسلطنة
            </button>

            <button
              onClick={() => {
                setPrompt('أغنية رقيقة وهادئة عن الأمل والبدايات الجديدة والابتسامة الصافية');
                setSelectedGenreId('acoustic_pop');
                setSelectedVoiceId('sara_melodic');
              }}
              className="text-xs bg-slate-900/80 hover:bg-slate-800 text-pink-300 border border-pink-500/30 px-3.5 py-2 rounded-xl font-bold transition-all shadow-sm"
            >
              🌸 بوب هادئ بصوت سارة
            </button>

            <button
              onClick={() => {
                setPrompt('موشح أندلسي راقٍ عن شمس الأصيل ونسيم الياسمين وجمال الطبيعة');
                setSelectedGenreId('andalusian');
                setSelectedVoiceId('laila_tarab');
              }}
              className="text-xs bg-slate-900/80 hover:bg-slate-800 text-emerald-300 border border-emerald-500/30 px-3.5 py-2 rounded-xl font-bold transition-all shadow-sm"
            >
              🏛️ موشحات أندلسية
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column / Inputs (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Prompt Box */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-sm font-bold text-slate-200 flex items-center gap-2">
                <Wand2 className="w-4 h-4 text-amber-400" />
                <span>فكرة الأغنية أو الكلمات التي تريد غناءها:</span>
              </label>
              <span className="text-xs text-slate-400 font-mono">
                {prompt.length} حرف
              </span>
            </div>

            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              rows={4}
              placeholder="اكتب هنا موضوع الأغنية، أبيات شعرية، أو كلمات محددة تريد تلحينها..."
              className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-2xl p-4 text-slate-100 text-sm leading-relaxed resize-none transition-all placeholder:text-slate-600"
            />

            {/* Quick Inspiration Phrases */}
            <div className="flex flex-wrap items-center gap-2 pt-1">
              <span className="text-xs text-slate-400 font-bold">أفكار طربية سريعة:</span>
              {selectedGenre.sampleKeywords.map((kw, i) => (
                <button
                  key={i}
                  onClick={() => setPrompt(`أغنية جميلة وراقية تدور حول ${kw} بلحن هادئ وكلمات عذبة`)}
                  className="text-xs bg-slate-800/80 hover:bg-slate-700 text-slate-300 px-3 py-1 rounded-xl transition-all border border-slate-700/60"
                >
                  {kw}
                </button>
              ))}
            </div>

            {/* Compose Button */}
            <button
              onClick={handleComposeSong}
              disabled={isComposing || !prompt.trim()}
              className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 text-slate-950 font-black text-base shadow-lg shadow-amber-500/20 hover:brightness-110 active:scale-[0.99] disabled:opacity-50 transition-all flex items-center justify-center gap-2"
            >
              {isComposing ? (
                <>
                  <RefreshCw className="w-5 h-5 animate-spin" />
                  <span>جاري تأليف الكلمات وتوزيع اللحن الموسيقي الراقي...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  <span>تأليف وتلحين الأغنية بالذكاء الاصطناعي 🪄</span>
                </>
              )}
            </button>
          </div>

          {/* Musical Genre Picker */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
                <Music className="w-4 h-4 text-amber-400" />
                <span>اختر الطابع والنوع الموسيقي:</span>
              </h3>
              <span className="text-xs text-amber-400 font-bold">
                {selectedGenre.bpm} BPM • مقام {selectedGenre.scale}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {MUSIC_GENRES.map((genre) => {
                const isSelected = selectedGenreId === genre.id;
                return (
                  <button
                    key={genre.id}
                    onClick={() => setSelectedGenreId(genre.id)}
                    className={`p-3.5 rounded-2xl text-right transition-all border flex flex-col justify-between ${
                      isSelected
                        ? 'bg-gradient-to-br from-amber-500/20 to-orange-500/20 border-amber-400 shadow-md shadow-amber-500/10'
                        : 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700 hover:bg-slate-900'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-2xl">{genre.icon}</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-800 text-slate-400">
                        {genre.bpm} BPM
                      </span>
                    </div>
                    <div>
                      <p className={`text-xs font-bold ${isSelected ? 'text-amber-400' : 'text-slate-200'}`}>
                        {genre.name}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Singer Voice Picker */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
            <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
              <Mic className="w-4 h-4 text-amber-400" />
              <span>اختر الصوت الواقعي المغني للأغنية:</span>
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {REALISTIC_VOICES.map((voice) => {
                const isSelected = selectedVoiceId === voice.id;
                return (
                  <button
                    key={voice.id}
                    onClick={() => setSelectedVoiceId(voice.id)}
                    className={`p-3 rounded-2xl flex items-center gap-3 text-right transition-all border ${
                      isSelected
                        ? 'bg-slate-800 border-amber-400 ring-2 ring-amber-400/20 shadow-md'
                        : 'bg-slate-950/60 border-slate-800/80 hover:bg-slate-900'
                    }`}
                  >
                    <span className="text-2xl">{voice.avatarIcon}</span>
                    <div className="overflow-hidden">
                      <p className={`text-xs font-bold truncate ${isSelected ? 'text-amber-400' : 'text-slate-200'}`}>
                        {voice.name.split('-')[0].trim()}
                      </p>
                      <p className="text-[10px] text-slate-400 truncate">
                        {voice.badge}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

        </div>

        {/* Right Column / Live Audio Player & Track Mixer (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          
          {currentSong && (
            <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-6 sticky top-24">
              
              {/* Song Header & Visualizer */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-3xl">
                      {selectedVoice.avatarIcon}
                    </div>
                    <div>
                      <h3 className="font-black text-white text-lg font-['Tajawal']">
                        {currentSong.title}
                      </h3>
                      <p className="text-xs text-amber-400 font-bold">
                        أداء: {selectedVoice.name.split('-')[0].trim()} • {selectedGenre.name}
                      </p>
                    </div>
                  </div>

                  <span className="text-xs font-mono px-3 py-1 rounded-full bg-slate-800 text-slate-300">
                    {currentSong.bpm} BPM
                  </span>
                </div>

                {/* Live Neon Visualizer */}
                <Visualizer
                  color={selectedVoice.accentHex}
                  glowColor={selectedVoice.glowColor}
                  height={80}
                  barCount={32}
                />
              </div>

              {/* Karaoke Subtitle Display */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-center space-y-2">
                <div className="flex items-center justify-between text-[11px] text-slate-400 font-bold">
                  <span>الكلمات المغناة (Karaoke):</span>
                  {currentSong.chorusCatchphrase && (
                    <span className="text-amber-400 truncate max-w-[200px]">
                      ⭐ {currentSong.chorusCatchphrase}
                    </span>
                  )}
                </div>
                
                <div className="py-2 min-h-[70px] flex items-center justify-center">
                  <p className="text-sm sm:text-base font-bold text-amber-300 leading-relaxed transition-all duration-300">
                    {currentSong.sections[activeSectionIdx]?.lyrics || currentSong.fullLyrics.split('\n')[0]}
                  </p>
                </div>
              </div>

              {/* Main Play / Stop / Action Controls */}
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={handlePlaySong}
                  className={`flex items-center justify-center gap-2 py-3.5 px-4 rounded-2xl font-black text-sm shadow-lg transition-all ${
                    isPlaying
                      ? 'bg-rose-500 hover:bg-rose-600 text-white shadow-rose-500/20'
                      : 'bg-gradient-to-r from-amber-500 to-orange-500 hover:brightness-110 text-slate-950 shadow-amber-500/25'
                  }`}
                >
                  {isPlaying ? (
                    <>
                      <Square className="w-4 h-4 fill-current" />
                      <span>إيقاف الموسيقى</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4 fill-current" />
                      <span>تشغيل الأغنية والموسيقى 🎶</span>
                    </>
                  )}
                </button>

                <button
                  onClick={() => setIsShareModalOpen(true)}
                  className="flex items-center justify-center gap-2 py-3.5 px-4 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:brightness-110 text-white font-bold text-sm shadow-lg shadow-purple-500/20 transition-all"
                >
                  <Share2 className="w-4 h-4" />
                  <span>مشاركة وتصدير 🚀</span>
                </button>
              </div>

              {/* Vocal Generator Status */}
              <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-950/60 border border-slate-800 text-xs">
                <span className="text-slate-400">حالة المسار الصوتي:</span>
                {isSynthesizingVoice ? (
                  <span className="flex items-center gap-1.5 text-amber-400 font-bold">
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    جاري توليد صوت الغناء...
                  </span>
                ) : (
                  <button
                    onClick={() => handleSynthesizeSinging()}
                    className="flex items-center gap-1 text-amber-400 font-bold hover:underline"
                  >
                    <Zap className="w-3.5 h-3.5" />
                    <span>تحديث صوت الغناء الواقعي</span>
                  </button>
                )}
              </div>

              {/* Multi-Track Mixer Panel */}
              <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between text-xs font-bold text-slate-300">
                  <span className="flex items-center gap-1.5">
                    <Sliders className="w-3.5 h-3.5 text-amber-400" />
                    مكسر تراكات الأغنية (Studio Mixer):
                  </span>
                </div>

                <div className="space-y-2.5">
                  {/* Vocal Track */}
                  <div className="flex items-center justify-between text-xs">
                    <span className="w-24 text-slate-400 flex items-center gap-1">
                      🎤 غناء المؤدي
                    </span>
                    <input
                      type="range"
                      min="0"
                      max="1.5"
                      step="0.05"
                      value={vocalVol}
                      onChange={(e) => setVocalVol(parseFloat(e.target.value))}
                      className="flex-1 mx-3 accent-amber-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                    />
                    <span className="font-mono text-slate-400 w-8 text-left">
                      {Math.round(vocalVol * 100)}%
                    </span>
                  </div>

                  {/* Melody Track (Oud / Piano) */}
                  <div className="flex items-center justify-between text-xs">
                    <span className="w-24 text-slate-400 flex items-center gap-1">
                      🪕 أوتار العود واللحن
                    </span>
                    <input
                      type="range"
                      min="0"
                      max="1.5"
                      step="0.05"
                      value={melodyVol}
                      onChange={(e) => setMelodyVol(parseFloat(e.target.value))}
                      className="flex-1 mx-3 accent-amber-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                    />
                    <span className="font-mono text-slate-400 w-8 text-left">
                      {Math.round(melodyVol * 100)}%
                    </span>
                  </div>

                  {/* Drums Track (Riq & Darbuka) */}
                  <div className="flex items-center justify-between text-xs">
                    <span className="w-24 text-slate-400 flex items-center gap-1">
                      🥁 رق وإيقاع مقسوم
                    </span>
                    <input
                      type="range"
                      min="0"
                      max="1.5"
                      step="0.05"
                      value={drumsVol}
                      onChange={(e) => setDrumsVol(parseFloat(e.target.value))}
                      className="flex-1 mx-3 accent-amber-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                    />
                    <span className="font-mono text-slate-400 w-8 text-left">
                      {Math.round(drumsVol * 100)}%
                    </span>
                  </div>

                  {/* Bass Track */}
                  <div className="flex items-center justify-between text-xs">
                    <span className="w-24 text-slate-400 flex items-center gap-1">
                      🎸 بيس وهارموني
                    </span>
                    <input
                      type="range"
                      min="0"
                      max="1.5"
                      step="0.05"
                      value={bassVol}
                      onChange={(e) => setBassVol(parseFloat(e.target.value))}
                      className="flex-1 mx-3 accent-amber-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                    />
                    <span className="font-mono text-slate-400 w-8 text-left">
                      {Math.round(bassVol * 100)}%
                    </span>
                  </div>
                </div>
              </div>

              {/* Save Button */}
              <button
                onClick={handleSaveToLibrary}
                className="w-full py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-all flex items-center justify-center gap-2 border border-slate-700"
              >
                <FolderPlus className="w-4 h-4 text-amber-400" />
                <span>{saveSuccess ? 'تم حفظ الأغنية في مكتبتك! ✅' : 'حفظ الأغنية في المكتبة (Save Track)'}</span>
              </button>

            </div>
          )}

        </div>

      </div>

      {/* Share & Social Media Modal */}
      {currentSong && (
        <ShareExportModal
          isOpen={isShareModalOpen}
          onClose={() => setIsShareModalOpen(false)}
          title={currentSong.title}
          character={selectedVoice}
          lyrics={currentSong.fullLyrics}
          audioBase64={currentSong.vocalAudioBase64}
          songData={currentSong}
          duration={20}
        />
      )}

    </div>
  );
};
