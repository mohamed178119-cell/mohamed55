import React, { useState } from 'react';
import { 
  X, Share2, Download, Video, MessageCircle, Instagram, 
  Send, Sparkles, Check, Play, RefreshCw, Eye
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Character, SongData } from '../types';
import { SocialVideoGenerator } from '../services/videoGenerator';

interface ShareExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  character: Character;
  lyrics: string;
  audioBase64?: string;
  songData?: SongData | null;
  duration?: number;
}

export const ShareExportModal: React.FC<ShareExportModalProps> = ({
  isOpen,
  onClose,
  title,
  character,
  lyrics,
  audioBase64,
  songData,
  duration = 15,
}) => {
  const [aspectRatio, setAspectRatio] = useState<'9:16' | '1:1' | '16:9'>('9:16');
  const [isGeneratingVideo, setIsGeneratingVideo] = useState(false);
  const [renderProgress, setRenderProgress] = useState(0);
  const [generatedVideoUrl, setGeneratedVideoUrl] = useState<string | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);

  if (!isOpen) return null;

  // Generate 9:16 or selected aspect ratio video for TikTok / Reels / Shorts
  const handleGenerateVideo = async () => {
    try {
      setIsGeneratingVideo(true);
      setRenderProgress(0);
      setGeneratedVideoUrl(null);

      const videoBlob = await SocialVideoGenerator.generateSocialVideo({
        title,
        character,
        lyrics,
        songData,
        aspectRatio,
        durationSeconds: Math.min(25, Math.max(8, duration)),
        onProgress: (p) => setRenderProgress(p),
      });

      const url = URL.createObjectURL(videoBlob);
      setGeneratedVideoUrl(url);
      setIsGeneratingVideo(false);

      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch (err) {
      console.error('Video generation error:', err);
      alert('حدث خطأ أثناء تصدير الفيديو، يرجى المحاولة مجدداً');
      setIsGeneratingVideo(false);
    }
  };

  // Download Audio as WAV file
  const handleDownloadAudio = () => {
    if (!audioBase64) {
      alert('لا يتوفر ملف صوتي خام للتحميل المباشر');
      return;
    }
    const byteCharacters = atob(audioBase64);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray], { type: 'audio/wav' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${title.replace(/\s+/g, '_')}_${character.id}.wav`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // WhatsApp Share
  const handleWhatsAppShare = () => {
    const text = `استمع إلى هذا المقطع الصوتي الرائع بصوت "${character.name}" من تطبيق صوتك ونغم 🎶🔥:\n\n"${title}"\n${lyrics.slice(0, 140)}...\n\nجرب التطبيق الآن!`;
    const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  // Telegram Share
  const handleTelegramShare = () => {
    const text = `🎶 مقطع بصوت "${character.name}":\n"${title}"\n\n${lyrics.slice(0, 120)}...`;
    const url = `https://t.me/share/url?url=${encodeURIComponent(window.location.href)}&text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  // Copy lyrics & link
  const handleCopyShare = () => {
    const shareText = `🎵 "${title}" بصوت ${character.name}\n\n${lyrics}\n\nتم إنشاؤه عبر استوديو صوتك ونغم 🚀`;
    navigator.clipboard.writeText(shareText);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl text-right">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-6 left-6 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-all"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center text-slate-950 font-bold text-2xl shadow-lg shadow-amber-500/20">
            <Share2 className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white font-['Tajawal']">
              مشاركة وتصدير لجميع المنصات
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">
              تصدير فيديو عمودي 9:16 للتيك توك والريلز أو ملف صوتي للواتساب
            </p>
          </div>
        </div>

        {/* Selected Track Pill */}
        <div className="flex items-center justify-between p-3.5 mb-6 rounded-2xl bg-slate-950/60 border border-slate-800">
          <div className="flex items-center gap-3">
            <span className="text-3xl">{character.avatarIcon}</span>
            <div>
              <p className="font-bold text-slate-200 text-sm">{title}</p>
              <p className="text-xs text-amber-400">{character.name}</p>
            </div>
          </div>
          <span className="text-xs px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 font-mono">
            {duration} ثانية
          </span>
        </div>

        {/* Social Sharing Quick Channels */}
        <div className="mb-8">
          <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">
            مشاركة سريعة ومباشرة:
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            
            {/* WhatsApp */}
            <button
              onClick={handleWhatsAppShare}
              className="flex items-center justify-center gap-2 p-3 rounded-2xl bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 font-bold text-sm transition-all"
            >
              <MessageCircle className="w-5 h-5 text-emerald-400" />
              <span>واتساب</span>
            </button>

            {/* Telegram */}
            <button
              onClick={handleTelegramShare}
              className="flex items-center justify-center gap-2 p-3 rounded-2xl bg-sky-500/10 hover:bg-sky-500/20 border border-sky-500/30 text-sky-400 font-bold text-sm transition-all"
            >
              <Send className="w-5 h-5 text-sky-400" />
              <span>تيليجرام</span>
            </button>

            {/* Copy Link / Lyrics */}
            <button
              onClick={handleCopyShare}
              className="flex items-center justify-center gap-2 p-3 rounded-2xl bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/30 text-purple-400 font-bold text-sm transition-all"
            >
              {copiedLink ? <Check className="w-5 h-5 text-emerald-400" /> : <Sparkles className="w-5 h-5 text-purple-400" />}
              <span>{copiedLink ? 'تم النسخ!' : 'نسخ الكلمات'}</span>
            </button>

            {/* Direct Audio Download */}
            <button
              onClick={handleDownloadAudio}
              className="flex items-center justify-center gap-2 p-3 rounded-2xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-400 font-bold text-sm transition-all"
            >
              <Download className="w-5 h-5 text-amber-400" />
              <span>تحميل WAV</span>
            </button>

          </div>
        </div>

        {/* Video Generator Studio (Vertical 9:16 Reels/TikTok) */}
        <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-950/80 to-slate-900 border border-slate-800">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Video className="w-5 h-5 text-amber-400" />
              <h3 className="font-bold text-white text-base">
                استوديو إنتاج فيديو للتيك توك والريلز 🎬
              </h3>
            </div>
            <span className="text-xs bg-amber-500/10 text-amber-400 px-2 py-0.5 rounded-full border border-amber-500/20">
              مع تموجات الصوت وكلمات الأغنية
            </span>
          </div>

          <p className="text-xs text-slate-400 mb-4 leading-relaxed">
            يقوم بتوليد فيديو متحرك مخصص للشخصية الكرتونية مع أمواج الصوت المتراقصة وكلمات الأغنية بالترتيب، مناسب تماماً للنشر على TikTok و Instagram Reels و YouTube Shorts.
          </p>

          {/* Aspect Ratio Selector */}
          <div className="flex items-center gap-3 mb-5">
            <span className="text-xs text-slate-400 font-bold">أبعاد الفيديو:</span>
            <div className="flex gap-2">
              <button
                onClick={() => setAspectRatio('9:16')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  aspectRatio === '9:16'
                    ? 'bg-amber-500 text-slate-950'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                📱 عمودي 9:16 (تيك توك / ريلز)
              </button>
              <button
                onClick={() => setAspectRatio('1:1')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  aspectRatio === '1:1'
                    ? 'bg-amber-500 text-slate-950'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                🔳 مربع 1:1 (إنستغرام)
              </button>
              <button
                onClick={() => setAspectRatio('16:9')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  aspectRatio === '16:9'
                    ? 'bg-amber-500 text-slate-950'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                🖥️ أفقي 16:9 (يوتيوب)
              </button>
            </div>
          </div>

          {/* Video Preview or Action Button */}
          {generatedVideoUrl ? (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row items-center gap-4 bg-slate-950 p-4 rounded-2xl border border-emerald-500/30">
                <div className="w-full sm:w-48 aspect-[9/16] bg-black rounded-xl overflow-hidden flex items-center justify-center">
                  <video
                    src={generatedVideoUrl}
                    controls
                    autoPlay
                    loop
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1 space-y-3">
                  <div className="flex items-center gap-2 text-emerald-400 text-sm font-bold">
                    <Check className="w-5 h-5" />
                    <span>تم تجهيز الفيديو بنجاح وجاهز للمشاركة!</span>
                  </div>
                  <p className="text-xs text-slate-400">
                    يمكنك الآن تحميل الفيديو وحفظه في المعرض أو نشره مباشرة على حساباتك في مواقع التواصل الاجتماعي.
                  </p>
                  <div className="flex flex-wrap gap-2 pt-2">
                    <a
                      href={generatedVideoUrl}
                      download={`${title.replace(/\s+/g, '_')}_social_video.mp4`}
                      className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-bold text-sm shadow-md hover:brightness-110 transition-all"
                    >
                      <Download className="w-4 h-4" />
                      <span>تحميل الفيديو (MP4)</span>
                    </a>
                    <button
                      onClick={handleGenerateVideo}
                      className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-all"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>إعادة التوليد</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div>
              {isGeneratingVideo ? (
                <div className="space-y-3 p-4 rounded-xl bg-slate-950/80 border border-amber-500/30">
                  <div className="flex items-center justify-between text-xs text-amber-400 font-bold">
                    <span className="flex items-center gap-2">
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      جاري تصميم ورندرة فيديو الريلز والتيك توك...
                    </span>
                    <span className="font-mono">{renderProgress}%</span>
                  </div>
                  <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 h-full transition-all duration-300"
                      style={{ width: `${renderProgress}%` }}
                    />
                  </div>
                </div>
              ) : (
                <button
                  onClick={handleGenerateVideo}
                  className="w-full flex items-center justify-center gap-2 py-3.5 px-6 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 text-slate-950 font-black text-sm shadow-lg shadow-amber-500/25 hover:brightness-110 transition-all"
                >
                  <Sparkles className="w-5 h-5 text-slate-950" />
                  <span>توليد فيديو احترافي للتيك توك والريلز الآن</span>
                </button>
              )}
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
