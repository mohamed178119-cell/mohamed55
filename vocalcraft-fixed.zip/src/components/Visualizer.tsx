import React, { useEffect, useRef } from 'react';
import { audioEngine } from '../services/audioEngine';

interface VisualizerProps {
  color?: string;
  glowColor?: string;
  height?: number;
  barCount?: number;
  className?: string;
}

export const Visualizer: React.FC<VisualizerProps> = ({
  color = '#f59e0b',
  glowColor = 'rgba(245, 158, 11, 0.4)',
  height = 70,
  barCount = 36,
  className = '',
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    let animId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const render = () => {
      const width = canvas.width;
      const ch = canvas.height;
      ctx.clearRect(0, 0, width, ch);

      const freqData = audioEngine.getVisualizerData();
      const hasSound = freqData.some(v => v > 10);

      const barWidth = width / barCount;

      for (let i = 0; i < barCount; i++) {
        // Pick frequency index
        const idx = Math.floor((i / barCount) * (freqData.length / 2));
        const rawVal = hasSound ? (freqData[idx] || 0) : Math.sin(Date.now() * 0.003 + i * 0.3) * 15 + 18;
        
        const barH = Math.max(4, (rawVal / 255) * ch * 0.9);
        const x = i * barWidth;
        const y = ch - barH;

        // Gradient for bar
        const grad = ctx.createLinearGradient(0, y, 0, ch);
        grad.addColorStop(0, color);
        grad.addColorStop(1, glowColor);

        ctx.fillStyle = grad;
        ctx.fillRect(x + 2, y, barWidth - 4, barH);

        // Rounded top
        ctx.beginPath();
        ctx.arc(x + (barWidth - 4) / 2 + 2, y, (barWidth - 4) / 2, Math.PI, 0);
        ctx.fillStyle = color;
        ctx.fill();
      }

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [color, glowColor, barCount]);

  return (
    <div className={`relative overflow-hidden rounded-xl bg-slate-900/60 p-2 border border-slate-800 ${className}`}>
      <canvas
        ref={canvasRef}
        width={400}
        height={height}
        className="w-full h-full block"
      />
    </div>
  );
};
