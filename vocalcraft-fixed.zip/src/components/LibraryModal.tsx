import React, { useState } from 'react';
import { Play, Square, Trash2, Share2, Download, Music, Mic, FolderHeart, Calendar, Clock } from 'lucide-react';
import { SavedTrack, Character } from '../types';
import { CHARACTERS } from '../data/characters';
import { audioEngine } from '../services/audioEngine';
import { ShareExportModal } from './ShareExportModal';

interface LibraryModalProps {
  tracks: SavedTrack[];
  onDeleteTrack: (id: string) => void;
  onNavigateToStudio: () => void;
}

export const LibraryModal: React.FC<LibraryModalProps> = ({
  tracks,
  onDeleteTrack,
  onNavigateToStudio,
}) => {
  const [playingTrackId, setPlayingTrackId] = useState<string | null>(null);
  const [exportTrack, setExportTrack] = useState<{
    track: SavedTrack;
    character: Character;
  } | null>(null);

  const handlePlayTrack = async (track: SavedTrack) => {
    if (playingTrackId === track.id) {
      audioEngine.stopPlayback();
      setPlayingTrackId(null);
      return;
    }

    setPlayingTrackId(track.id);
    const char = CHARACTERS.find(c => c.id === track.characterId) || CHARACTERS[0];

    if (track.audioBase64) {
      try {
        await audioEngine.playBase64Audio(
          track.audioBase64,
          {
            speed: 1.0,
            pitch: 0,
            reverb: 0.1,
            bassBoost: 0.2,
            presence: 0.5,
          },
          () => setPlayingTrackId(null)
        );
      } catch (e) {
        console.error('Error playing track audio:', e);
        setPlayingTrackId(null);
      }
    } else {
      audioEngine.speakNative(
        track.content,
        {
          speed: 1.0,
          pitch: 0,
          reverb: 0.1,
          bassBoost: 0.2,
          presence: 0.5,
        },
        char,
        undefined,
        () => setPlayingTrackId(null)
      );
    }
  };

  const handleDownloadWav = (track: SavedTrack) => {
    if (!track.audioBase64) {
      alert('لا يتوفر ملف صوتي خام محفوظ لهذا المقطع');
      return;
    }
    const byteCharacters = atob(track.audioBase64);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray], { type: 'audio/wav' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${track.title.replace(/\s+/g, '_')}.wav`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8">
      
      {/* Header Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-purple-500/15 via-indigo-500/15 to-amber-500/15 border border-slate-800 p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-3xl">
              <FolderHeart className="w-7 h-7 text-amber-400" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-white font-['Tajawal']">
                مكتبتي والأغاني المحفوظة 📁
              </h2>
              <p className="text-xs sm:text-sm text-slate-400 mt-1">
                جميع المقاطع الصوتية والأغاني التي قمت بتأليفها وحفظها جاهزة للاستماع والمشاركة
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-amber-400 font-bold font-mono">
              {tracks.length} مقاطع محفوظة
            </span>
          </div>
        </div>
      </div>

      {/* Tracks List or Empty State */}
      {tracks.length === 0 ? (
        <div className="p-12 text-center rounded-3xl bg-slate-900/60 border border-slate-800 space-y-4">
          <div className="w-20 h-20 rounded-3xl bg-slate-800/80 mx-auto flex items-center justify-center text-4xl">
            🎵
          </div>
          <div className="space-y-1">
            <h3 className="text-lg font-bold text-white">لم تقم بحفظ أي أغنية بعد</h3>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              قم بزيارة استوديو تلحين الأغاني أو محول النصوص واضغط على زر "حفظ في المكتبة" لتبقى مقاطعك هنا دائماً!
            </p>
          </div>
          <button
            onClick={onNavigateToStudio}
            className="px-6 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-black text-sm shadow-lg shadow-amber-500/20 hover:brightness-110 transition-all inline-flex items-center gap-2"
          >
            <Music className="w-4 h-4" />
            <span>إنشاء أول أغنية الآن 🎶</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {tracks.map((track) => {
            const char = CHARACTERS.find(c => c.id === track.characterId) || CHARACTERS[0];
            const isPlayingThis = playingTrackId === track.id;

            return (
              <div
                key={track.id}
                className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-slate-700 transition-all space-y-4 shadow-lg flex flex-col justify-between"
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-center text-2xl flex-shrink-0">
                        {char.avatarIcon}
                      </div>
                      <div>
                        <h4 className="font-bold text-white text-sm line-clamp-1">
                          {track.title}
                        </h4>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-[11px] text-amber-400 font-bold">
                            {char.name}
                          </span>
                          {track.genre && (
                            <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-medium">
                              {track.genre}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400 flex-shrink-0">
                      {track.type === 'song' ? 'أغنية 🎵' : 'صوت 🎙️'}
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 bg-slate-950/70 p-3 rounded-xl line-clamp-3 leading-relaxed border border-slate-800/80">
                    "{track.content}"
                  </p>

                  <div className="flex items-center gap-4 text-[11px] text-slate-500 font-mono">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      {track.formattedDate}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      {track.duration} ثانية
                    </span>
                  </div>
                </div>

                {/* Track Action Buttons */}
                <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-800">
                  <button
                    onClick={() => handlePlayTrack(track)}
                    className={`flex-1 py-2 px-3 rounded-xl flex items-center justify-center gap-2 font-bold text-xs transition-all ${
                      isPlayingThis
                        ? 'bg-rose-500 text-white'
                        : 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                    }`}
                  >
                    {isPlayingThis ? (
                      <>
                        <Square className="w-3.5 h-3.5 fill-current" />
                        <span>إيقاف</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-3.5 h-3.5 fill-current" />
                        <span>تشغيل المقطع</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => setExportTrack({ track, character: char })}
                    className="p-2 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/30 text-purple-400 text-xs font-bold transition-all flex items-center gap-1"
                    title="تصدير ومشاركة"
                  >
                    <Share2 className="w-4 h-4" />
                    <span className="hidden sm:inline">مشاركة</span>
                  </button>

                  {track.audioBase64 && (
                    <button
                      onClick={() => handleDownloadWav(track)}
                      className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-all"
                      title="تحميل ملف صوتي WAV"
                    >
                      <Download className="w-4 h-4" />
                    </button>
                  )}

                  <button
                    onClick={() => onDeleteTrack(track.id)}
                    className="p-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 transition-all"
                    title="حذف من المكتبة"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Export Modal */}
      {exportTrack && (
        <ShareExportModal
          isOpen={!!exportTrack}
          onClose={() => setExportTrack(null)}
          title={exportTrack.track.title}
          character={exportTrack.character}
          lyrics={exportTrack.track.content}
          audioBase64={exportTrack.track.audioBase64}
          duration={exportTrack.track.duration}
        />
      )}

    </div>
  );
};
