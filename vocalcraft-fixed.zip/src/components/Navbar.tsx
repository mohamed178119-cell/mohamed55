import React from 'react';
import { Volume2, Music, Mic, FolderHeart, Zap, Headphones, Smartphone, Download } from 'lucide-react';
import { audioEngine } from '../services/audioEngine';

interface NavbarProps {
  activeTab: 'tts' | 'song' | 'cartoon' | 'library';
  setActiveTab: (tab: 'tts' | 'song' | 'cartoon' | 'library') => void;
  savedCount: number;
  onOpenInstallModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  savedCount,
  onOpenInstallModal,
}) => {
  const [volume, setVolume] = React.useState(0.95);

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    audioEngine.setTrackVolume('master', val);
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800/80 bg-slate-950/85 backdrop-blur-xl transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo & Brand with App Icon */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('tts')}>
            <div className="relative w-12 h-12 rounded-2xl overflow-hidden shadow-lg shadow-amber-500/20 border border-amber-500/40 p-0.5 bg-gradient-to-tr from-amber-500 via-orange-500 to-rose-500">
              <img
                src="/pwa-192x192.png"
                alt="أيقونة صوتك ونغم"
                className="w-full h-full object-cover rounded-[14px]"
              />
              <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-emerald-500 border-2 border-slate-950 rounded-full"></span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-black tracking-tight text-white font-['Tajawal'] bg-gradient-to-r from-amber-400 via-orange-400 to-rose-400 bg-clip-text text-transparent">
                  صوتك ونغم
                </h1>
                <span className="text-xs px-2 py-0.5 rounded-full font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                  أصوات واقعية ✨
                </span>
              </div>
              <p className="text-xs text-slate-400">
                استوديو تحويل النصوص إلى أصوات وأغاني وموسيقى
              </p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="hidden md:flex items-center gap-2 bg-slate-900/80 p-1.5 rounded-2xl border border-slate-800">
            <button
              onClick={() => setActiveTab('tts')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
                activeTab === 'tts'
                  ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Mic className="w-4 h-4" />
              <span>أصوات واقعية (TTS)</span>
            </button>

            <button
              onClick={() => setActiveTab('song')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
                activeTab === 'song'
                  ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Music className="w-4 h-4" />
              <span>أغاني وموسيقى طربية</span>
            </button>

            <button
              onClick={() => setActiveTab('cartoon')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
                activeTab === 'cartoon'
                  ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Headphones className="w-4 h-4" />
              <span>حوارات واللهجات</span>
            </button>

            <button
              onClick={() => setActiveTab('library')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all relative ${
                activeTab === 'library'
                  ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <FolderHeart className="w-4 h-4" />
              <span>مكتبتي</span>
              {savedCount > 0 && (
                <span className={`text-xs px-2 py-0.5 rounded-full font-bold ${
                  activeTab === 'library' ? 'bg-slate-950 text-amber-400' : 'bg-amber-500/20 text-amber-400'
                }`}>
                  {savedCount}
                </span>
              )}
            </button>
          </nav>

          {/* Master Volume & APK Install Action */}
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-2 bg-slate-900/60 px-3 py-1.5 rounded-xl border border-slate-800">
              <Volume2 className="w-4 h-4 text-slate-400" />
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={volume}
                onChange={handleVolumeChange}
                className="w-16 accent-amber-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
                title="مستوى الصوت العام"
              />
              <span className="text-xs font-mono text-slate-400 w-8">
                {Math.round(volume * 100)}%
              </span>
            </div>

            {/* Install APK / Mobile App button */}
            <button
              onClick={onOpenInstallModal}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-black bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow-md shadow-emerald-500/20 hover:brightness-110 active:scale-95 transition-all"
              title="تثبيت التطبيق كـ APK على هاتفك"
            >
              <Smartphone className="w-4 h-4 text-slate-950" />
              <span>تثبيت APK 📱</span>
            </button>
          </div>

        </div>

        {/* Mobile Navigation bar */}
        <div className="flex md:hidden items-center justify-around py-2.5 border-t border-slate-800/60">
          <button
            onClick={() => setActiveTab('tts')}
            className={`flex flex-col items-center gap-1 text-xs font-bold ${
              activeTab === 'tts' ? 'text-amber-400' : 'text-slate-400'
            }`}
          >
            <Mic className="w-5 h-5" />
            <span>نص لصوت</span>
          </button>

          <button
            onClick={() => setActiveTab('song')}
            className={`flex flex-col items-center gap-1 text-xs font-bold ${
              activeTab === 'song' ? 'text-amber-400' : 'text-slate-400'
            }`}
          >
            <Music className="w-5 h-5" />
            <span>الأغاني</span>
          </button>

          <button
            onClick={() => setActiveTab('cartoon')}
            className={`flex flex-col items-center gap-1 text-xs font-bold ${
              activeTab === 'cartoon' ? 'text-amber-400' : 'text-slate-400'
            }`}
          >
            <Headphones className="w-5 h-5" />
            <span>الحوارات</span>
          </button>

          <button
            onClick={() => setActiveTab('library')}
            className={`flex flex-col items-center gap-1 text-xs font-bold relative ${
              activeTab === 'library' ? 'text-amber-400' : 'text-slate-400'
            }`}
          >
            <FolderHeart className="w-5 h-5" />
            <span>المكتبة</span>
            {savedCount > 0 && (
              <span className="absolute -top-1 -right-2 w-4 h-4 rounded-full bg-amber-500 text-slate-950 text-[10px] font-black flex items-center justify-center">
                {savedCount}
              </span>
            )}
          </button>

          <button
            onClick={onOpenInstallModal}
            className="flex flex-col items-center gap-1 text-xs font-bold text-emerald-400"
          >
            <Smartphone className="w-5 h-5" />
            <span>تثبيت APK</span>
          </button>
        </div>

      </div>
    </header>
  );
};
