import React, { useState, useRef, useEffect } from 'react';
import { 
  Play, Square, MessageSquare, Share2, Plus, Trash2, 
  Wand2, RefreshCw, Volume2, Sparkles, FolderPlus, ArrowUpDown, Check
} from 'lucide-react';
import { RealisticVoice, SavedTrack } from '../types';
import { REALISTIC_VOICES } from '../data/characters';
import { audioEngine } from '../services/audioEngine';
import { ApiService } from '../services/apiService';
import { ShareExportModal } from './ShareExportModal';

interface DialogueLine {
  id: string;
  speakerIndex: 0 | 1;
  text: string;
}

interface CartoonCornerProps {
  onSaveTrack: (track: SavedTrack) => void;
}

export const CartoonCorner: React.FC<CartoonCornerProps> = ({ onSaveTrack }) => {
  const [charAId, setCharAId] = useState('sara_melodic');
  const [charBId, setCharBId] = useState('omar_deep');
  const [dialogueTitle, setDialogueTitle] = useState('حوار عن أثر الكلمة الطيبة وبناء الأمل');
  const [dialogueTopic, setDialogueTopic] = useState('نقاش راقٍ بين شخصين حول أثر الكلمة الطيبة والتفاؤل في الحياة');
  const [isGeneratingAiDialogue, setIsGeneratingAiDialogue] = useState(false);

  // Editable custom dialogue lines
  const [lines, setLines] = useState<DialogueLine[]>([
    {
      id: 'line_1',
      speakerIndex: 0,
      text: 'مساء الخير يا عمر، هل فكرت يوماً كيف يمكن لكلمة طيبة واحدة أن تضيء يوم إنسان وتغير نظرته للحياة؟',
    },
    {
      id: 'line_2',
      speakerIndex: 1,
      text: 'مساء النور يا سارة. بكل تأكيد، الكلمات الصادقة لها طاقة سحرية تتجاوز الأسماع لتستقر في أعماق القلب.',
    },
    {
      id: 'line_3',
      speakerIndex: 0,
      text: 'صحيح تماماً، فالإنصات الواعي والحديث بمودة هما أعظم هدية يمكن أن نقدمها لمن حولنا في هذا العالم السريع.',
    },
    {
      id: 'line_4',
      speakerIndex: 1,
      text: 'أوافقك الرأي تماماً. فلنحرص دائماً على أن تكون كلماتنا بلسماً وسلاماً أينما حللنا.',
    },
  ]);

  const [isPlayingDialogue, setIsPlayingDialogue] = useState(false);
  const [activeDialogueIndex, setActiveDialogueIndex] = useState<number | null>(null);
  const [playingSingleLineId, setPlayingSingleLineId] = useState<string | null>(null);

  // Ref to cancel playback immediately without React closure state delays
  const isCancelledRef = useRef<boolean>(false);

  const [savedSuccess, setSavedSuccess] = useState(false);
  const [shareData, setShareData] = useState<{
    title: string;
    character: RealisticVoice;
    lyrics: string;
    audioBase64?: string;
  } | null>(null);

  const voiceA = REALISTIC_VOICES.find(v => v.id === charAId) || REALISTIC_VOICES[0];
  const voiceB = REALISTIC_VOICES.find(v => v.id === charBId) || REALISTIC_VOICES[1];

  // Stop playback when component unmounts
  useEffect(() => {
    return () => {
      isCancelledRef.current = true;
      audioEngine.stopPlayback();
    };
  }, []);

  // Helper: Play a single line of speech cleanly and return a Promise that resolves when finished
  const playSpeechLine = (text: string, voice: RealisticVoice): Promise<void> => {
    return new Promise((resolve) => {
      let isDone = false;
      const finish = () => {
        if (!isDone) {
          isDone = true;
          resolve();
        }
      };

      // Safety fallback timer in case speech synthesis end event drops
      const safetyTimeout = setTimeout(finish, Math.max(3500, text.length * 160));

      const onEnded = () => {
        clearTimeout(safetyTimeout);
        finish();
      };

      if (isCancelledRef.current) {
        clearTimeout(safetyTimeout);
        finish();
        return;
      }

      // Try server-side Gemini TTS first
      ApiService.generateTTS(text, voice)
        .then((res) => {
          if (isCancelledRef.current) {
            clearTimeout(safetyTimeout);
            finish();
            return;
          }
          audioEngine.playBase64Audio(
            res.audioBase64,
            { speed: 1.0, pitch: 0, reverb: 0.1, bassBoost: 0.2, presence: 0.5 },
            onEnded
          ).catch(() => {
            fallbackToNative();
          });
        })
        .catch(() => {
          fallbackToNative();
        });

      function fallbackToNative() {
        if (isCancelledRef.current) {
          clearTimeout(safetyTimeout);
          finish();
          return;
        }
        audioEngine.speakNative(
          text,
          { speed: 1.0, pitch: 0, reverb: 0.1, bassBoost: 0.2, presence: 0.5 },
          voice,
          undefined,
          onEnded
        );
      }
    });
  };

  // Play full dialogue sequentially (first voice, second voice, third voice...)
  const handlePlayDialogue = async () => {
    if (isPlayingDialogue) {
      handleStopDialogue();
      return;
    }

    if (lines.length === 0) return;

    audioEngine.init();
    isCancelledRef.current = false;
    setIsPlayingDialogue(true);

    for (let i = 0; i < lines.length; i++) {
      if (isCancelledRef.current) {
        break;
      }

      setActiveDialogueIndex(i);
      const currentLine = lines[i];
      const speakerVoice = currentLine.speakerIndex === 0 ? voiceA : voiceB;

      // Play this line and wait until it completely finishes speaking
      await playSpeechLine(currentLine.text, speakerVoice);

      if (isCancelledRef.current) {
        break;
      }

      // Natural human breath pause between conversational turns (450ms)
      await new Promise(r => setTimeout(r, 450));
    }

    setIsPlayingDialogue(false);
    setActiveDialogueIndex(null);
  };

  const handleStopDialogue = () => {
    isCancelledRef.current = true;
    audioEngine.stopPlayback();
    setIsPlayingDialogue(false);
    setActiveDialogueIndex(null);
    setPlayingSingleLineId(null);
  };

  // Play a single line isolated
  const handlePlaySingleLine = async (line: DialogueLine) => {
    if (playingSingleLineId === line.id) {
      audioEngine.stopPlayback();
      setPlayingSingleLineId(null);
      return;
    }

    audioEngine.init();
    handleStopDialogue();
    setPlayingSingleLineId(line.id);
    const speakerVoice = line.speakerIndex === 0 ? voiceA : voiceB;

    await playSpeechLine(line.text, speakerVoice);
    setPlayingSingleLineId(null);
  };

  // Add a new line to custom dialogue
  const handleAddLine = () => {
    const lastIndex = lines.length > 0 ? lines[lines.length - 1].speakerIndex : 1;
    const nextSpeaker: 0 | 1 = lastIndex === 0 ? 1 : 0;
    const newLine: DialogueLine = {
      id: 'line_' + Date.now(),
      speakerIndex: nextSpeaker,
      text: nextSpeaker === 0 ? 'ما رأيك في هذه الفكرة؟' : 'أرى أنها فكرة ممتازة وتستحق التجربة!',
    };
    setLines([...lines, newLine]);
  };

  // Update text of a line
  const handleUpdateLineText = (id: string, newText: string) => {
    setLines(lines.map(l => l.id === id ? { ...l, text: newText } : l));
  };

  // Toggle speaker for a line
  const handleToggleSpeaker = (id: string) => {
    setLines(lines.map(l => l.id === id ? { ...l, speakerIndex: l.speakerIndex === 0 ? 1 : 0 } : l));
  };

  // Delete line
  const handleDeleteLine = (id: string) => {
    if (lines.length <= 1) {
      alert('يجب أن يحتوي الحوار على سطر واحد على الأقل');
      return;
    }
    setLines(lines.filter(l => l.id !== id));
  };

  // AI Dialogue Generator
  const handleAiGenerateDialogue = async () => {
    if (!dialogueTopic.trim()) return;
    try {
      setIsGeneratingAiDialogue(true);
      handleStopDialogue();

      const speakerAName = voiceA.name.split('-')[0].trim();
      const speakerBName = voiceB.name.split('-')[0].trim();

      const res = await ApiService.generateDialogue(dialogueTopic, speakerAName, speakerBName);
      
      if (res && res.lines && res.lines.length > 0) {
        setDialogueTitle(res.title || `حوار بين ${speakerAName} و ${speakerBName}`);
        const formatted: DialogueLine[] = res.lines.map((l, idx) => ({
          id: 'ai_line_' + Date.now() + '_' + idx,
          speakerIndex: l.speakerIndex === 1 ? 1 : 0,
          text: l.text,
        }));
        setLines(formatted);
      }
      setIsGeneratingAiDialogue(false);
    } catch (e) {
      console.error(e);
      setIsGeneratingAiDialogue(false);
    }
  };

  // Save dialogue to library
  const handleSaveDialogue = () => {
    const fullText = lines.map(l => {
      const speakerName = l.speakerIndex === 0 ? voiceA.name.split('-')[0].trim() : voiceB.name.split('-')[0].trim();
      return `${speakerName}: ${l.text}`;
    }).join('\n\n');

    const item: SavedTrack = {
      id: 'dialogue_' + Date.now(),
      title: dialogueTitle,
      content: fullText,
      type: 'speech',
      characterId: voiceA.id,
      genre: 'حوار ثنائي واقعي',
      duration: Math.max(10, Math.round(fullText.length / 15)),
      createdAt: Date.now(),
      formattedDate: new Date().toLocaleDateString('ar-EG', {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }),
    };

    onSaveTrack(item);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="space-y-8">
      
      {/* Studio Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-amber-500/15 via-rose-500/15 to-purple-500/15 border border-slate-800 p-6 sm:p-8">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
              <Sparkles className="w-3.5 h-3.5" />
              <span>محرر الحوارات المخصص وتوليد المحادثات بالذكاء الاصطناعي</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white font-['Tajawal'] tracking-wide">
              استوديو الحوارات الثنائية المخصصة 🎙️💬
            </h2>
            <p className="text-slate-300 text-sm leading-relaxed">
              اكتب حوارك بنفسك بكل حرية، عدّل نصوص كل متحدث، أضف أسطراً جديدة أو اطلب من الذكاء الاصطناعي تأليف حوار واقعي كامل حول أي فكرة، واستمع للمحادثة كاملة بالتناوب الطبيعي بين الصوتين!
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => {
                setDialogueTopic('حوار بين صديقين عن الاستعداد لرحلة سفر إلى شاطئ البحر');
                setCharAId('mariam_egyptian');
                setCharBId('karim_youth');
              }}
              className="text-xs bg-slate-900/80 hover:bg-slate-800 text-amber-300 border border-amber-500/30 px-3.5 py-2 rounded-xl font-bold transition-all shadow-sm"
            >
              ☀️ حوار رحلة وسفر
            </button>
            <button
              onClick={() => {
                setDialogueTopic('نقاش علمي وثائقي ممتع عن استكشاف أعماق البحار والمحيطات');
                setCharAId('yasmine_doc');
                setCharBId('omar_deep');
              }}
              className="text-xs bg-slate-900/80 hover:bg-slate-800 text-emerald-300 border border-emerald-500/30 px-3.5 py-2 rounded-xl font-bold transition-all shadow-sm"
            >
              🌍 نقاش وثائقي
            </button>
            <button
              onClick={() => {
                setDialogueTopic('حوار رومانسي وشعري راقٍ عن لقاء الأحبة في المساء');
                setCharAId('laila_tarab');
                setCharBId('zain_singer');
              }}
              className="text-xs bg-slate-900/80 hover:bg-slate-800 text-purple-300 border border-purple-500/30 px-3.5 py-2 rounded-xl font-bold transition-all shadow-sm"
            >
              🪕 حوار شعري وطربي
            </button>
          </div>
        </div>
      </div>

      {/* Select the Two Speakers */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
        <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
          <MessageSquare className="w-4 h-4 text-amber-400" />
          <span>تحديد طرفي الحوار (المتحدث الأول والمتحدث الثاني):</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          
          {/* Speaker A */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                <span>المتحدث الأول (طرف أ):</span>
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                {voiceA.dialect}
              </span>
            </div>
            
            <select
              value={charAId}
              onChange={(e) => setCharAId(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-xs font-bold text-slate-100"
            >
              {REALISTIC_VOICES.map(v => (
                <option key={`spk_a_${v.id}`} value={v.id}>
                  {v.avatarIcon} {v.name} ({v.badge})
                </option>
              ))}
            </select>
          </div>

          {/* Speaker B */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-rose-400 flex items-center gap-1.5">
                <span>المتحدث الثاني (طرف ب):</span>
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                {voiceB.dialect}
              </span>
            </div>

            <select
              value={charBId}
              onChange={(e) => setCharBId(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-xs font-bold text-slate-100"
            >
              {REALISTIC_VOICES.map(v => (
                <option key={`spk_b_${v.id}`} value={v.id}>
                  {v.avatarIcon} {v.name} ({v.badge})
                </option>
              ))}
            </select>
          </div>

        </div>
      </div>

      {/* AI Scenario Generator Drawer */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <label className="text-xs font-bold text-slate-300 flex items-center gap-2">
            <Wand2 className="w-4 h-4 text-amber-400" />
            <span>اطلب من الذكاء الاصطناعي تأليف سيناريو حوار جديد (أو اكتبه بنفسك بالأسفل):</span>
          </label>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-3">
          <input
            type="text"
            value={dialogueTopic}
            onChange={(e) => setDialogueTopic(e.target.value)}
            placeholder="مثال: نقاش بين شخصين حول أهمية التعلم المستمر أو نصيحة قبل الامتحان..."
            className="flex-1 w-full bg-slate-950 border border-slate-800 rounded-2xl px-4 py-3 text-xs text-slate-100 placeholder:text-slate-600 focus:border-amber-500 focus:outline-none"
          />

          <button
            onClick={handleAiGenerateDialogue}
            disabled={isGeneratingAiDialogue || !dialogueTopic.trim()}
            className="w-full sm:w-auto px-5 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 hover:brightness-110 text-slate-950 font-black text-xs transition-all shadow-md flex items-center justify-center gap-2 whitespace-nowrap disabled:opacity-50"
          >
            {isGeneratingAiDialogue ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>جاري تأليف الحوار...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>تأليف الحوار بالذكاء الاصطناعي 🪄</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Custom Dialogue Editor Section */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-6">
        
        {/* Editor Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={dialogueTitle}
                onChange={(e) => setDialogueTitle(e.target.value)}
                className="bg-transparent font-black text-white text-lg font-['Tajawal'] border-b border-dashed border-slate-700 focus:border-amber-400 focus:outline-none pb-0.5"
                placeholder="عنوان الحوار..."
              />
            </div>
            <p className="text-xs text-slate-400">
              يمكنك كتابة وتعديل كل سطر، وتغيير المتحدث، والاستماع لكل سطر بمفرده أو تشغيل الحوار كاملاً.
            </p>
          </div>

          {/* Master Play / Stop Controls */}
          <div className="flex items-center gap-2">
            <button
              onClick={handlePlayDialogue}
              className={`flex items-center justify-center gap-2 py-3 px-6 rounded-2xl font-black text-sm shadow-lg transition-all ${
                isPlayingDialogue
                  ? 'bg-rose-500 hover:bg-rose-600 text-white animate-pulse'
                  : 'bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 hover:brightness-110 text-slate-950 shadow-amber-500/25'
              }`}
            >
              {isPlayingDialogue ? (
                <>
                  <Square className="w-4 h-4 fill-current" />
                  <span>إيقاف الحوار ⏹️</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-current" />
                  <span>تشغيل الحوار كاملاً بالتناوب 🎬</span>
                </>
              )}
            </button>

            <button
              onClick={handleSaveDialogue}
              className="p-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-all"
              title="حفظ في المكتبة"
            >
              {savedSuccess ? <Check className="w-5 h-5 text-emerald-400" /> : <FolderPlus className="w-5 h-5 text-amber-400" />}
            </button>

            <button
              onClick={() => {
                const fullText = lines.map(l => {
                  const spk = l.speakerIndex === 0 ? voiceA.name.split('-')[0].trim() : voiceB.name.split('-')[0].trim();
                  return `${spk}: ${l.text}`;
                }).join('\n\n');

                setShareData({
                  title: dialogueTitle,
                  character: voiceA,
                  lyrics: fullText,
                });
              }}
              className="p-3 rounded-2xl bg-purple-600 hover:bg-purple-500 text-white transition-all shadow-md"
              title="مشاركة وتصدير فيديو"
            >
              <Share2 className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Dialogue Lines List (Editable) */}
        <div className="space-y-4">
          {lines.map((line, idx) => {
            const isSpeakerA = line.speakerIndex === 0;
            const currentVoice = isSpeakerA ? voiceA : voiceB;
            const isCurrentlyPlaying = isPlayingDialogue && activeDialogueIndex === idx;
            const isPlayingThisSolo = playingSingleLineId === line.id;

            return (
              <div
                key={line.id}
                className={`p-4 rounded-2xl border transition-all duration-300 ${
                  isCurrentlyPlaying
                    ? 'bg-amber-500/10 border-amber-400 ring-2 ring-amber-400/25 shadow-xl scale-[1.01]'
                    : isSpeakerA
                    ? 'bg-slate-950/80 border-slate-800/90'
                    : 'bg-slate-950/60 border-slate-800/60'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2.5">
                  
                  {/* Speaker Selector Button (Toggle between Voice A & Voice B) */}
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleToggleSpeaker(line.id)}
                      className={`flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-bold transition-all border ${
                        isSpeakerA
                          ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 hover:bg-amber-500/30'
                          : 'bg-rose-500/20 text-rose-300 border-rose-500/40 hover:bg-rose-500/30'
                      }`}
                      title="اضغط للتبديل بين المتحدثين"
                    >
                      <span className="text-base">{currentVoice.avatarIcon}</span>
                      <span>{currentVoice.name.split('-')[0].trim()}</span>
                      <ArrowUpDown className="w-3 h-3 text-slate-400 mr-1" />
                    </button>

                    <span className="text-[10px] text-slate-500 font-mono">
                      (السطر {idx + 1} من {lines.length})
                    </span>

                    {isCurrentlyPlaying && (
                      <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-amber-500 text-slate-950 animate-pulse flex items-center gap-1">
                        <Volume2 className="w-3 h-3" />
                        <span>يتحدث الآن</span>
                      </span>
                    )}
                  </div>

                  {/* Line Actions (Play Solo / Delete) */}
                  <div className="flex items-center gap-1.5 self-end sm:self-auto">
                    <button
                      onClick={() => handlePlaySingleLine(line)}
                      className={`p-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 ${
                        isPlayingThisSolo
                          ? 'bg-rose-500 text-white'
                          : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                      }`}
                      title="تشغيل هذا السطر فقط"
                    >
                      {isPlayingThisSolo ? <Square className="w-3.5 h-3.5 fill-current" /> : <Play className="w-3.5 h-3.5 fill-current" />}
                      <span className="hidden sm:inline">تجربة</span>
                    </button>

                    <button
                      onClick={() => handleDeleteLine(line.id)}
                      className="p-1.5 rounded-lg text-xs text-rose-400 hover:bg-rose-500/10 transition-all"
                      title="حذف هذا السطر"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Editable Textarea for this dialogue line */}
                <textarea
                  value={line.text}
                  onChange={(e) => handleUpdateLineText(line.id, e.target.value)}
                  rows={2}
                  className="w-full bg-slate-900/90 border border-slate-800 rounded-xl p-3 text-sm text-slate-100 focus:border-amber-400 focus:ring-1 focus:ring-amber-400 leading-relaxed resize-none transition-all"
                  placeholder="اكتب هنا ما تقوله هذه الشخصية..."
                />
              </div>
            );
          })}
        </div>

        {/* Add New Line Button */}
        <div className="pt-2">
          <button
            onClick={handleAddLine}
            className="w-full py-3.5 rounded-2xl bg-slate-800/80 hover:bg-slate-800 border-2 border-dashed border-slate-700 hover:border-amber-400 text-slate-300 hover:text-amber-400 font-bold text-xs transition-all flex items-center justify-center gap-2"
          >
            <Plus className="w-4 h-4" />
            <span>➕ إضافة سطر جديد للحوار (Add Line)</span>
          </button>
        </div>

      </div>

      {/* Share / Video Export Modal */}
      {shareData && (
        <ShareExportModal
          isOpen={!!shareData}
          onClose={() => setShareData(null)}
          title={shareData.title}
          character={shareData.character}
          lyrics={shareData.lyrics}
          audioBase64={shareData.audioBase64}
          duration={Math.min(30, Math.max(12, lines.length * 5))}
        />
      )}

    </div>
  );
};
