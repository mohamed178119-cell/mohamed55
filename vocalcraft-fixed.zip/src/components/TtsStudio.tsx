import React, { useState, useEffect } from 'react';
import { 
  Mic, Play, Square, Volume2, Sparkles, 
  Share2, FolderPlus, RefreshCw, CheckCircle, SlidersHorizontal, Heart, Headphones
} from 'lucide-react';
import { RealisticVoice, AudioSettings, SavedTrack } from '../types';
import { REALISTIC_VOICES } from '../data/characters';
import { audioEngine } from '../services/audioEngine';
import { ApiService } from '../services/apiService';
import { Visualizer } from './Visualizer';
import { ShareExportModal } from './ShareExportModal';

interface TtsStudioProps {
  onSaveTrack: (track: SavedTrack) => void;
}

export const TtsStudio: React.FC<TtsStudioProps> = ({ onSaveTrack }) => {
  const [text, setText] = useState('أهلاً بكم في استوديو الأصوات الواقعية. هنا تستمع إلى أصوات طبيعية نقية، تحاكي أرقى معايير الإلقاء والسرد الإذاعي والقصصي.');
  const [selectedVoiceId, setSelectedVoiceId] = useState('sara_melodic');
  const [genderFilter, setGenderFilter] = useState<'all' | 'female' | 'male'>('all');
  
  const [isGenerating, setIsGenerating] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentAudioBase64, setCurrentAudioBase64] = useState<string | null>(null);

  // Available real system voices
  const [systemVoices, setSystemVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [preferredVoiceUri, setPreferredVoiceUri] = useState<string>('');

  // Audio Natural Settings
  const [settings, setSettings] = useState<AudioSettings>({
    speed: 1.0,
    pitch: 0,
    reverb: 0.1,
    bassBoost: 0.2,
    presence: 0.5,
  });

  const [showAcoustics, setShowAcoustics] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Fetch real system voices on mount
  useEffect(() => {
    const updateVoices = () => {
      const v = audioEngine.getAvailableSystemVoices();
      setSystemVoices(v);
    };

    updateVoices();
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.onvoiceschanged = updateVoices;
    }
  }, []);

  const selectedVoice = REALISTIC_VOICES.find(v => v.id === selectedVoiceId) || REALISTIC_VOICES[0];

  const filteredVoices = REALISTIC_VOICES.filter(v => {
    if (genderFilter === 'female') return v.gender === 'female';
    if (genderFilter === 'male') return v.gender === 'male';
    return true;
  });

  const handleSpeak = async () => {
    if (!text.trim()) return;

    if (isPlaying) {
      audioEngine.stopPlayback();
      setIsPlaying(false);
      return;
    }

    try {
      setIsGenerating(true);
      audioEngine.init();

      // Call realistic Gemini TTS API
      const res = await ApiService.generateTTS(text, selectedVoice);
      setCurrentAudioBase64(res.audioBase64);
      setIsGenerating(false);
      setIsPlaying(true);

      // Play pristine studio audio cleanly
      await audioEngine.playBase64Audio(
        res.audioBase64,
        settings,
        () => setIsPlaying(false)
      );
    } catch (err: any) {
      console.warn('Using high-quality system speech engine:', err?.message);
      setIsGenerating(false);
      setIsPlaying(true);

      // Natural speech synthesis with authentic human cadence
      audioEngine.speakNative(
        text,
        settings,
        selectedVoice,
        preferredVoiceUri || undefined,
        () => setIsPlaying(false)
      );
    }
  };

  const handleStop = () => {
    audioEngine.stopPlayback();
    setIsPlaying(false);
  };

  const handleSave = () => {
    const item: SavedTrack = {
      id: 'voice_' + Date.now(),
      title: `تسجيل بصوت ${selectedVoice.name.split('-')[0].trim()}`,
      content: text,
      type: 'speech',
      characterId: selectedVoice.id,
      audioBase64: currentAudioBase64 || undefined,
      duration: Math.max(5, Math.round(text.length / 14)),
      createdAt: Date.now(),
      formattedDate: new Date().toLocaleDateString('ar-EG', {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }),
    };
    onSaveTrack(item);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="space-y-8">
      
      {/* Studio Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-amber-500/10 via-rose-500/10 to-purple-500/10 border border-slate-800 p-6 sm:p-8">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
              <CheckCircle className="w-3.5 h-3.5" />
              <span>أصوات واقعية 100% طبيعية وخالية من أي تشويه</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white font-['Tajawal'] tracking-wide">
              استوديو الأصوات الواقعية والنقية 🎙️
            </h2>
            <p className="text-slate-300 text-sm leading-relaxed">
              اختر من بين نخبة من الأصوات البشرية الطبيعية باللغة العربية الفصحى واللهجات المحبوبة (المصرية، الخليجية، الشامية). نبرات دافئة، مخارج حروف فصيحة، وإلقاء يحاكي كبار المعلقين والإذاعيين.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                setText('في هدوء هذا المساء الجميل، ننصت لأجمل الحكايات التي تلامس القلوب وتبث الأمل في النفوس.');
                setSelectedVoiceId('sara_melodic');
              }}
              className="text-xs bg-slate-900/80 hover:bg-slate-800 text-rose-300 border border-rose-500/30 px-3.5 py-2 rounded-xl font-bold transition-all shadow-sm"
            >
              🌸 تجربة صوت سارة العذب
            </button>
            <button
              onClick={() => {
                setText('بين ثنايا التاريخ الإنساني، بقيت هناك أسرارٌ كبرى تتحدى الزمن وتنتظر من يكتشف حقيقتها.');
                setSelectedVoiceId('omar_deep');
              }}
              className="text-xs bg-slate-900/80 hover:bg-slate-800 text-amber-300 border border-amber-500/30 px-3.5 py-2 rounded-xl font-bold transition-all shadow-sm"
            >
              🎙️ تجربة صوت عمر الرخيم
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column / Text Input & Real Voices (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Text Area */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-sm font-bold text-slate-200 flex items-center gap-2">
                <Mic className="w-4 h-4 text-amber-400" />
                <span>اكتب أو الصق النص هنا:</span>
              </label>
              <span className="text-xs text-slate-400 font-mono">
                {text.length} حرف
              </span>
            </div>

            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              rows={4}
              placeholder="اكتب هنا أي نص، خاطرة، مقال، أو قصة لتحويلها لصوت طبيعي نقي..."
              className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 rounded-2xl p-4 text-slate-100 text-sm leading-relaxed resize-none transition-all placeholder:text-slate-600"
            />

            {/* Quick Sample Quotes */}
            <div className="space-y-2 pt-1">
              <span className="text-xs font-bold text-slate-400">عبارات جاهزة منتقاة لهذا الصوت:</span>
              <div className="flex flex-wrap gap-2">
                {selectedVoice.samplePhrases.map((phrase, i) => (
                  <button
                    key={i}
                    onClick={() => setText(phrase)}
                    className="text-xs bg-slate-800/80 hover:bg-slate-700 text-slate-300 px-3 py-1.5 rounded-xl transition-all border border-slate-700/60 text-right line-clamp-1 max-w-[320px]"
                  >
                    "{phrase}"
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Realistic Voices Directory */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
                  <Headphones className="w-4 h-4 text-amber-400" />
                  <span>دليل الأصوات الواقعية ({REALISTIC_VOICES.length} أصوات):</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  أصوات بشرية عالية النقاء بدرجات صوتية ولهجات متنوعة
                </p>
              </div>

              {/* Gender Filter Tabs */}
              <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800">
                <button
                  onClick={() => setGenderFilter('all')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                    genderFilter === 'all' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  الكل
                </button>
                <button
                  onClick={() => setGenderFilter('female')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                    genderFilter === 'female' ? 'bg-rose-500 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  نسائي 👩
                </button>
                <button
                  onClick={() => setGenderFilter('male')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                    genderFilter === 'male' ? 'bg-blue-500 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  رجالي 👨
                </button>
              </div>
            </div>

            {/* Voices Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[380px] overflow-y-auto pr-1">
              {filteredVoices.map((voice) => {
                const isSelected = selectedVoiceId === voice.id;
                return (
                  <button
                    key={voice.id}
                    onClick={() => {
                      setSelectedVoiceId(voice.id);
                      if (voice.samplePhrases[0]) {
                        setText(voice.samplePhrases[0]);
                      }
                    }}
                    className={`p-4 rounded-2xl text-right transition-all border flex items-start gap-3.5 ${
                      isSelected
                        ? 'bg-slate-800/90 border-amber-400 ring-2 ring-amber-400/20 shadow-lg'
                        : 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700 hover:bg-slate-900'
                    }`}
                  >
                    <div className="w-12 h-12 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center text-2xl flex-shrink-0 shadow-inner">
                      {voice.avatarIcon}
                    </div>
                    <div className="overflow-hidden flex-1">
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <p className={`text-xs font-bold truncate ${isSelected ? 'text-amber-400' : 'text-slate-100'}`}>
                          {voice.name}
                        </p>
                      </div>
                      <div className="flex items-center gap-1.5 mb-1.5">
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                          {voice.badge}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          {voice.dialect}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                        {voice.description}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* System Voice Selector (for local neural voices) */}
            {systemVoices.length > 0 && (
              <div className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800/80 space-y-1.5">
                <div className="flex items-center justify-between text-xs text-slate-400 font-bold">
                  <span>محرك الصوت المحلي بالجهاز (اختياري):</span>
                  <span className="text-emerald-400 text-[10px]">مكتشف تلقائياً</span>
                </div>
                <select
                  value={preferredVoiceUri}
                  onChange={(e) => setPreferredVoiceUri(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs font-bold text-slate-200"
                >
                  <option value="">تلقائي (أفضل صوت عربي نقي متاح)</option>
                  {systemVoices.map((v, idx) => (
                    <option key={`sys_voice_${v.voiceURI || v.name}_${v.lang}_${idx}`} value={v.voiceURI || v.name}>
                      {v.name} ({v.lang})
                    </option>
                  ))}
                </select>
              </div>
            )}

          </div>

        </div>

        {/* Right Column / Live Visualizer & Studio Controls (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-6 sticky top-24">
            
            {/* Selected Voice Card */}
            <div className="flex items-center gap-4 p-4 rounded-2xl bg-slate-950 border border-slate-800">
              <div className="relative">
                <div className="w-16 h-16 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-4xl shadow-inner">
                  {selectedVoice.avatarIcon}
                </div>
                {isPlaying && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full animate-ping" />
                )}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-white text-base">
                    {selectedVoice.name}
                  </h3>
                </div>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-[10px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full border border-amber-500/30 font-bold">
                    {selectedVoice.badge}
                  </span>
                  <span className="text-xs text-slate-400 font-medium">
                    {selectedVoice.tone}
                  </span>
                </div>
              </div>
            </div>

            {/* Neon Sound Visualizer */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400 font-bold">
                <span>مستوى الصوت والنقاء:</span>
                <span className={isPlaying ? 'text-emerald-400 animate-pulse font-bold' : 'text-slate-500'}>
                  {isPlaying ? 'جاري الاستماع الآن 🔊' : 'جاهز للتشغيل'}
                </span>
              </div>
              <Visualizer
                color={selectedVoice.accentHex}
                glowColor={selectedVoice.glowColor}
                height={85}
                barCount={36}
              />
            </div>

            {/* Play / Stop / Action Buttons */}
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={handleSpeak}
                disabled={isGenerating || !text.trim()}
                className={`flex items-center justify-center gap-2 py-4 px-4 rounded-2xl font-black text-sm shadow-lg transition-all ${
                  isPlaying
                    ? 'bg-rose-500 hover:bg-rose-600 text-white shadow-rose-500/20'
                    : 'bg-gradient-to-r from-amber-500 to-orange-500 hover:brightness-110 text-slate-950 shadow-amber-500/25 disabled:opacity-50'
                }`}
              >
                {isGenerating ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>توليد الصوت الواقعي...</span>
                  </>
                ) : isPlaying ? (
                  <>
                    <Square className="w-4 h-4 fill-current" />
                    <span>إيقاف الصوت</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-current" />
                    <span>تشغيل الصوت الواقعي 🔊</span>
                  </>
                )}
              </button>

              <button
                onClick={() => setIsShareModalOpen(true)}
                className="flex items-center justify-center gap-2 py-4 px-4 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:brightness-110 text-white font-bold text-sm shadow-lg shadow-purple-500/20 transition-all"
              >
                <Share2 className="w-4 h-4" />
                <span>مشاركة وتصدير 🚀</span>
              </button>
            </div>

            {/* Natural Acoustics Adjustment */}
            <div className="border-t border-slate-800 pt-4">
              <button
                onClick={() => setShowAcoustics(!showAcoustics)}
                className="w-full flex items-center justify-between text-xs font-bold text-slate-300 hover:text-white transition-all py-1"
              >
                <span className="flex items-center gap-2">
                  <SlidersHorizontal className="w-4 h-4 text-amber-400" />
                  <span>ضبط سرعة الإلقاء ودفء الصوت (Acoustics)</span>
                </span>
                <span className="text-amber-400">{showAcoustics ? 'إخفاء ▲' : 'إظهار ▼'}</span>
              </button>

              {showAcoustics && (
                <div className="space-y-4 pt-4 mt-2 border-t border-slate-800/80">
                  {/* Speed */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-400">سرعة الإلقاء (طبيعي 1.0x):</span>
                      <span className="font-mono text-amber-400">{settings.speed}x</span>
                    </div>
                    <input
                      type="range"
                      min="0.8"
                      max="1.3"
                      step="0.05"
                      value={settings.speed}
                      onChange={(e) => setSettings({ ...settings, speed: parseFloat(e.target.value) })}
                      className="w-full accent-amber-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                    />
                  </div>

                  {/* Bass Warmth */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-400">دفء الصوت والجهير (Warmth):</span>
                      <span className="font-mono text-amber-400">{Math.round(settings.bassBoost * 100)}%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="0.8"
                      step="0.05"
                      value={settings.bassBoost}
                      onChange={(e) => setSettings({ ...settings, bassBoost: parseFloat(e.target.value) })}
                      className="w-full accent-amber-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                    />
                  </div>

                  {/* Soft Room Ambience */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-400">صدى الغرفة الطبيعي (Ambience):</span>
                      <span className="font-mono text-amber-400">{Math.round(settings.reverb * 100)}%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="0.4"
                      step="0.05"
                      value={settings.reverb}
                      onChange={(e) => setSettings({ ...settings, reverb: parseFloat(e.target.value) })}
                      className="w-full accent-amber-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Save Button */}
            <button
              onClick={handleSave}
              className="w-full py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-all flex items-center justify-center gap-2 border border-slate-700"
            >
              <FolderPlus className="w-4 h-4 text-amber-400" />
              <span>{savedSuccess ? 'تم حفظ المقطع في مكتبتك! ✅' : 'حفظ المقطع في المكتبة (Save Track)'}</span>
            </button>

          </div>

        </div>

      </div>

      {/* Share & Social Media Modal */}
      <ShareExportModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
        title={`تسجيل بصوت ${selectedVoice.name.split('-')[0].trim()}`}
        character={selectedVoice}
        lyrics={text}
        audioBase64={currentAudioBase64 || undefined}
        duration={14}
      />

    </div>
  );
};
