import React, { useState } from 'react';
import { 
  Download, Smartphone, CheckCircle, X, Sparkles, 
  ExternalLink, ArrowLeft, ShieldCheck, Zap, Share2
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PWAInstallModal: React.FC<PWAInstallModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const [installSuccess, setInstallSuccess] = useState(false);

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    if (isInstallable) {
      const success = await install();
      if (success) {
        setInstallSuccess(true);
        setTimeout(() => {
          setInstallSuccess(false);
          onClose();
        }, 2500);
      }
    }
  };

  const currentUrl = typeof window !== 'undefined' ? window.location.href : '';
  const pwaBuilderUrl = `https://www.pwabuilder.com/reportcard?site=${encodeURIComponent(currentUrl)}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl text-right space-y-6">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-6 left-6 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-all"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header with App Icon */}
        <div className="flex flex-col items-center text-center space-y-3 pt-2">
          <div className="relative group">
            <div className="w-24 h-24 rounded-3xl overflow-hidden shadow-2xl shadow-amber-500/25 border-2 border-amber-500/40 p-1 bg-gradient-to-tr from-amber-500 via-orange-500 to-rose-500">
              <img
                src="/pwa-512x512.png"
                alt="أيقونة تطبيق صوتك ونغم"
                className="w-full h-full object-cover rounded-2xl"
              />
            </div>
            <span className="absolute -bottom-1 -right-1 w-6 h-6 bg-emerald-500 border-2 border-slate-950 rounded-full flex items-center justify-center text-[10px] text-slate-950 font-black">
              ✓
            </span>
          </div>

          <div className="space-y-1">
            <div className="flex items-center justify-center gap-2">
              <h2 className="text-xl sm:text-2xl font-black text-white font-['Tajawal']">
                تثبيت تطبيق «صوتك ونغم» على هاتفك
              </h2>
            </div>
            <p className="text-xs text-amber-400 font-bold">
              تطبيق أندرويد وiOS كامل الشاشة (APK / PWA)
            </p>
          </div>
        </div>

        {/* Features Checklist */}
        <div className="grid grid-cols-2 gap-2.5 p-4 rounded-2xl bg-slate-950/80 border border-slate-800 text-xs">
          <div className="flex items-center gap-2 text-slate-300">
            <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span>يعمل بدون متصفح بشاشة كاملة</span>
          </div>
          <div className="flex items-center gap-2 text-slate-300">
            <Zap className="w-4 h-4 text-amber-400 flex-shrink-0" />
            <span>سرعة فائقة واستجابة فورية</span>
          </div>
          <div className="flex items-center gap-2 text-slate-300">
            <Sparkles className="w-4 h-4 text-purple-400 flex-shrink-0" />
            <span>أيقونة فخمة على شاشة هاتفك</span>
          </div>
          <div className="flex items-center gap-2 text-slate-300">
            <Smartphone className="w-4 h-4 text-sky-400 flex-shrink-0" />
            <span>حفظ الأغاني محلياً بالهاتف</span>
          </div>
        </div>

        {/* Installation Actions */}
        <div className="space-y-3">
          
          {/* If already installed */}
          {isInstalled && (
            <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-center text-xs font-bold flex items-center justify-center gap-2">
              <CheckCircle className="w-4 h-4" />
              <span>التطبيق مثبت بالفعل على جهازك وتعمل في وضع التطبيق المستقل!</span>
            </div>
          )}

          {/* Direct Install on Android / Chromium */}
          {isInstallable && !isInstalled && (
            <button
              onClick={handleInstallClick}
              className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 hover:brightness-110 active:scale-[0.99] text-slate-950 font-black text-sm shadow-xl shadow-amber-500/25 transition-all flex items-center justify-center gap-2.5"
            >
              <Download className="w-5 h-5 text-slate-950" />
              <span>تثبيت التطبيق الآن على الشاشة الرئيسية (Install APK)</span>
            </button>
          )}

          {/* iOS Safari Guide */}
          {isIOS && (
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
              <p className="font-bold text-amber-400 flex items-center gap-1.5">
                <Share2 className="w-4 h-4" />
                <span>طريقة التثبيت على أجهزة iPhone / iPad:</span>
              </p>
              <ol className="list-decimal list-inside space-y-1 text-slate-300 pr-1 leading-relaxed">
                <li>اضغط على زر <strong>المشاركة (Share)</strong> في شريط متصفح Safari بالأسفل.</li>
                <li>مرر للأسفل واختر <strong>«إضافة إلى الشاشة الرئيسية» (Add to Home Screen)</strong>.</li>
                <li>اضغط <strong>إضافة (Add)</strong> لتجد أيقونة التطبيق الجميلة على شاشتك.</li>
              </ol>
            </div>
          )}

          {/* Android Manual Instruction if not triggered yet */}
          {isAndroid && !isInstallable && !isInstalled && (
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
              <p className="font-bold text-amber-400 flex items-center gap-1.5">
                <Smartphone className="w-4 h-4" />
                <span>طريقة التثبيت على هواتف أندرويد (Chrome):</span>
              </p>
              <ol className="list-decimal list-inside space-y-1 text-slate-300 pr-1 leading-relaxed">
                <li>اضغط على قائمة <strong>الثلاث نقاط (⋮)</strong> في أعلى متصفح Chrome.</li>
                <li>اختر <strong>«تثبيت التطبيق» (Install app)</strong> أو <strong>«إضافة إلى الشاشة الرئيسية»</strong>.</li>
                <li>سيتم تثبيت التطبيق فوراً بأيقونته كأي تطبيق APK نظامي!</li>
              </ol>
            </div>
          )}

          {/* Standalone APK Builder option */}
          <div className="pt-2 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
            <span className="text-slate-400">
              تريد حزمة ملف APK مستقل لمتجر Google Play؟
            </span>
            <a
              href={pwaBuilderUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-400 font-bold transition-all"
            >
              <span>إنشاء ملف APK عبر PWA Builder</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>

        </div>

      </div>
    </div>
  );
};
