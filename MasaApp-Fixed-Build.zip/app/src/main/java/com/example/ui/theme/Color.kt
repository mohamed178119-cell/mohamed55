package com.example.ui.theme
import androidx.compose.ui.graphics.Color

val MasaPurple = Color(0xFF5E35B1)
val MasaPurpleDark = Color(0xFF311B92)
val MasaPurpleLight = Color(0xFFEDE7F6)
val MasaAmber = Color(0xFFFFB300)
val MasaTeal = Color(0xFF00897B)
