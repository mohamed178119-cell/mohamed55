package com.example.data.db
import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [StudyDocument::class, ChatMessage::class, LectureRecording::class], version = 1, exportSchema = false)
abstract class MasaDatabase : RoomDatabase() {
    abstract fun studyDao(): StudyDao
    abstract fun chatDao(): ChatDao
    abstract fun lectureDao(): LectureDao

    companion object {
        @Volatile
        private var INSTANCE: MasaDatabase? = null

        fun getDatabase(context: Context): MasaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MasaDatabase::class.java,
                    "masa_study_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
