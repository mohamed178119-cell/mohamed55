package com.example.data.repository

import android.content.Context
import android.net.Uri
import android.util.Base64
import com.example.data.api.*
import com.example.data.db.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class MasaRepository(private val context: Context) {
    private val db = MasaDatabase.getDatabase(context)
    private val studyDao = db.studyDao()
    private val chatDao = db.chatDao()
    private val lectureDao = db.lectureDao()

    val allDocuments: Flow<List<StudyDocument>> = studyDao.getAllDocuments()
    val allMessages: Flow<List<ChatMessage>> = chatDao.getAllMessages()
    val allLectures: Flow<List<LectureRecording>> = lectureDao.getAllLectures()

    suspend fun saveDocument(doc: StudyDocument): Long = withContext(Dispatchers.IO) { studyDao.insertDocument(doc) }
    suspend fun deleteDocument(id: Long) = withContext(Dispatchers.IO) { studyDao.deleteDocument(id) }
    suspend fun saveMessage(msg: ChatMessage): Long = withContext(Dispatchers.IO) { chatDao.insertMessage(msg) }
    suspend fun clearChat() = withContext(Dispatchers.IO) { chatDao.clearChatHistory() }
    suspend fun saveLecture(lecture: LectureRecording): Long = withContext(Dispatchers.IO) { lectureDao.insertLecture(lecture) }
    suspend fun deleteLecture(id: Long) = withContext(Dispatchers.IO) { lectureDao.deleteLecture(id) }

    suspend fun askMasa(
        userPrompt: String,
        documentContext: String? = null,
        base64Image: String? = null,
        base64Audio: String? = null,
        mimeType: String? = null,
        customApiKey: String? = null
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val apiKey = customApiKey?.trim().orEmpty()
            if (apiKey.isBlank()) {
                return@withContext Result.failure(Exception("يرجى إدخال كلمة السر للاستمرار."))
            }

            val partsList = mutableListOf<Part>()
            if (!documentContext.isNullOrBlank()) {
                partsList.add(Part(text = "سياق المستند:
$documentContext
---"))
            }
            if (!base64Image.isNullOrBlank()) {
                partsList.add(Part(inlineData = InlineData(mimeType = mimeType ?: "image/jpeg", data = base64Image)))
            }
            if (!base64Audio.isNullOrBlank()) {
                partsList.add(Part(inlineData = InlineData(mimeType = mimeType ?: "audio/mp3", data = base64Audio)))
            }
            partsList.add(Part(text = userPrompt))

            val systemInstruction = Content(
                parts = listOf(Part(text = "أنت مساعد دراسي ذكي يدعى ماسة."))
            )

            val request = GenerateContentRequest(
                contents = listOf(Content(parts = partsList)),
                generationConfig = GenerationConfig(temperature = 0.2f),
                systemInstruction = systemInstruction
            )

            val response = RetrofitClient.service.generateContent(apiKey, request)
            if (response.error != null) {
                return@withContext Result.failure(Exception("خطأ من API: ${response.error.message ?: "خطأ غير معروف"}"))
            }

            val answerText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (!answerText.isNullOrBlank()) {
                Result.success(answerText)
            } else {
                Result.failure(Exception("لم يتم استلام رد."))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
