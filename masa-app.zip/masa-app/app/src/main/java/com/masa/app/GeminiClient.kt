package com.masa.app

import android.util.Base64
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

object GeminiClient {

    // ⚠️ المفتاح متضمن مباشرة في الكود بناءً على طلبك.
    private const val API_KEY = "AQ.Ab8RN6KZhvg6fWgayY-YkE01tdfRLWhHezqqBeXePT_nFasuWQ"
    private const val MODEL = "gemini-2.0-flash"
    private const val ENDPOINT =
        "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent?key=$API_KEY"

    private const val STUDY_SYSTEM_INSTRUCTION =
        "أنت مساعد مذاكرة اسمه \"ماسا\". مهمتك الوحيدة هي الإجابة على أسئلة الطالب بالاعتماد حصريًا " +
        "على محتوى الملف أو الصورة المرفقة في هذه المحادثة (كتاب، ملزمة، امتحان...). " +
        "ممنوع منعًا باتًا الإجابة على أي سؤال لا علاقة له بمحتوى الملف المرفق، حتى لو كان سؤالًا عامًا أو ثقافيًا أو شخصيًا. " +
        "لو السؤال خارج نطاق الملف، اعتذر بأدب وقل: \"السؤال ده خارج نطاق المذاكرة، اسألني حاجة من الملف اللي رفعته.\" " +
        "أجب دائمًا باللغة العربية، وبأسلوب مبسط يناسب طالب بيذاكر."

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    interface ResultCallback {
        fun onSuccess(text: String)
        fun onError(message: String)
    }

    /**
     * Sends a question grounded in the uploaded document.
     * On the first call in a session, the document bytes are attached.
     * Subsequent calls reuse AppState.geminiHistory so context carries on
     * without re-uploading the file every time.
     */
    fun askAboutDocument(question: String, callback: ResultCallback) {
        val fileBytes = AppState.fileBytes
        val mimeType = AppState.fileMimeType

        val userParts = JSONArray()
        // Attach the file only on the very first turn of the conversation.
        if (AppState.geminiHistory.length() == 0 && fileBytes != null && mimeType != null) {
            val filePart = JSONObject().apply {
                put("inline_data", JSONObject().apply {
                    put("mime_type", mimeType)
                    put("data", Base64.encodeToString(fileBytes, Base64.NO_WRAP))
                })
            }
            userParts.put(filePart)
        }
        userParts.put(JSONObject().apply { put("text", question) })

        val userTurn = JSONObject().apply {
            put("role", "user")
            put("parts", userParts)
        }
        AppState.geminiHistory.put(userTurn)

        val body = JSONObject().apply {
            put("system_instruction", JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", STUDY_SYSTEM_INSTRUCTION)))
            })
            put("contents", AppState.geminiHistory)
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.3)
            })
        }

        send(body, onSuccess = { text ->
            // Save model's answer into the running history too.
            val modelTurn = JSONObject().apply {
                put("role", "model")
                put("parts", JSONArray().put(JSONObject().put("text", text)))
            }
            AppState.geminiHistory.put(modelTurn)
            callback.onSuccess(text)
        }, onError = { err ->
            // Remove the failed user turn so a retry doesn't duplicate it.
            if (AppState.geminiHistory.length() > 0) {
                AppState.geminiHistory.remove(AppState.geminiHistory.length() - 1)
            }
            callback.onError(err)
        })
    }

    /** Sends a recorded audio clip and asks Gemini to summarize the lecture in Arabic. */
    fun summarizeAudio(audioBytes: ByteArray, mimeType: String, callback: ResultCallback) {
        val parts = JSONArray()
        parts.put(JSONObject().apply {
            put("inline_data", JSONObject().apply {
                put("mime_type", mimeType)
                put("data", Base64.encodeToString(audioBytes, Base64.NO_WRAP))
            })
        })
        parts.put(JSONObject().apply {
            put(
                "text",
                "لخص هذا التسجيل الصوتي لحصة دراسية باللغة العربية. اكتب الملخص في نقاط واضحة " +
                "تغطي أهم الأفكار والمعلومات اللي اتقالت في الحصة."
            )
        })

        val contents = JSONArray().put(JSONObject().apply {
            put("role", "user")
            put("parts", parts)
        })

        val body = JSONObject().apply {
            put("contents", contents)
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.3)
            })
        }

        send(body, onSuccess = { callback.onSuccess(it) }, onError = { callback.onError(it) })
    }

    private fun send(body: JSONObject, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        val mediaType = "application/json".toMediaType()
        val request = Request.Builder()
            .url(ENDPOINT)
            .post(body.toString().toRequestBody(mediaType))
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                onError("فشل الاتصال بالسيرفر: ${e.message}")
            }

            override fun onResponse(call: Call, response: okhttp3.Response) {
                response.use { resp ->
                    val raw = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        onError("خطأ من السيرفر (${resp.code}): $raw")
                        return
                    }
                    try {
                        val json = JSONObject(raw)
                        val candidates = json.optJSONArray("candidates")
                        if (candidates == null || candidates.length() == 0) {
                            onError("لم يصل رد من Gemini. حاول تاني.")
                            return
                        }
                        val content = candidates.getJSONObject(0).getJSONObject("content")
                        val partsArr = content.getJSONArray("parts")
                        val text = StringBuilder()
                        for (i in 0 until partsArr.length()) {
                            text.append(partsArr.getJSONObject(i).optString("text"))
                        }
                        onSuccess(text.toString())
                    } catch (e: Exception) {
                        onError("تعذر قراءة الرد: ${e.message}")
                    }
                }
            }
        })
    }
}
